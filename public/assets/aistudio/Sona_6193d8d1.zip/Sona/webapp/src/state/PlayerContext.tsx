import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from "react";
import { api } from "../api";
import type { Track } from "../types";
import { haptic } from "../telegram";
import { useToast } from "./ToastContext";

type RepeatMode = "off" | "all" | "one";

interface PlayerContextValue {
  current: Track | null;
  queue: Track[];
  queueIndex: number;
  isPlaying: boolean;
  progress: number;
  duration: number;
  shuffle: boolean;
  repeat: RepeatMode;
  expanded: boolean;
  playTrack: (track: Track, queue?: Track[]) => void;
  playQueue: (tracks: Track[], startIndex?: number) => void;
  togglePlay: () => void;
  next: () => void;
  previous: () => void;
  seek: (seconds: number) => void;
  setShuffle: (value: boolean) => void;
  cycleRepeat: () => void;
  openPlayer: () => void;
  closePlayer: () => void;
  addToQueue: (track: Track) => void;
}

const PlayerContext = createContext<PlayerContextValue | null>(null);

function mediaUrl(url: string): string {
  if (/^https?:\/\//i.test(url)) return url;
  return new URL(url, window.location.origin).toString();
}

export function PlayerProvider({ children }: { children: ReactNode }) {
  const { toast } = useToast();
  const audioRef = useRef<HTMLAudioElement | null>(null);
  if (!audioRef.current) {
    audioRef.current = new Audio();
    audioRef.current.preload = "metadata";
  }

  const [queue, setQueue] = useState<Track[]>([]);
  const [queueIndex, setQueueIndex] = useState(-1);
  const [isPlaying, setIsPlaying] = useState(false);
  const [progress, setProgress] = useState(0);
  const [duration, setDuration] = useState(0);
  const [shuffle, setShuffleState] = useState(false);
  const [repeat, setRepeat] = useState<RepeatMode>("off");
  const [expanded, setExpanded] = useState(false);

  const queueRef = useRef<Track[]>([]);
  const indexRef = useRef(-1);
  const shuffleRef = useRef(false);
  const repeatRef = useRef<RepeatMode>("off");

  useEffect(() => {
    queueRef.current = queue;
  }, [queue]);
  useEffect(() => {
    indexRef.current = queueIndex;
  }, [queueIndex]);
  useEffect(() => {
    shuffleRef.current = shuffle;
  }, [shuffle]);
  useEffect(() => {
    repeatRef.current = repeat;
  }, [repeat]);

  const current = queueIndex >= 0 ? queue[queueIndex] || null : null;

  const startAt = useCallback(
    (tracks: Track[], index: number, shouldPlay = true) => {
      const audio = audioRef.current;
      if (!audio || tracks.length === 0) return;

      let targetIndex = index;
      let attempts = 0;
      while (attempts < tracks.length && !tracks[targetIndex]?.preview_url) {
        targetIndex = (targetIndex + 1) % tracks.length;
        attempts += 1;
      }
      const track = tracks[targetIndex];
      if (!track?.preview_url) {
        toast("У этого трека нет превью — открой его в музыкальном сервисе", "info");
        return;
      }

      setQueue(tracks);
      queueRef.current = tracks;
      setQueueIndex(targetIndex);
      indexRef.current = targetIndex;
      setProgress(0);
      audio.src = mediaUrl(track.preview_url);
      audio.currentTime = 0;
      setDuration((track.duration_ms || 30_000) / 1000);
      if (shouldPlay) {
        audio
          .play()
          .then(() => {
            setIsPlaying(true);
            api.registerPlay(track.id).catch(() => undefined);
          })
          .catch(() => {
            setIsPlaying(false);
            toast("Не удалось включить превью. Проверь соединение.", "error");
          });
        setIsPlaying(true);
        haptic("light");
      }
    },
    [toast],
  );

  const playQueue = useCallback(
    (tracks: Track[], startIndex = 0) => {
      if (!tracks.length) return;
      startAt(tracks, Math.max(0, Math.min(startIndex, tracks.length - 1)));
    },
    [startAt],
  );

  const playTrack = useCallback(
    (track: Track, nextQueue?: Track[]) => {
      const audio = audioRef.current;
      if (!audio) return;
      if (current?.id === track.id) {
        if (audio.paused) {
          audio.play().then(() => setIsPlaying(true)).catch(() => undefined);
        } else {
          audio.pause();
          setIsPlaying(false);
        }
        return;
      }
      const sourceQueue = nextQueue?.length ? nextQueue : [track];
      const index = Math.max(
        0,
        sourceQueue.findIndex((item) => item.id === track.id),
      );
      startAt(sourceQueue, index);
    },
    [current?.id, startAt],
  );

  const next = useCallback(() => {
    const audio = audioRef.current;
    const tracks = queueRef.current;
    if (!audio || !tracks.length) return;
    if (repeatRef.current === "one") {
      audio.currentTime = 0;
      audio.play().catch(() => undefined);
      return;
    }
    if (shuffleRef.current && tracks.length > 1) {
      let nextIndex = indexRef.current;
      while (nextIndex === indexRef.current) {
        nextIndex = Math.floor(Math.random() * tracks.length);
      }
      startAt(tracks, nextIndex);
      return;
    }
    const nextIndex = indexRef.current + 1;
    if (nextIndex >= tracks.length) {
      if (repeatRef.current === "all") {
        startAt(tracks, 0);
      } else {
        audio.pause();
        setIsPlaying(false);
      }
      return;
    }
    startAt(tracks, nextIndex);
  }, [startAt]);

  const previous = useCallback(() => {
    const audio = audioRef.current;
    const tracks = queueRef.current;
    if (!audio || !tracks.length) return;
    if (audio.currentTime > 3) {
      audio.currentTime = 0;
      return;
    }
    const prevIndex = indexRef.current - 1;
    if (prevIndex < 0) {
      startAt(tracks, repeatRef.current === "all" ? tracks.length - 1 : 0);
      return;
    }
    startAt(tracks, prevIndex);
  }, [startAt]);

  const togglePlay = useCallback(() => {
    const audio = audioRef.current;
    if (!audio) return;
    if (!current) {
      if (queue.length) startAt(queue, 0);
      return;
    }
    if (!current.preview_url) {
      toast("У этого трека нет превью", "info");
      return;
    }
    if (audio.paused) {
      audio.play().then(() => setIsPlaying(true)).catch(() => undefined);
    } else {
      audio.pause();
      setIsPlaying(false);
    }
  }, [current, queue, startAt, toast]);

  const seek = useCallback((seconds: number) => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.currentTime = seconds;
    setProgress(seconds);
  }, []);

  const setShuffle = useCallback((value: boolean) => {
    setShuffleState(value);
    toast(value ? "Перемешивание включено" : "Перемешивание выключено", "info");
  }, [toast]);

  const cycleRepeat = useCallback(() => {
    setRepeat((mode) => {
      const nextMode = mode === "off" ? "all" : mode === "all" ? "one" : "off";
      toast(
        nextMode === "off"
          ? "Повтор выключен"
          : nextMode === "all"
            ? "Повтор очереди"
            : "Повтор трека",
        "info",
      );
      return nextMode;
    });
  }, [toast]);

  const addToQueue = useCallback(
    (track: Track) => {
      const tracks = queueRef.current;
      if (!tracks.length || indexRef.current < 0) {
        startAt([...tracks, track], tracks.length);
        return;
      }
      setQueue((current) => {
        const nextQueue = [...current, track];
        queueRef.current = nextQueue;
        return nextQueue;
      });
      toast(`«${track.title}» в очереди`, "success");
    },
    [startAt, toast],
  );

  const openPlayer = useCallback(() => setExpanded(true), []);
  const closePlayer = useCallback(() => setExpanded(false), []);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    const onTime = () => setProgress(audio.currentTime || 0);
    const onDuration = () => {
      if (Number.isFinite(audio.duration)) setDuration(audio.duration);
    };
    const onPlay = () => setIsPlaying(true);
    const onPause = () => setIsPlaying(false);
    const onEnded = () => {
      setIsPlaying(false);
      next();
    };
    const onError = () => {
      if (audio.src) setIsPlaying(false);
    };

    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("durationchange", onDuration);
    audio.addEventListener("loadedmetadata", onDuration);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("ended", onEnded);
    audio.addEventListener("error", onError);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("durationchange", onDuration);
      audio.removeEventListener("loadedmetadata", onDuration);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("ended", onEnded);
      audio.removeEventListener("error", onError);
    };
  }, [next]);

  useEffect(() => {
    if (!current || !("mediaSession" in navigator)) return;
    try {
      navigator.mediaSession.metadata = new MediaMetadata({
        title: current.title,
        artist: current.artist,
        album: current.album || "Sona",
        artwork: current.artwork_url
          ? [{ src: current.artwork_url, sizes: "512x512" }]
          : [],
      });
      navigator.mediaSession.setActionHandler("play", () => togglePlay());
      navigator.mediaSession.setActionHandler("pause", () => togglePlay());
      navigator.mediaSession.setActionHandler("nexttrack", () => next());
      navigator.mediaSession.setActionHandler("previoustrack", () => previous());
    } catch {
      /* unsupported */
    }
  }, [current, next, previous, togglePlay]);

  useEffect(
    () => () => {
      audioRef.current?.pause();
    },
    [],
  );

  const value = useMemo<PlayerContextValue>(
    () => ({
      current,
      queue,
      queueIndex,
      isPlaying,
      progress,
      duration,
      shuffle,
      repeat,
      expanded,
      playTrack,
      playQueue,
      togglePlay,
      next,
      previous,
      seek,
      setShuffle,
      cycleRepeat,
      openPlayer,
      closePlayer,
      addToQueue,
    }),
    [
      current,
      queue,
      queueIndex,
      isPlaying,
      progress,
      duration,
      shuffle,
      repeat,
      expanded,
      playTrack,
      playQueue,
      togglePlay,
      next,
      previous,
      seek,
      setShuffle,
      cycleRepeat,
      openPlayer,
      closePlayer,
      addToQueue,
    ],
  );

  return <PlayerContext.Provider value={value}>{children}</PlayerContext.Provider>;
}

export function usePlayer(): PlayerContextValue {
  const context = useContext(PlayerContext);
  if (!context) throw new Error("usePlayer must be used inside PlayerProvider");
  return context;
}
