interface HapticFeedback {
  impactOccurred: (style: "light" | "medium" | "heavy" | "rigid" | "soft") => void;
  notificationOccurred: (type: "error" | "success" | "warning") => void;
  selectionChanged: () => void;
}

interface TelegramBackButton {
  isVisible: boolean;
  show: () => void;
  hide: () => void;
  onClick: (callback: () => void) => void;
  offClick: (callback: () => void) => void;
}

interface TelegramMainButton {
  text: string;
  isVisible: boolean;
  show: () => void;
  hide: () => void;
  onClick: (callback: () => void) => void;
  offClick: (callback: () => void) => void;
}

export interface TelegramWebAppApi {
  initData: string;
  initDataUnsafe: {
    user?: {
      id: number;
      first_name: string;
      last_name?: string;
      username?: string;
      photo_url?: string;
    };
    start_param?: string;
  };
  colorScheme: "light" | "dark";
  themeParams: Record<string, string>;
  ready: () => void;
  expand: () => void;
  close: () => void;
  setHeaderColor: (color: string) => void;
  setBackgroundColor: (color: string) => void;
  disableVerticalSwipes?: () => void;
  enableClosingConfirmation?: () => void;
  openLink: (url: string, options?: { try_instant_view?: boolean }) => void;
  openTelegramLink: (url: string) => void;
  switchInlineQuery: (query: string, chatTypes?: Array<"users" | "bots" | "groups" | "channels">) => void;
  showAlert: (message: string, callback?: () => void) => void;
  showConfirm: (message: string, callback?: (confirmed: boolean) => void) => void;
  HapticFeedback?: HapticFeedback;
  BackButton?: TelegramBackButton;
  MainButton?: TelegramMainButton;
  isVersionAtLeast?: (version: string) => boolean;
  platform?: string;
  version?: string;
  viewportStableHeight?: number;
}

declare global {
  interface Window {
    Telegram?: { WebApp: TelegramWebAppApi };
  }
}

export const telegram: TelegramWebAppApi | undefined = window.Telegram?.WebApp;

export const isTelegram = Boolean(telegram?.initData);

export function initTelegram(): void {
  if (!telegram) return;
  try {
    telegram.ready();
    telegram.expand();
    telegram.setHeaderColor("#090d0b");
    telegram.setBackgroundColor("#090d0b");
    telegram.disableVerticalSwipes?.();
  } catch {
    /* Older Telegram clients */
  }
}

export function haptic(type: "light" | "medium" | "success" | "selection" | "error" = "light"): void {
  const feedback = telegram?.HapticFeedback;
  if (!feedback) return;
  try {
    if (type === "success" || type === "error") feedback.notificationOccurred(type);
    else if (type === "selection") feedback.selectionChanged();
    else feedback.impactOccurred(type);
  } catch {
    /* noop */
  }
}

export function getStartParam(): string {
  return telegram?.initDataUnsafe?.start_param || "";
}

export function openExternal(url: string): void {
  if (telegram) {
    telegram.openLink(url);
  } else {
    window.open(url, "_blank", "noopener,noreferrer");
  }
}

export function openTelegramLink(url: string): void {
  if (telegram) telegram.openTelegramLink(url);
  else window.open(url, "_blank", "noopener,noreferrer");
}

export async function copyText(text: string): Promise<boolean> {
  try {
    await navigator.clipboard.writeText(text);
    haptic("success");
    return true;
  } catch {
    try {
      const area = document.createElement("textarea");
      area.value = text;
      area.style.position = "fixed";
      area.style.opacity = "0";
      document.body.appendChild(area);
      area.select();
      document.execCommand("copy");
      document.body.removeChild(area);
      haptic("success");
      return true;
    } catch {
      haptic("error");
      return false;
    }
  }
}

export function shareTrackToTelegram(trackId: number): boolean {
  if (telegram?.switchInlineQuery) {
    try {
      telegram.switchInlineQuery(`track:${trackId}`, ["users", "groups", "channels"]);
      haptic("medium");
      return true;
    } catch {
      return false;
    }
  }
  return false;
}

export function shareLinkToTelegram(url: string, text: string): void {
  const shareUrl = `https://t.me/share/url?url=${encodeURIComponent(url)}&text=${encodeURIComponent(text)}`;
  openTelegramLink(shareUrl);
}
