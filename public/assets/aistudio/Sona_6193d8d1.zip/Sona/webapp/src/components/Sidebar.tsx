import { useQuery } from "@tanstack/react-query";
import { NavLink } from "react-router-dom";
import {
  Heart,
  House,
  Library,
  Plus,
  Search,
  Settings2,
  Sparkles,
} from "lucide-react";
import { api } from "../api";
import { useAuth } from "../state/AuthContext";
import { useUI } from "../state/UIContext";
import { cn } from "../utils";
import { Avatar } from "./Avatar";
import { Logo } from "./Logo";

const navItems = [
  { to: "/", label: "Главная", icon: House, end: true },
  { to: "/search", label: "Поиск", icon: Search },
  { to: "/library", label: "Коллекция", icon: Library },
  { to: "/likes", label: "Избранное", icon: Heart },
];

export function Sidebar() {
  const { user, isDev } = useAuth();
  const { openCreatePlaylist } = useUI();
  const { data: playlists = [], isLoading } = useQuery({
    queryKey: ["playlists"],
    queryFn: api.playlists,
    staleTime: 30_000,
  });

  return (
    <aside className="sidebar">
      <div className="sidebar__top">
        <Logo />
        <span className="beta-chip">beta</span>
      </div>

      <nav className="sidebar__nav" aria-label="Основная навигация">
        {navItems.map(({ to, label, icon: Icon, end }) => (
          <NavLink
            key={to}
            to={to}
            end={end}
            className={({ isActive }) => cn("sidebar-link", isActive && "is-active")}
          >
            <Icon size={19} strokeWidth={1.9} />
            <span>{label}</span>
            {to === "/likes" && user && <span className="sidebar-link__dot" />}
          </NavLink>
        ))}
      </nav>

      <div className="sidebar__divider" />

      <div className="sidebar__playlists">
        <div className="sidebar__label-row">
          <span className="sidebar__label">Твои плейлисты</span>
          <button
            type="button"
            className="icon-btn icon-btn--tiny"
            onClick={() => openCreatePlaylist()}
            aria-label="Создать плейлист"
          >
            <Plus size={16} />
          </button>
        </div>

        <div className="sidebar__playlist-list">
          {isLoading &&
            Array.from({ length: 4 }).map((_, index) => (
              <div key={index} className="sidebar-skeleton" />
            ))}
          {!isLoading && playlists.length === 0 && (
            <button
              type="button"
              className="sidebar-empty"
              onClick={() => openCreatePlaylist()}
            >
              <Sparkles size={16} />
              Собрать первый плейлист
            </button>
          )}
          {playlists.slice(0, 8).map((playlist) => (
            <NavLink
              key={playlist.id}
              to={`/playlist/${playlist.id}`}
              className={({ isActive }) =>
                cn("sidebar-playlist", isActive && "is-active")
              }
            >
              <span className="sidebar-playlist__art">
                {playlist.collage[0] ? (
                  <img src={playlist.collage[0]} alt="" loading="lazy" />
                ) : (
                  <span>{playlist.title.slice(0, 1).toUpperCase()}</span>
                )}
              </span>
              <span className="sidebar-playlist__text">
                <span className="sidebar-playlist__title">{playlist.title}</span>
                <span className="sidebar-playlist__meta">
                  {playlist.is_public ? "публичный" : "скрытый"} · {playlist.track_count}
                </span>
              </span>
            </NavLink>
          ))}
        </div>
      </div>

      <div className="sidebar__footer">
        {isDev && (
          <div className="dev-note">
            <span className="dev-note__dot" />
            Демо-режим
          </div>
        )}
        <NavLink to="/profile" className="sidebar-profile">
          <Avatar name={user?.display_name || "Sona"} src={user?.photo_url} size="sm" />
          <span className="sidebar-profile__text">
            <span className="sidebar-profile__name">{user?.display_name}</span>
            <span className="sidebar-profile__meta">
              {user?.username ? `@${user.username}` : "музыкальный профиль"}
            </span>
          </span>
          <Settings2 size={17} className="sidebar-profile__settings" />
        </NavLink>
      </div>
    </aside>
  );
}
