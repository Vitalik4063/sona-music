import { Heart, Pause, Play, SkipForward } from "lucide-react";
import { usePlayer } from "../state/PlayerContext";
import { useTrackLike } from "../hooks/useTrackLike";
import { cn } from "../utils";
import { Cover } from "./Cover";
import { Equalizer } from "./Equalizer";

export function MiniPlayer() {
  const player = usePlayer();
  const { liked, toggle } = useTrackLike(player.current);

  if (!player.current) return null;
  const track = player.current;
  const percent = player.duration
    ? Math.min(100, (player.progress / player.duration) * 100)
    : 0;

  return (
    <div
      className={cn("mini-player", player.expanded && "mini-player--hidden")}
      role="region"
      aria-label="Плеер"
    >
      <button
        type="button"
        className="mini-player__main"
        onClick={player.openPlayer}
        aria-label="Открыть плеер"
      >
        <span className="mini-player__art">
          <Cover src={track.artwork_url} seed={track.title + track.artist} alt="" />
          {player.isPlaying && (
            <span className="mini-player__eq">
              <Equalizer paused={false} />
            </span>
          )}
        </span>
        <span className="mini-player__meta">
          <span className="mini-player__title">{track.title}</span>
          <span className="mini-player__artist">
            {track.artist}
            <span className="mini-player__preview"> · превью 30 сек</span>
          </span>
        </span>
      </button>

      <div className="mini-player__progress" aria-hidden="true">
        <span style={{ width: `${percent}%` }} />
      </div>

      <div className="mini-player__controls">
        <button
          type="button"
          className={cn("icon-btn mini-player__like", liked && "is-liked")}
          onClick={() => void toggle()}
          aria-label={liked ? "Убрать из избранного" : "В избранное"}
          aria-pressed={liked}
        >
          <Heart size={18} fill={liked ? "currentColor" : "none"} />
        </button>
        <button
          type="button"
          className="mini-player__play"
          onClick={player.togglePlay}
          aria-label={player.isPlaying ? "Пауза" : "Играть"}
        >
          {player.isPlaying ? (
            <Pause size={19} fill="currentColor" />
          ) : (
            <Play size={19} fill="currentColor" />
          )}
        </button>
        <button
          type="button"
          className="icon-btn mini-player__next"
          onClick={player.next}
          aria-label="Следующий трек"
        >
          <SkipForward size={19} fill="currentColor" />
        </button>
      </div>
    </div>
  );
}
