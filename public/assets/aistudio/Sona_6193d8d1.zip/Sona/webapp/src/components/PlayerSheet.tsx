import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import {
  ChevronDown,
  Heart,
  ListMusic,
  Pause,
  Play,
  Plus,
  Repeat,
  Repeat1,
  Share2,
  Shuffle,
  SkipBack,
  SkipForward,
  Sparkles,
} from "lucide-react";
import { usePlayer } from "../state/PlayerContext";
import { useBodyScrollLock } from "../hooks/useBodyScrollLock";
import { useTrackLike } from "../hooks/useTrackLike";
import { useUI } from "../state/UIContext";
import { useToast } from "../state/ToastContext";
import { openExternal, shareTrackToTelegram } from "../telegram";
import { cn, formatDuration } from "../utils";
import { Cover } from "./Cover";
import { Equalizer } from "./Equalizer";

export function PlayerSheet() {
  const player = usePlayer();
  const { closePlayer, togglePlay } = player;
  const { openPlaylistPicker, setQueueOpen } = useUI();
  const { toast } = useToast();
  const { liked, toggle } = useTrackLike(player.current);
  const [scrubbing, setScrubbing] = useState(false);
  const [scrubValue, setScrubValue] = useState(0);

  useBodyScrollLock(player.expanded && Boolean(player.current));

  useEffect(() => {
    if (!player.expanded) return;
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closePlayer();
      if (event.key === " " && event.target === document.body) {
        event.preventDefault();
        togglePlay();
      }
    };
    document.addEventListener("keydown", onKeyDown);
    return () => document.removeEventListener("keydown", onKeyDown);
  }, [closePlayer, player.expanded, togglePlay]);

  if (!player.expanded || !player.current) return null;
  const track = player.current;
  const duration = player.duration || track.duration_ms / 1000 || 30;
  const value = scrubbing ? scrubValue : Math.min(player.progress, duration);
  const percent = duration ? (value / duration) * 100 : 0;

  const share = () => {
    if (!shareTrackToTelegram(track.id)) {
      const url = track.external_url || track.links?.deezer || track.links?.itunes;
      if (url) {
        void navigator.clipboard.writeText(url).catch(() => undefined);
        toast("Ссылка на трек скопирована", "success");
      } else {
        toast("Открыть Sona в Telegram, чтобы поделиться треком", "info");
      }
    }
  };

  return createPortal(
    <div
      className="player-expanded"
      role="dialog"
      aria-modal="true"
      aria-label={`Плеер: ${track.title}`}
    >
      <div
        className="player-expanded__backdrop"
        style={
          track.artwork_url
            ? { backgroundImage: `url(${track.artwork_url})` }
            : undefined
        }
        aria-hidden="true"
      />
      <div className="player-expanded__noise" aria-hidden="true" />

      <div className="player-expanded__inner">
        <header className="player-expanded__top">
          <button
            type="button"
            className="icon-btn icon-btn--on-dark"
            onClick={player.closePlayer}
            aria-label="Свернуть плеер"
          >
            <ChevronDown size={22} />
          </button>
          <div className="player-expanded__label">
            <span className="player-expanded__eyebrow">Сейчас играет</span>
            <span className="player-expanded__source">{track.album || "Sona"}</span>
          </div>
          <button
            type="button"
            className="icon-btn icon-btn--on-dark"
            onClick={share}
            aria-label="Поделиться треком"
          >
            <Share2 size={20} />
          </button>
        </header>

        <div className="player-expanded__body">
          <div className="player-expanded__art-column">
            <div className="player-expanded__art-wrap">
              <span className="player-expanded__orbit player-expanded__orbit--one" />
              <span className="player-expanded__orbit player-expanded__orbit--two" />
              <Cover
                src={track.artwork_url}
                seed={track.title + track.artist}
                alt={track.title}
                className={cn("player-expanded__art", player.isPlaying && "is-playing")}
                loading="eager"
              />
              <span className="player-expanded__art-chip">
                {track.is_demo ? "Sona Sessions" : track.provider}
              </span>
            </div>
          </div>

          <div className="player-expanded__info">
            <div className="player-expanded__title-row">
              <div className="player-expanded__heading">
                <h1>{track.title}</h1>
                <p>{track.artist}</p>
              </div>
              <button
                type="button"
                className={cn("icon-btn icon-btn--on-dark player-expanded__like", liked && "is-liked")}
                onClick={() => void toggle()}
                aria-label={liked ? "Убрать из избранного" : "В избранное"}
                aria-pressed={liked}
              >
                <Heart size={22} fill={liked ? "currentColor" : "none"} />
              </button>
            </div>

            <div className="player-expanded__timeline">
              <div className="range-wrap">
                <div className="range-track" aria-hidden="true">
                  <span style={{ width: `${percent}%` }} />
                </div>
                <input
                  type="range"
                  min={0}
                  max={duration}
                  step={0.1}
                  value={value}
                  onChange={(event) => {
                    setScrubbing(true);
                    setScrubValue(Number(event.target.value));
                  }}
                  onMouseUp={(event) => {
                    player.seek(Number(event.currentTarget.value));
                    setScrubbing(false);
                  }}
                  onTouchEnd={(event) => {
                    player.seek(Number(event.currentTarget.value));
                    setScrubbing(false);
                  }}
                  onKeyUp={(event) => {
                    player.seek(Number(event.currentTarget.value));
                    setScrubbing(false);
                  }}
                  aria-label="Позиция воспроизведения"
                />
              </div>
              <div className="player-expanded__times">
                <span>{formatDuration(value * 1000)}</span>
                <span>{formatDuration(duration * 1000)}</span>
              </div>
            </div>

            <div className="player-expanded__controls">
              <button
                type="button"
                className={cn("player-control", player.shuffle && "is-active")}
                onClick={() => player.setShuffle(!player.shuffle)}
                aria-label="Перемешать"
                aria-pressed={player.shuffle}
              >
                <Shuffle size={19} />
              </button>
              <button
                type="button"
                className="player-control player-control--skip"
                onClick={player.previous}
                aria-label="Предыдущий трек"
              >
                <SkipBack size={26} fill="currentColor" />
              </button>
              <button
                type="button"
                className="player-control player-control--play"
                onClick={player.togglePlay}
                aria-label={player.isPlaying ? "Пауза" : "Играть"}
              >
                {player.isPlaying ? (
                  <Pause size={28} fill="currentColor" />
                ) : (
                  <Play size={28} fill="currentColor" />
                )}
              </button>
              <button
                type="button"
                className="player-control player-control--skip"
                onClick={player.next}
                aria-label="Следующий трек"
              >
                <SkipForward size={26} fill="currentColor" />
              </button>
              <button
                type="button"
                className={cn("player-control", player.repeat !== "off" && "is-active")}
                onClick={player.cycleRepeat}
                aria-label="Повтор"
              >
                {player.repeat === "one" ? <Repeat1 size={19} /> : <Repeat size={19} />}
              </button>
            </div>

            <div className="player-expanded__extras">
              <button
                type="button"
                className="player-extra"
                onClick={() => openPlaylistPicker(track)}
              >
                <Plus size={17} />
                В плейлист
              </button>
              <button
                type="button"
                className="player-extra"
                onClick={() => setQueueOpen(true)}
              >
                <ListMusic size={17} />
                Очередь
                <span className="player-extra__badge">{player.queue.length}</span>
              </button>
              {track.external_url && (
                <button
                  type="button"
                  className="player-extra"
                  onClick={() => openExternal(track.external_url as string)}
                >
                  <Sparkles size={17} />
                  Оригинал
                </button>
              )}
            </div>

            <div className="player-expanded__status">
              <Equalizer paused={!player.isPlaying} />
              <span>
                {track.preview_url
                  ? "Играет 30-секундное превью · полная версия в музыкальном сервисе"
                  : "Превью недоступно · открой трек в сервисе"}
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>,
    document.body,
  );
}
