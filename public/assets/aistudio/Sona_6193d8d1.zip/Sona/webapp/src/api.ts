import type {
  CopyResult,
  HealthData,
  HomeData,
  Mix,
  Playlist,
  PlaylistSummary,
  PublicPlaylist,
  PublicProfile,
  SearchResult,
  Session,
  SettingsData,
  SettingsPatch,
  Track,
  User,
} from "./types";

const TOKEN_KEY = "sona.session.token";
const API_BASE = "/api";

let token: string = localStorage.getItem(TOKEN_KEY) || "";

export class ApiError extends Error {
  status: number;
  detail: unknown;

  constructor(status: number, detail: unknown, message?: string) {
    super(message || (typeof detail === "string" ? detail : "Ошибка запроса"));
    this.name = "ApiError";
    this.status = status;
    this.detail = detail;
  }
}

export function getToken(): string {
  return token;
}

export function setToken(value: string): void {
  token = value;
  if (value) localStorage.setItem(TOKEN_KEY, value);
  else localStorage.removeItem(TOKEN_KEY);
}

function errorMessage(detail: unknown): string {
  if (typeof detail === "string") return detail;
  if (Array.isArray(detail)) {
    const first = detail[0] as { msg?: string } | undefined;
    if (first?.msg) return first.msg;
  }
  if (detail && typeof detail === "object" && "message" in detail) {
    return String((detail as { message: unknown }).message);
  }
  return "Не удалось выполнить запрос";
}

async function request<T>(
  path: string,
  options: RequestInit = {},
  authenticated = true,
): Promise<T> {
  const headers = new Headers(options.headers);
  if (options.body && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }
  if (authenticated && token) headers.set("Authorization", `Bearer ${token}`);

  const controller = new AbortController();
  const timeout = window.setTimeout(() => controller.abort(), 25_000);
  try {
    const response = await fetch(`${API_BASE}${path}`, {
      ...options,
      headers,
      signal: options.signal || controller.signal,
    });
    if (!response.ok) {
      let detail: unknown = response.statusText;
      try {
        const payload = await response.json();
        detail = payload.detail ?? payload;
      } catch {
        /* not json */
      }
      throw new ApiError(response.status, detail, errorMessage(detail));
    }
    if (response.status === 204) return undefined as T;
    return (await response.json()) as T;
  } catch (error) {
    if (error instanceof DOMException && error.name === "AbortError") {
      throw new ApiError(0, "timeout", "Сервер не ответил вовремя. Попробуй ещё раз.");
    }
    throw error;
  } finally {
    window.clearTimeout(timeout);
  }
}

export const api = {
  async health(): Promise<HealthData> {
    return request<HealthData>("/health", {}, false);
  },

  async bootstrap(): Promise<Session | null> {
    const tg = window.Telegram?.WebApp;
    const initData = tg?.initData?.trim();
    let storedError: unknown = null;

    if (initData) {
      try {
        const session = await request<Session>(
          "/auth/session",
          {
            method: "POST",
            body: JSON.stringify({ initData }),
          },
          false,
        );
        setToken(session.token);
        return session;
      } catch (error) {
        storedError = error;
      }
    }

    if (token) {
      try {
        const user = await request<User>("/me");
        return { token, user, is_dev: false };
      } catch (error) {
        if (error instanceof ApiError && error.status === 401) setToken("");
        else storedError = error;
      }
    }

    try {
      const session = await request<Session>("/auth/dev", { method: "POST" }, false);
      setToken(session.token);
      return session;
    } catch (error) {
      if (storedError instanceof ApiError) throw storedError;
      throw error;
    }
  },

  async me(): Promise<User> {
    return request<User>("/me");
  },

  async updateMe(payload: { first_name?: string; bio?: string }): Promise<User> {
    return request<User>("/me", { method: "PATCH", body: JSON.stringify(payload) });
  },

  async home(): Promise<HomeData> {
    return request<HomeData>("/home");
  },

  async mix(id: string): Promise<Mix> {
    return request<Mix>(`/mixes/${encodeURIComponent(id)}`);
  },

  async search(query: string, limit = 30, signal?: AbortSignal): Promise<SearchResult> {
    return request<SearchResult>(
      `/search?q=${encodeURIComponent(query)}&limit=${limit}`,
      { signal },
    );
  },

  async track(id: number): Promise<Track> {
    return request<Track>(`/tracks/${id}`);
  },

  async likes(): Promise<Track[]> {
    return request<Track[]>("/me/likes");
  },

  async like(trackId: number): Promise<Track> {
    return request<Track>(`/likes/${trackId}`, { method: "POST" });
  },

  async unlike(trackId: number): Promise<Track> {
    return request<Track>(`/likes/${trackId}`, { method: "DELETE" });
  },

  async registerPlay(trackId: number): Promise<void> {
    await request("/me/history", {
      method: "POST",
      body: JSON.stringify({ track_id: trackId }),
    });
  },

  async recent(): Promise<Track[]> {
    return request<Track[]>("/me/recent");
  },

  async playlists(): Promise<PlaylistSummary[]> {
    return request<PlaylistSummary[]>("/playlists");
  },

  async playlist(id: number): Promise<Playlist> {
    return request<Playlist>(`/playlists/${id}`);
  },

  async createPlaylist(payload: {
    title: string;
    description?: string;
    is_public?: boolean;
  }): Promise<Playlist> {
    return request<Playlist>("/playlists", {
      method: "POST",
      body: JSON.stringify(payload),
    });
  },

  async updatePlaylist(
    id: number,
    payload: { title?: string; description?: string; is_public?: boolean },
  ): Promise<Playlist> {
    return request<Playlist>(`/playlists/${id}`, {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
  },

  async deletePlaylist(id: number): Promise<void> {
    await request(`/playlists/${id}`, { method: "DELETE" });
  },

  async addTrackToPlaylist(playlistId: number, trackId: number): Promise<Playlist> {
    return request<Playlist>(`/playlists/${playlistId}/tracks`, {
      method: "POST",
      body: JSON.stringify({ track_id: trackId }),
    });
  },

  async removeTrackFromPlaylist(playlistId: number, trackId: number): Promise<Playlist> {
    return request<Playlist>(`/playlists/${playlistId}/tracks/${trackId}`, {
      method: "DELETE",
    });
  },

  async reorderPlaylist(playlistId: number, trackIds: number[]): Promise<Playlist> {
    return request<Playlist>(`/playlists/${playlistId}/reorder`, {
      method: "PATCH",
      body: JSON.stringify({ track_ids: trackIds }),
    });
  },

  async settings(): Promise<SettingsData> {
    return request<SettingsData>("/settings");
  },

  async patchSettings(payload: SettingsPatch): Promise<SettingsData> {
    return request<SettingsData>("/settings", {
      method: "PATCH",
      body: JSON.stringify(payload),
    });
  },

  async addViewer(identifier: string): Promise<SettingsData> {
    return request<SettingsData>("/settings/viewers", {
      method: "POST",
      body: JSON.stringify({ identifier }),
    });
  },

  async removeViewer(id: number): Promise<SettingsData> {
    return request<SettingsData>(`/settings/viewers/${id}`, { method: "DELETE" });
  },

  async approveRequest(id: number): Promise<SettingsData> {
    return request<SettingsData>(`/settings/requests/${id}/approve`, {
      method: "POST",
    });
  },

  async declineRequest(id: number): Promise<SettingsData> {
    return request<SettingsData>(`/settings/requests/${id}/decline`, {
      method: "POST",
    });
  },

  async rotateShare(): Promise<SettingsData> {
    return request<SettingsData>("/settings/rotate-share", { method: "POST" });
  },

  async publicProfile(tokenValue: string): Promise<PublicProfile> {
    return request<PublicProfile>(`/share/${encodeURIComponent(tokenValue)}`);
  },

  async requestAccess(tokenValue: string): Promise<{ status: string; message: string }> {
    return request(`/share/${encodeURIComponent(tokenValue)}/request`, {
      method: "POST",
    });
  },

  async publicPlaylist(tokenValue: string, playlistId: number): Promise<PublicPlaylist> {
    return request<PublicPlaylist>(
      `/share/${encodeURIComponent(tokenValue)}/playlists/${playlistId}`,
    );
  },

  async copyPublicPlaylist(tokenValue: string, playlistId: number): Promise<CopyResult> {
    return request<CopyResult>(
      `/share/${encodeURIComponent(tokenValue)}/playlists/${playlistId}/copy`,
      { method: "POST" },
    );
  },
};
