from __future__ import annotations

from collections.abc import Awaitable, Callable
from typing import Any

from aiogram import BaseMiddleware
from aiogram.types import TelegramObject
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from backend.config import Settings
from backend.services.music.aggregator import SearchAggregator


class SonaMiddleware(BaseMiddleware):
    def __init__(
        self,
        session_factory: async_sessionmaker[AsyncSession],
        settings: Settings,
        aggregator: SearchAggregator,
    ) -> None:
        self.session_factory = session_factory
        self.settings = settings
        self.aggregator = aggregator

    async def __call__(
        self,
        handler: Callable[[TelegramObject, dict[str, Any]], Awaitable[Any]],
        event: TelegramObject,
        data: dict[str, Any],
    ) -> Any:
        async with self.session_factory() as session:
            data["session"] = session
            data["settings"] = self.settings
            data["aggregator"] = self.aggregator
            try:
                return await handler(event, data)
            except Exception:
                await session.rollback()
                raise
