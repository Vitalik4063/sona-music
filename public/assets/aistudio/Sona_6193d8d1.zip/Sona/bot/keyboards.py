from __future__ import annotations

from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup, WebAppInfo

from backend.config import Settings
from backend.models import Playlist, Track, User
from bot.utils import external_buttons


def webapp_path_button(
    settings: Settings,
    text: str,
    path: str = "/",
    *,
    row_only: bool = False,
) -> InlineKeyboardButton | None:
    if not settings.public_webapp_url.startswith("https://"):
        return None
    base = settings.webapp_base
    url = f"{base}{path}" if path != "/" else base
    return InlineKeyboardButton(text=text, web_app=WebAppInfo(url=url))


def main_keyboard(settings: Settings, user: User | None = None) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    app = webapp_path_button(settings, "▶️  Открыть Sona", "/")
    if app:
        rows.append([app])
    else:
        rows.append(
            [InlineKeyboardButton(text="▶️  Открыть Sona", callback_data="webapp_info")]
        )
    rows.append(
        [
            InlineKeyboardButton(text="🔎  Найти трек", callback_data="search"),
            InlineKeyboardButton(text="🎧  Плейлисты", callback_data="playlists"),
        ]
    )
    rows.append(
        [
            InlineKeyboardButton(text="👤  Профиль", callback_data="profile"),
            InlineKeyboardButton(text="⚙️  Настройки", callback_data="settings"),
        ]
    )
    rows.append(
        [
            InlineKeyboardButton(
                text="🔗  Поделиться профилем", callback_data="share_profile"
            )
        ]
    )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def track_card_keyboard(
    settings: Settings,
    track: Track,
    liked: bool,
    *,
    include_external: bool = True,
    back_to: str | None = None,
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    rows.append(
        [
            InlineKeyboardButton(
                text="💚  В избранном" if liked else "❤️  В избранное",
                callback_data=f"like:{track.id}",
            ),
            InlineKeyboardButton(text="➕  В плейлист", callback_data=f"add:{track.id}"),
        ]
    )
    if include_external:
        sources = external_buttons(track)
        if sources:
            rows.append(sources)
    app = webapp_path_button(settings, "Открыть Sona", "/")
    if app:
        rows.append([app])
    if back_to:
        rows.append([InlineKeyboardButton(text="← Назад", callback_data=back_to)])
    return InlineKeyboardMarkup(inline_keyboard=rows)


def playlists_keyboard(playlists: list[Playlist], track_id: int | None = None):
    rows = []
    for playlist in playlists:
        if track_id is not None:
            rows.append(
                [
                    InlineKeyboardButton(
                        text=f"＋ {playlist.title}"[:60],
                        callback_data=f"addp:{playlist.id}:{track_id}",
                    )
                ]
            )
        else:
            rows.append(
                [
                    InlineKeyboardButton(
                        text=f"🎵 {playlist.title}"[:60],
                        callback_data=f"pl:{playlist.id}",
                    )
                ]
            )
    if track_id is not None:
        rows.append(
            [
                InlineKeyboardButton(
                    text="✦  Создать плейлист",
                    callback_data=f"newpl:{track_id}",
                )
            ]
        )
    return InlineKeyboardMarkup(inline_keyboard=rows)


def request_actions(request_id: int) -> InlineKeyboardMarkup:
    return InlineKeyboardMarkup(
        inline_keyboard=[
            [
                InlineKeyboardButton(
                    text="✅ Принять", callback_data=f"access_ok:{request_id}"
                ),
                InlineKeyboardButton(
                    text="✖️ Отклонить", callback_data=f"access_no:{request_id}"
                ),
            ]
        ]
    )


def settings_keyboard(settings: Settings, privacy: str, pending: int = 0):
    rows = [
        [
            InlineKeyboardButton(
                text=f"{'●' if privacy == 'public' else '○'}  Открыт",
                callback_data="privacy:public",
            ),
            InlineKeyboardButton(
                text=f"{'●' if privacy == 'selected' else '○'}  По заявке",
                callback_data="privacy:selected",
            ),
            InlineKeyboardButton(
                text=f"{'●' if privacy == 'private' else '○'}  Закрыт",
                callback_data="privacy:private",
            ),
        ],
        [
            InlineKeyboardButton(
                text=f"🔔  Заявки ({pending})" if pending else "🔔  Заявки",
                callback_data="requests",
            )
        ],
    ]
    app = webapp_path_button(settings, "⚙️  Все настройки", "/settings")
    if app:
        rows.append([app])
    rows.append([InlineKeyboardButton(text="← В меню", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)
