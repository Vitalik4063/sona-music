from __future__ import annotations

import html
from urllib.parse import urlencode

from aiogram.types import InlineKeyboardButton
from sqlalchemy.ext.asyncio import AsyncSession

from backend.auth import upsert_telegram_user
from backend.config import Settings
from backend.models import Track, User
from backend.services.music.base import SERVICE_LABELS


def esc(value: str | None) -> str:
    return html.escape(value or "", quote=False)


def fmt_duration(ms: int) -> str:
    if not ms:
        return "—"
    total_seconds = round(ms / 1000)
    minutes, seconds = divmod(total_seconds, 60)
    return f"{minutes}:{seconds:02d}"


def privacy_label(privacy: str) -> str:
    return {
        "public": "Открыт всем",
        "selected": "Только избранные",
        "private": "Закрыт",
    }.get(privacy, privacy)


async def ensure_user(session: AsyncSession, tg_user) -> User:
    user = await upsert_telegram_user(
        session,
        {
            "id": tg_user.id,
            "username": tg_user.username,
            "first_name": tg_user.first_name,
            "last_name": tg_user.last_name,
            "photo_url": None,
        },
    )
    await session.commit()
    await session.refresh(user)
    return user


def absolute_art(settings: Settings, track: Track) -> str | None:
    return settings.absolute_url(track.artwork_url)


def external_buttons(track: Track) -> list[InlineKeyboardButton]:
    buttons: list[InlineKeyboardButton] = []
    order = ["deezer", "itunes", "spotify", "youtube"]
    links = track.links or {}
    for service in order:
        url = links.get(service)
        if url and url.startswith("http"):
            buttons.append(
                InlineKeyboardButton(
                    text=f"Открыть в {SERVICE_LABELS.get(service, service)}", url=url
                )
            )
        if len(buttons) == 2:
            break
    return buttons


def profile_share_url(settings: Settings, token: str) -> str:
    return f"https://t.me/{settings.bot_username}?startapp=u_{token}"


def profile_web_url(settings: Settings, token: str) -> str:
    return f"{settings.webapp_base}/u/{token}"


def share_dialog_url(settings: Settings, token: str, name: str) -> str:
    link = profile_share_url(settings, token)
    text = f"Послушай мою музыку в Sona — {name}"
    return f"https://t.me/share/url?{urlencode({'url': link, 'text': text})}"
