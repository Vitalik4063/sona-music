from __future__ import annotations

import asyncio
import logging

from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.types import (
    BotCommand,
    BotCommandScopeDefault,
    MenuButtonWebApp,
    WebAppInfo,
)

from backend.config import get_settings
from backend.db import create_engine, create_schema, create_session_factory
from backend.seed import seed_demo_data
from backend.services.music.aggregator import SearchAggregator
from bot.handlers import common, inline, library, profile, search
from bot.middleware import SonaMiddleware

logger = logging.getLogger("sona.bot")

COMMANDS = [
    BotCommand(command="start", description="Главное меню"),
    BotCommand(command="app", description="Открыть Sona"),
    BotCommand(command="search", description="Найти трек"),
    BotCommand(command="library", description="Мои плейлисты"),
    BotCommand(command="likes", description="Избранное"),
    BotCommand(command="profile", description="Профиль и ссылка"),
    BotCommand(command="settings", description="Доступ к профилю"),
    BotCommand(command="help", description="Помощь"),
]


async def main() -> None:
    settings = get_settings()
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s %(levelname)s %(name)s: %(message)s",
    )
    if not settings.bot_is_configured:
        logger.error(
            "BOT_TOKEN не настроен. Скопируйте .env.example в .env и вставьте токен от @BotFather."
        )
        return

    engine = create_engine(settings.database_url)
    await create_schema(engine)
    session_factory = create_session_factory(engine)
    async with session_factory() as session:
        await seed_demo_data(session, settings)

    bot = Bot(
        token=settings.bot_token,
        default=DefaultBotProperties(
            parse_mode=ParseMode.HTML,
            link_preview_is_disabled=True,
        ),
    )
    aggregator = SearchAggregator(settings)
    dp = Dispatcher(storage=MemoryStorage())
    dp.update.middleware(SonaMiddleware(session_factory, settings, aggregator))
    dp.include_router(common.router)
    dp.include_router(profile.router)
    dp.include_router(search.router)
    dp.include_router(library.router)
    dp.include_router(inline.router)

    try:
        await bot.set_my_commands(COMMANDS, scope=BotCommandScopeDefault())
        if settings.public_webapp_url.startswith("https://"):
            await bot.set_chat_menu_button(
                menu_button=MenuButtonWebApp(
                    text="Sona",
                    web_app=WebAppInfo(url=settings.webapp_base),
                )
            )
        else:
            logger.warning(
                "PUBLIC_WEBAPP_URL не HTTPS — кнопка Mini App и меню отключены. "
                "Для локальной проверки используйте ngrok/cloudflared."
            )
        me = await bot.get_me()
        logger.info("Bot @%s is polling. Mini App: %s", me.username, settings.webapp_base)
        await bot.delete_webhook(drop_pending_updates=False)
        await dp.start_polling(
            bot,
            allowed_updates=dp.resolve_used_update_types(),
            drop_pending_updates=False,
        )
    finally:
        await bot.session.close()
        await engine.dispose()


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, SystemExit):
        logger.info("Bot stopped")
