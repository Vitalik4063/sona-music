from __future__ import annotations

from aiogram import Bot
from aiogram.exceptions import TelegramAPIError, TelegramBadRequest
from aiogram.types import (
    FSInputFile,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
)
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import BASE_DIR, Settings
from backend.models import Like, Playlist, PlaylistTrack, Track, User
from backend.services.access import resolve_access, visible_playlists
from bot.keyboards import main_keyboard, track_card_keyboard, webapp_path_button
from bot.utils import (
    esc,
    fmt_duration,
    privacy_label,
    profile_share_url,
    profile_web_url,
    share_dialog_url,
)

WELCOME_IMAGE = BASE_DIR / "backend" / "static" / "brand" / "welcome-1200.jpg"


async def _send_photo_or_text(
    bot: Bot,
    chat_id: int,
    photo_url: str | None,
    text: str,
    reply_markup: InlineKeyboardMarkup | None,
    *,
    local_photo: FSInputFile | None = None,
) -> None:
    photo = local_photo or photo_url
    if photo:
        try:
            await bot.send_photo(
                chat_id=chat_id,
                photo=photo,
                caption=text,
                reply_markup=reply_markup,
                parse_mode="HTML",
            )
            return
        except (TelegramAPIError, TelegramBadRequest):
            pass
    try:
        await bot.send_message(
            chat_id=chat_id,
            text=text,
            reply_markup=reply_markup,
            disable_web_page_preview=True,
        )
    except TelegramBadRequest:
        await bot.send_message(
            chat_id=chat_id,
            text=text[:4000],
            reply_markup=reply_markup,
            disable_web_page_preview=True,
        )


async def send_welcome(
    bot: Bot,
    chat_id: int,
    user: User,
    settings: Settings,
    *,
    with_image: bool = True,
) -> None:
    text = (
        f"<b>Привет, {esc(user.first_name)}.</b>\n\n"
        "Это <b>Sona</b> — тихое место для громкой музыки.\n\n"
        "🎧 Собирай плейлисты и любимые треки\n"
        "🔎 Ищи одновременно в Apple Music, Deezer, Spotify и YouTube\n"
        "🔗 Делись профилем — целиком или только с избранными\n"
        "📨 Пересылай треки в любой чат через инлайн-режим\n\n"
        "<i>Начни с поиска или открой мини-приложение.</i>"
    )
    local = FSInputFile(WELCOME_IMAGE) if with_image and WELCOME_IMAGE.exists() else None
    await _send_photo_or_text(
        bot,
        chat_id,
        None,
        text,
        main_keyboard(settings, user),
        local_photo=local,
    )


async def send_main_menu(
    bot: Bot, chat_id: int, user: User, settings: Settings, *, edit_message=None
) -> None:
    text = (
        f"🎧 <b>Sona</b> · {esc(user.first_name)}\n\n"
        "Выбирай, с чего продолжить:"
    )
    if edit_message is not None:
        try:
            await edit_message.edit_text(
                text=text,
                reply_markup=main_keyboard(settings, user),
                disable_web_page_preview=True,
            )
            return
        except TelegramBadRequest:
            pass
    await bot.send_message(
        chat_id=chat_id,
        text=text,
        reply_markup=main_keyboard(settings, user),
        disable_web_page_preview=True,
    )


async def send_track(
    bot: Bot,
    chat_id: int,
    track: Track,
    user: User,
    session: AsyncSession,
    settings: Settings,
    *,
    prefix: str = "",
) -> None:
    liked = bool(
        await session.scalar(
            select(Like).where(Like.user_id == user.id, Like.track_id == track.id)
        )
    )
    sources = ", ".join(track.sources or [])
    caption = prefix
    caption += f"<b>{esc(track.title)}</b>\n{esc(track.artist)}"
    if track.album:
        caption += f" · <i>{esc(track.album)}</i>"
    caption += f"\n\n⏱ {fmt_duration(track.duration_ms)}"
    if track.is_demo:
        caption += " · Sona Sessions"
    if sources and not track.is_demo:
        caption += f"\n🌐 {esc(sources)}"
    if not track.preview_url:
        caption += "\n\n<i>Превью недоступно — полная версия откроется в сервисе.</i>"

    keyboard = track_card_keyboard(settings, track, liked)

    if track.preview_url:
        audio_url = settings.absolute_url(track.preview_url)
        if audio_url:
            try:
                await bot.send_audio(
                    chat_id=chat_id,
                    audio=audio_url,
                    title=track.title[:64],
                    performer=track.artist[:64],
                    duration=max(1, round(track.duration_ms / 1000)),
                    caption=caption[:1024],
                    reply_markup=keyboard,
                )
                return
            except (TelegramAPIError, TelegramBadRequest):
                pass

    art = settings.absolute_url(track.artwork_url)
    await _send_photo_or_text(bot, chat_id, art, caption, keyboard)


async def send_search_results(
    bot: Bot,
    chat_id: int,
    tracks: list[Track],
    user: User,
    session: AsyncSession,
    settings: Settings,
    query: str,
    providers: list[str],
    *,
    note: str = "",
) -> None:
    if not tracks:
        await bot.send_message(
            chat_id=chat_id,
            text=(
                f"По запросу «<b>{esc(query)}</b>» ничего не нашлось.\n\n"
                "Попробуй другое написание, название трека или исполнителя."
            ),
            reply_markup=main_keyboard(settings, user),
        )
        return

    lines = [
        f"🔎 <b>{esc(query)}</b>",
        f"<i>{len(tracks)} результатов · {esc(', '.join(providers))}</i>",
        "",
    ]
    for index, track in enumerate(tracks[:8], start=1):
        mark = "💚 " if index == 1 else f"{index}. "
        lines.append(
            f"{mark}<b>{esc(track.title)}</b> — {esc(track.artist)} "
            f"<i>· {fmt_duration(track.duration_ms)}</i>"
        )
    if note:
        lines.extend(["", f"<i>{esc(note)}</i>"])
    lines.extend(["", "Выбери трек, чтобы послушать превью и сохранить:"])

    rows: list[list[InlineKeyboardButton]] = []
    for index, track in enumerate(tracks[:8], start=1):
        title = f"▶️ {index}. {track.title}"
        if len(title) > 52:
            title = title[:49] + "…"
        rows.append(
            [InlineKeyboardButton(text=title, callback_data=f"track:{track.id}")]
        )
    app = webapp_path_button(settings, "🔎 Открыть поиск в Sona", "/search")
    if app:
        rows.append([app])
    rows.append([InlineKeyboardButton(text="← В меню", callback_data="menu")])

    await bot.send_message(
        chat_id=chat_id,
        text="\n".join(lines),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
        disable_web_page_preview=True,
    )


async def send_profile(
    bot: Bot,
    chat_id: int,
    owner: User,
    viewer: User,
    session: AsyncSession,
    settings: Settings,
    *,
    prefix: str = "",
) -> None:
    access = await resolve_access(session, owner, viewer)
    is_owner = owner.id == viewer.id
    can_view = access.can_view
    owner_name = esc(owner.display_name)
    username = f"@{esc(owner.username)}" if owner.username else ""

    lines = [prefix] if prefix else []
    if is_owner:
        lines.append(f"👤 <b>Твой профиль</b>\n\n<b>{owner_name}</b>")
    else:
        lines.append(f"<b>{owner_name}</b>")
    if username:
        lines.append(f"<i>{username}</i>")
    if owner.bio:
        lines.extend(["", esc(owner.bio)])
    lines.extend(["", f"🔐 <i>{privacy_label(owner.privacy)}</i>"])

    if can_view:
        show_playlists = is_owner or owner.show_playlists
        playlists_count = 0
        track_count = 0
        if show_playlists:
            playlist_filters = [Playlist.owner_id == owner.id]
            if not is_owner:
                playlist_filters.append(Playlist.is_public.is_(True))
            playlists_count = int(
                await session.scalar(
                    select(func.count())
                    .select_from(Playlist)
                    .where(*playlist_filters)
                )
                or 0
            )
            track_count = int(
                await session.scalar(
                    select(func.count())
                    .select_from(PlaylistTrack)
                    .join(Playlist, Playlist.id == PlaylistTrack.playlist_id)
                    .where(*playlist_filters)
                )
                or 0
            )

        summary = (
            f"🎵 <b>{track_count}</b> треков · "
            f"<b>{playlists_count}</b> плейлистов"
        )
        if is_owner or owner.show_liked:
            liked_count = int(
                await session.scalar(
                    select(func.count()).select_from(Like).where(Like.user_id == owner.id)
                )
                or 0
            )
            summary += f" · <b>{liked_count}</b> в избранном"
        lines.extend(["", summary])
        if is_owner:
            lines.extend(["", "🔗 <i>Ссылка на профиль готова — отправь её друзьям.</i>"])
    else:
        if access.access == "private":
            lines.extend(
                ["", "🔒 <b>Профиль закрыт.</b>", "Владелец не открывает музыку для просмотра."]
            )
        else:
            request_note = {
                "pending": "Заявка уже отправлена. Осталось дождаться ответа.",
                "declined": "Предыдущая заявка была отклонена.",
                "approved": "Доступ должен быть открыт — обнови профиль.",
            }.get(access.request_status or "", "Отправь заявку — владелец решит, открыть ли доступ.")
            lines.extend(["", "🔒 <b>Профиль доступен по заявке.</b>", esc(request_note)])

    rows: list[list[InlineKeyboardButton]] = []
    if can_view:
        app = webapp_path_button(settings, "🎧 Открыть профиль в Sona", f"/u/{owner.share_token}")
        if app:
            rows.append([app])
        else:
            rows.append(
                [
                    InlineKeyboardButton(
                        text="Скопировать ссылку", callback_data=f"copy_share:{owner.share_token}"
                    )
                ]
            )
    elif access.can_request:
        rows.append(
            [
                InlineKeyboardButton(
                    text="✉️ Запросить доступ", callback_data=f"req:{owner.share_token}"
                )
            ]
        )
    elif access.request_status == "pending":
        rows.append(
            [InlineKeyboardButton(text="⏳ Заявка отправлена", callback_data="noop")]
        )

    if is_owner:
        rows.append(
            [
                InlineKeyboardButton(
                    text="📨 Поделиться профилем", callback_data="share_profile"
                )
            ]
        )
        rows.append(
            [
                InlineKeyboardButton(
                    text="⚙️ Настройки доступа", callback_data="settings"
                )
            ]
        )

    art = settings.absolute_url(owner.photo_url)
    await _send_photo_or_text(
        bot, chat_id, art, "\n".join(lines), InlineKeyboardMarkup(inline_keyboard=rows)
    )


def share_text(user: User, settings: Settings) -> tuple[str, InlineKeyboardMarkup]:
    link = profile_share_url(settings, user.share_token)
    web_link = profile_web_url(settings, user.share_token)
    text = (
        "🔗 <b>Твой профиль готов к отправке</b>\n\n"
        f"Доступ: <b>{privacy_label(user.privacy)}</b>\n"
        f"<code>{link}</code>\n\n"
        "Ссылка откроет твой профиль в Sona. Внутри можно будет посмотреть "
        "плейлисты, избранное и попросить доступ, если профиль закрыт."
    )
    rows = [
        [
            InlineKeyboardButton(
                text="📨 Отправить в чат",
                url=share_dialog_url(settings, user.share_token, user.display_name),
            )
        ],
        [
            InlineKeyboardButton(
                text="🌐 Открыть веб-версию", url=web_link
            )
        ],
        [InlineKeyboardButton(text="⚙️ Настроить доступ", callback_data="settings")],
        [InlineKeyboardButton(text="← В меню", callback_data="menu")],
    ]
    return text, InlineKeyboardMarkup(inline_keyboard=rows)
