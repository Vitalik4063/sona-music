from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.exceptions import TelegramBadRequest
from aiogram.filters import Command, CommandStart
from aiogram.fsm.context import FSMContext
from aiogram.types import CallbackQuery, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import Settings
from backend.models import AccessRequest, AllowedViewer, Track, User
from backend.models import utcnow
from backend.services.access import resolve_access
from bot.keyboards import main_keyboard, request_actions, webapp_path_button
from bot.utils import ensure_user, esc, profile_share_url, share_dialog_url
from bot.views import send_main_menu, send_profile, send_track, send_welcome, share_text

router = Router(name="common")


@router.message(CommandStart())
async def start(
    message: Message,
    state: FSMContext,
    bot: Bot,
    session: AsyncSession,
    settings: Settings,
) -> None:
    await state.clear()
    user = await ensure_user(session, message.from_user)
    args = (message.text or "").split(maxsplit=1)
    payload = args[1].strip() if len(args) > 1 else ""

    if payload.startswith("u_"):
        token = payload[2:]
        owner = await session.scalar(select(User).where(User.share_token == token))
        if owner:
            await send_profile(
                bot,
                message.chat.id,
                owner,
                user,
                session,
                settings,
                prefix="🔗 <b>Тебе открыли профиль</b>\n\n",
            )
            return
        await message.answer("Профиль не найден. Возможно, ссылка устарела.")
        return

    if payload.startswith("track_"):
        try:
            track_id = int(payload[6:])
        except ValueError:
            track_id = 0
        track = await session.get(Track, track_id)
        if track:
            await send_track(bot, message.chat.id, track, user, session, settings)
            return

    await send_welcome(bot, message.chat.id, user, settings)


@router.message(Command("help"))
async def help_command(message: Message, session: AsyncSession, settings: Settings) -> None:
    user = await ensure_user(session, message.from_user)
    text = (
        "<b>Sona — музыка в Telegram</b>\n\n"
        "/app — открыть мини-приложение\n"
        "/search — найти трек\n"
        "/likes — избранное\n"
        "/library — плейлисты\n"
        "/profile — профиль и ссылка\n"
        "/settings — доступ к профилю\n\n"
        "📨 <b>Как переслать трек в диалог</b>\n"
        "Напиши в любом чате <code>@"
        + esc(settings.bot_username)
        + " название трека</code> — бот предложит аудио и карточку. "
        "Выбери нужное, и трек отправится прямо в чат.\n\n"
        "Кнопки добавления в избранное и плейлист доступны под каждым треком."
    )
    rows = []
    app = webapp_path_button(settings, "▶️ Открыть Sona", "/")
    if app:
        rows.append([app])
    rows.append([__import__("aiogram").types.InlineKeyboardButton(
        text="← В меню", callback_data="menu"
    )])
    from aiogram.types import InlineKeyboardMarkup

    await message.answer(
        text,
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows) if rows else main_keyboard(settings, user),
        disable_web_page_preview=True,
    )


@router.message(Command("app"))
async def app_command(message: Message, session: AsyncSession, settings: Settings) -> None:
    await ensure_user(session, message.from_user)
    app = webapp_path_button(settings, "🎧 Открыть Sona", "/")
    if app:
        from aiogram.types import InlineKeyboardMarkup

        await message.answer(
            "Открой мини-приложение Sona:",
            reply_markup=InlineKeyboardMarkup(inline_keyboard=[[app]]),
        )
    else:
        await message.answer(
            "Мини-приложение откроется после настройки HTTPS-адреса.\n\n"
            "Для локального запуска выполните <code>ngrok http 5173</code> и укажите "
            "полученный адрес в <code>PUBLIC_WEBAPP_URL</code>."
        )


@router.callback_query(F.data == "menu")
async def menu_callback(
    callback: CallbackQuery, bot: Bot, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    await send_main_menu(
        bot,
        callback.message.chat.id,
        user,
        settings,
        edit_message=callback.message,
    )


@router.callback_query(F.data == "webapp_info")
async def webapp_info(callback: CallbackQuery, settings: Settings) -> None:
    await callback.answer(
        "Для Mini App нужен HTTPS-адрес. Укажите его в PUBLIC_WEBAPP_URL.",
        show_alert=True,
    )


@router.callback_query(F.data == "noop")
async def noop(callback: CallbackQuery) -> None:
    await callback.answer()


@router.callback_query(F.data == "share_profile")
async def share_profile_callback(
    callback: CallbackQuery, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    text, keyboard = share_text(user, settings)
    try:
        await callback.message.edit_text(
            text, reply_markup=keyboard, disable_web_page_preview=True
        )
    except TelegramBadRequest:
        await callback.message.answer(
            text, reply_markup=keyboard, disable_web_page_preview=True
        )


@router.callback_query(F.data.startswith("copy_share:"))
async def copy_share_link(
    callback: CallbackQuery, session: AsyncSession, settings: Settings
) -> None:
    token = callback.data.split(":", 1)[1]
    user = await ensure_user(session, callback.from_user)
    from aiogram.types import InlineKeyboardButton, InlineKeyboardMarkup

    link = profile_share_url(settings, token)
    await callback.answer("Ссылка отправлена сообщением")
    await callback.message.answer(
        f"🔗 <code>{esc(link)}</code>",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(
                        text="📨 Отправить в чат",
                        url=share_dialog_url(settings, token, user.display_name),
                    )
                ]
            ]
        ),
        disable_web_page_preview=True,
    )


@router.callback_query(F.data.startswith("req:"))
async def request_access(
    callback: CallbackQuery,
    bot: Bot,
    session: AsyncSession,
    settings: Settings,
) -> None:
    token = callback.data.split(":", 1)[1]
    viewer = await ensure_user(session, callback.from_user)
    owner = await session.scalar(select(User).where(User.share_token == token))
    if owner is None:
        await callback.answer("Профиль не найден", show_alert=True)
        return
    if owner.id == viewer.id:
        await callback.answer("Это твой профиль", show_alert=True)
        return
    access = await resolve_access(session, owner, viewer)
    if access.can_view:
        await callback.answer("Доступ уже открыт", show_alert=True)
        return
    if owner.privacy == "private":
        await callback.answer("Владелец закрыл профиль для всех", show_alert=True)
        return
    if access.request_status == "pending":
        await callback.answer("Заявка уже отправлена", show_alert=True)
        return

    access_request = AccessRequest(
        owner_id=owner.id, requester_id=viewer.id, status="pending"
    )
    session.add(access_request)
    await session.commit()
    await session.refresh(access_request)
    await callback.answer("Заявка отправлена ✨", show_alert=True)

    text = (
        "🔔 <b>Новая заявка в Sona</b>\n\n"
        f"<b>{esc(viewer.display_name)}</b>"
        + (f" ({esc('@' + viewer.username)})" if viewer.username else "")
        + " просит доступ к твоему музыкальному профилю."
    )
    try:
        await bot.send_message(
            chat_id=owner.telegram_id,
            text=text,
            reply_markup=request_actions(access_request.id),
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("access_ok:"))
async def approve_access(
    callback: CallbackQuery,
    bot: Bot,
    session: AsyncSession,
    settings: Settings,
) -> None:
    request_id = int(callback.data.split(":", 1)[1])
    owner = await ensure_user(session, callback.from_user)
    access_request = await session.scalar(
        select(AccessRequest).where(
            AccessRequest.id == request_id, AccessRequest.owner_id == owner.id
        )
    )
    if access_request is None or access_request.status != "pending":
        await callback.answer("Заявка уже обработана", show_alert=True)
        return
    access_request.status = "approved"
    access_request.decided_at = utcnow()
    if owner.privacy == "private":
        owner.privacy = "selected"
    requester = await session.get(User, access_request.requester_id)
    existing = await session.scalar(
        select(AllowedViewer).where(
            AllowedViewer.owner_id == owner.id,
            AllowedViewer.identifier_type == "telegram_id",
            AllowedViewer.identifier_value == str(requester.telegram_id),
        )
    )
    if existing is None:
        session.add(
            AllowedViewer(
                owner_id=owner.id,
                identifier_type="telegram_id",
                identifier_value=str(requester.telegram_id),
                display_name=requester.display_name,
            )
        )
    await session.commit()
    await callback.answer("Доступ открыт")
    try:
        await callback.message.edit_text(
            f"✅ Заявка от <b>{esc(requester.display_name)}</b> принята. Доступ открыт.",
            disable_web_page_preview=True,
        )
    except TelegramBadRequest:
        pass
    try:
        await bot.send_message(
            chat_id=requester.telegram_id,
            text=(
                "✅ <b>Доступ открыт</b>\n\n"
                f"<b>{esc(owner.display_name)}</b> открыл(а) тебе свой музыкальный профиль."
            ),
            reply_markup=None,
        )
        await bot.send_message(
            chat_id=requester.telegram_id,
            text=f"https://t.me/{settings.bot_username}?startapp=u_{owner.share_token}",
        )
    except Exception:
        pass


@router.callback_query(F.data.startswith("access_no:"))
async def decline_access(
    callback: CallbackQuery, session: AsyncSession
) -> None:
    request_id = int(callback.data.split(":", 1)[1])
    owner = await ensure_user(session, callback.from_user)
    access_request = await session.scalar(
        select(AccessRequest).where(
            AccessRequest.id == request_id, AccessRequest.owner_id == owner.id
        )
    )
    if access_request is None or access_request.status != "pending":
        await callback.answer("Заявка уже обработана", show_alert=True)
        return
    access_request.status = "declined"
    access_request.decided_at = utcnow()
    await session.commit()
    await callback.answer("Заявка отклонена")
    try:
        await callback.message.edit_text("✖️ Заявка отклонена.")
    except TelegramBadRequest:
        pass
