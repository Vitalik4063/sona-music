from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.fsm.context import FSMContext
from aiogram.fsm.state import State, StatesGroup
from aiogram.types import (
    CallbackQuery,
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    Message,
)
from sqlalchemy import delete, or_, select
from sqlalchemy.ext.asyncio import AsyncSession, async_sessionmaker

from backend.config import Settings
from backend.models import Like, Playlist, PlaylistTrack, Track, User
from backend.services.music.aggregator import SearchAggregator
from backend.services.serializers import track_out
from bot.keyboards import (
    main_keyboard,
    playlists_keyboard,
    track_card_keyboard,
    webapp_path_button,
)
from bot.utils import ensure_user, esc
from bot.views import send_search_results, send_track

router = Router(name="search")


class SearchFlow(StatesGroup):
    waiting = State()


class NewPlaylistFlow(StatesGroup):
    waiting_name = State()


async def _demo_fallback(session: AsyncSession, query: str) -> list[Track]:
    result = await session.execute(
        select(Track)
        .where(
            Track.is_demo.is_(True),
            or_(
                Track.title.ilike(f"%{query}%"),
                Track.artist.ilike(f"%{query}%"),
            ),
        )
        .limit(10)
    )
    return list(result.scalars())


@router.message(Command("search"))
async def search_command(message: Message, state: FSMContext) -> None:
    await state.set_state(SearchFlow.waiting)
    await message.answer(
        "🔎 <b>Что ищем?</b>\n\n"
        "Напиши название трека или исполнителя — я проверю Apple Music, Deezer, "
        "Spotify и YouTube одновременно.",
        reply_markup=InlineKeyboardMarkup(
            inline_keyboard=[
                [InlineKeyboardButton(text="Отмена", callback_data="cancel_search")]
            ]
        ),
    )


@router.callback_query(F.data == "search")
async def search_callback(callback: CallbackQuery, state: FSMContext) -> None:
    await state.set_state(SearchFlow.waiting)
    await callback.answer()
    try:
        await callback.message.edit_text(
            "🔎 <b>Что ищем?</b>\n\n"
            "Напиши название трека или исполнителя — проверю сразу несколько сервисов.",
            reply_markup=InlineKeyboardMarkup(
                inline_keyboard=[
                    [InlineKeyboardButton(text="Отмена", callback_data="cancel_search")]
                ]
            ),
        )
    except Exception:
        await callback.message.answer("🔎 Напиши название трека или исполнителя.")


@router.callback_query(F.data == "cancel_search")
async def cancel_search(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession, settings: Settings
) -> None:
    await state.clear()
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    try:
        await callback.message.edit_text(
            "Поиск отменён.",
            reply_markup=main_keyboard(settings, user),
        )
    except Exception:
        pass


@router.message(SearchFlow.waiting)
async def run_search(
    message: Message,
    state: FSMContext,
    bot: Bot,
    session: AsyncSession,
    settings: Settings,
    aggregator: SearchAggregator,
) -> None:
    query = (message.text or "").strip()
    if len(query) < 2:
        await message.answer("Слишком короткий запрос. Напиши хотя бы два символа.")
        return
    await state.clear()
    user = await ensure_user(session, message.from_user)
    status = await message.answer("🎧 Слушаю все сервисы сразу…")

    result = await aggregator.search(query, limit=24)
    tracks = []
    if result.tracks:
        from backend.services.tracks import upsert_candidates

        tracks = await upsert_candidates(session, result.tracks)
    providers = list(result.providers_used)
    if not tracks:
        tracks = await _demo_fallback(session, query)
        providers = ["Sona"] if tracks else []
    await session.commit()

    try:
        await status.delete()
    except Exception:
        pass
    await send_search_results(
        bot,
        message.chat.id,
        tracks,
        user,
        session,
        settings,
        query,
        providers or ["Sona"],
        note="Полные результаты и фильтры — в мини-приложении.",
    )


@router.callback_query(F.data.startswith("track:"))
async def show_track(
    callback: CallbackQuery, bot: Bot, session: AsyncSession, settings: Settings
) -> None:
    track_id = int(callback.data.split(":", 1)[1])
    track = await session.get(Track, track_id)
    if track is None:
        await callback.answer("Трек уже недоступен", show_alert=True)
        return
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    await send_track(bot, callback.message.chat.id, track, user, session, settings)


@router.callback_query(F.data.startswith("like:"))
async def toggle_like(
    callback: CallbackQuery, session: AsyncSession, settings: Settings
) -> None:
    track_id = int(callback.data.split(":", 1)[1])
    track = await session.get(Track, track_id)
    if track is None:
        await callback.answer("Трек не найден", show_alert=True)
        return
    user = await ensure_user(session, callback.from_user)
    existing = await session.get(Like, (user.id, track_id))
    if existing:
        await session.delete(existing)
        liked = False
        text = "Убрал из избранного"
    else:
        session.add(Like(user_id=user.id, track_id=track_id))
        liked = True
        text = "Добавил в избранное 💚"
    await session.commit()
    await callback.answer(text)
    try:
        await callback.message.edit_reply_markup(
            reply_markup=track_card_keyboard(settings, track, liked)
        )
    except Exception:
        pass


async def _send_playlist_picker(
    callback: CallbackQuery,
    track_id: int,
    session: AsyncSession,
) -> None:
    user = await ensure_user(session, callback.from_user)
    result = await session.execute(
        select(Playlist)
        .where(Playlist.owner_id == user.id)
        .order_by(Playlist.updated_at.desc())
        .limit(20)
    )
    playlists = list(result.scalars())
    text = "➕ <b>Куда добавить трек?</b>"
    if not playlists:
        text += "\n\nПлейлистов пока нет. Создай первый — это займёт секунду."
    await callback.answer()
    try:
        await callback.message.edit_text(
            text, reply_markup=playlists_keyboard(playlists, track_id=track_id)
        )
    except Exception:
        await callback.message.answer(
            text, reply_markup=playlists_keyboard(playlists, track_id=track_id)
        )


@router.callback_query(F.data.startswith("add:"))
async def show_add_picker(
    callback: CallbackQuery, session: AsyncSession
) -> None:
    track_id = int(callback.data.split(":", 1)[1])
    await _send_playlist_picker(callback, track_id, session)


@router.callback_query(F.data.startswith("addp:"))
async def add_to_playlist(
    callback: CallbackQuery, session: AsyncSession
) -> None:
    _, playlist_id_raw, track_id_raw = callback.data.split(":")
    playlist_id, track_id = int(playlist_id_raw), int(track_id_raw)
    user = await ensure_user(session, callback.from_user)
    playlist = await session.get(Playlist, playlist_id)
    track = await session.get(Track, track_id)
    if playlist is None or track is None or playlist.owner_id != user.id:
        await callback.answer("Плейлист или трек не найден", show_alert=True)
        return
    existing = await session.get(PlaylistTrack, (playlist_id, track_id))
    if existing:
        await callback.answer(f"Уже есть в «{playlist.title}»", show_alert=True)
        return
    max_position = await session.scalar(
        select(PlaylistTrack.position)
        .where(PlaylistTrack.playlist_id == playlist_id)
        .order_by(PlaylistTrack.position.desc())
        .limit(1)
    )
    session.add(
        PlaylistTrack(
            playlist_id=playlist_id,
            track_id=track_id,
            position=(int(max_position) + 1) if max_position is not None else 0,
        )
    )
    await session.commit()
    await callback.answer(f"Добавлено в «{playlist.title}» ✨", show_alert=True)


@router.callback_query(F.data.startswith("newpl:"))
async def start_new_playlist(
    callback: CallbackQuery, state: FSMContext, session: AsyncSession
) -> None:
    track_id = int(callback.data.split(":", 1)[1])
    await ensure_user(session, callback.from_user)
    await state.set_state(NewPlaylistFlow.waiting_name)
    await state.update_data(track_id=track_id)
    await callback.answer()
    await callback.message.answer(
        "✦ <b>Новый плейлист</b>\n\nКак его назвать? Напиши название одним сообщением."
    )


@router.message(NewPlaylistFlow.waiting_name)
async def create_playlist_with_track(
    message: Message,
    state: FSMContext,
    session: AsyncSession,
    settings: Settings,
) -> None:
    title = (message.text or "").strip()
    if not 1 <= len(title) <= 120:
        await message.answer("Название должно быть от 1 до 120 символов. Попробуй ещё раз.")
        return
    data = await state.get_data()
    track_id = data.get("track_id")
    await state.clear()
    user = await ensure_user(session, message.from_user)
    playlist = Playlist(owner_id=user.id, title=title, description="", is_public=True)
    session.add(playlist)
    await session.flush()
    track = await session.get(Track, int(track_id)) if track_id else None
    if track:
        session.add(
            PlaylistTrack(playlist_id=playlist.id, track_id=track.id, position=0)
        )
    await session.commit()
    rows = []
    app = webapp_path_button(settings, "Открыть плейлист", f"/playlist/{playlist.id}")
    if app:
        rows.append([app])
    rows.append([InlineKeyboardButton(text="← В меню", callback_data="menu")])
    await message.answer(
        f"✨ <b>«{esc(title)}»</b> создан и готов к прослушиванию."
        + (" Первый трек уже внутри." if track else ""),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
    )
