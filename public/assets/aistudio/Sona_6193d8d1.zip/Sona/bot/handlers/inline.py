from __future__ import annotations

from html import escape

from aiogram import Router
from aiogram.types import (
    InlineKeyboardButton,
    InlineKeyboardMarkup,
    InlineQuery,
    InlineQueryResultArticle,
    InlineQueryResultAudio,
    InputTextMessageContent,
)
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import Settings
from backend.models import Track, User
from backend.services.music.aggregator import SearchAggregator
from backend.services.tracks import upsert_candidates
from bot.utils import ensure_user, fmt_duration

router = Router(name="inline")


def _track_buttons(bot_username: str, track: Track, settings: Settings):
    rows = [
        [
            InlineKeyboardButton(
                text="🎧 Открыть в Sona",
                url=f"https://t.me/{bot_username}?start=track_{track.id}",
            )
        ]
    ]
    for key in ("deezer", "itunes", "spotify", "youtube"):
        url = (track.links or {}).get(key)
        if url and url.startswith("http"):
            labels = {
                "deezer": "Deezer",
                "itunes": "Apple Music",
                "spotify": "Spotify",
                "youtube": "YouTube Music",
            }
            rows.append([InlineKeyboardButton(text=f"Открыть в {labels[key]}", url=url)])
            break
    return InlineKeyboardMarkup(inline_keyboard=rows)


def _article(track: Track, settings: Settings, bot_username: str) -> InlineQueryResultArticle:
    art = settings.absolute_url(track.artwork_url)
    text = (
        f"🎵 <b>{escape(track.title)}</b>\n"
        f"{escape(track.artist)}"
        + (f" · {escape(track.album)}" if track.album else "")
        + f"\n\n⏱ {fmt_duration(track.duration_ms)}"
        + ("\n🎧 Sona Sessions" if track.is_demo else "")
        + f"\n\n<a href='https://t.me/{bot_username}?start=track_{track.id}'>Слушать в Sona</a>"
    )
    return InlineQueryResultArticle(
        id=f"p{track.id}",
        title=f"{track.title} — {track.artist}",
        description=f"{track.album or 'Трек'} · {fmt_duration(track.duration_ms)}",
        thumbnail_url=art if art and art.startswith("http") else None,
        input_message_content=InputTextMessageContent(
            message_text=text, parse_mode="HTML", disable_web_page_preview=True
        ),
        reply_markup=_track_buttons(bot_username, track, settings),
    )


def _audio(track: Track, settings: Settings, bot_username: str) -> InlineQueryResultAudio | None:
    audio_url = settings.absolute_url(track.preview_url)
    if not audio_url or not audio_url.startswith("http"):
        return None
    caption = (
        f"<b>{escape(track.title)}</b>\n"
        f"{escape(track.artist)}"
        + (f" · {escape(track.album)}" if track.album else "")
        + f"\n\n🎧 Найдено в Sona · {fmt_duration(track.duration_ms)}"
    )
    return InlineQueryResultAudio(
        id=f"a{track.id}",
        audio_url=audio_url,
        title=track.title[:64],
        performer=track.artist[:64],
        audio_duration=max(1, round(track.duration_ms / 1000)),
        caption=caption[:1024],
        parse_mode="HTML",
        reply_markup=_track_buttons(bot_username, track, settings),
    )


@router.inline_query()
async def inline_search(
    query: InlineQuery,
    session: AsyncSession,
    settings: Settings,
    aggregator: SearchAggregator,
) -> None:
    await ensure_user(session, query.from_user)
    raw = (query.query or "").strip()

    if not raw:
        await query.answer(
            results=[
                InlineQueryResultArticle(
                    id="hello",
                    title="Найти музыку в Sona",
                    description="Напиши @бот название трека или исполнителя",
                    input_message_content=InputTextMessageContent(
                        message_text="🎧 Ищу музыку в Sona",
                    ),
                )
            ],
            cache_time=5,
            is_personal=True,
        )
        return

    if raw.startswith("track:"):
        try:
            track_id = int(raw.split(":", 1)[1])
        except ValueError:
            track_id = 0
        track = await session.get(Track, track_id)
        tracks = [track] if track else []
        providers = list(track.sources or []) if track else []
    else:
        result = await aggregator.search(raw, limit=16)
        tracks = await upsert_candidates(session, result.tracks) if result.tracks else []
        providers = result.providers_used
        if not tracks:
            demo = await session.execute(
                select(Track)
                .where(
                    Track.is_demo.is_(True),
                    or_(Track.title.ilike(f"%{raw}%"), Track.artist.ilike(f"%{raw}%")),
                )
                .limit(10)
            )
            tracks = list(demo.scalars())
            providers = ["Sona"] if tracks else []
        await session.commit()

    results = []
    for track in tracks[:10]:
        audio = _audio(track, settings, settings.bot_username)
        if audio:
            results.append(audio)
        results.append(_article(track, settings, settings.bot_username))

    if not results:
        results = [
            InlineQueryResultArticle(
                id="empty",
                title="Ничего не нашлось",
                description="Попробуй другое название или имя исполнителя",
                input_message_content=InputTextMessageContent(
                    message_text=f"🎧 По запросу «{escape(raw)}» ничего не найдено.",
                ),
            )
        ]

    await query.answer(
        results=results[:25],
        cache_time=60,
        is_personal=True,
    )
