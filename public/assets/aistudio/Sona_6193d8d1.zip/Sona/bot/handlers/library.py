from __future__ import annotations

from aiogram import Bot, F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup, Message
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.config import Settings
from backend.models import Like, Playlist, PlaylistTrack, User
from bot.keyboards import webapp_path_button
from bot.utils import ensure_user, esc, fmt_duration
from bot.views import send_track

router = Router(name="library")


async def _user_playlists(session: AsyncSession, user_id: int) -> list[Playlist]:
    result = await session.execute(
        select(Playlist)
        .where(Playlist.owner_id == user_id)
        .options(selectinload(Playlist.items).selectinload(PlaylistTrack.track))
        .order_by(Playlist.updated_at.desc())
    )
    return list(result.scalars())


async def _liked_tracks(session: AsyncSession, user_id: int) -> list:
    result = await session.execute(
        select(Like)
        .where(Like.user_id == user_id)
        .options(selectinload(Like.track))
        .order_by(Like.created_at.desc())
    )
    return [like.track for like in result.scalars() if like.track]


def _library_markup(
    playlists: list[Playlist], settings: Settings, likes_count: int
) -> InlineKeyboardMarkup:
    rows: list[list[InlineKeyboardButton]] = []
    rows.append(
        [
            InlineKeyboardButton(
                text=f"💚 Избранное · {likes_count}", callback_data="likes"
            )
        ]
    )
    for playlist in playlists[:12]:
        rows.append(
            [
                InlineKeyboardButton(
                    text=f"🎵 {playlist.title} · {len(playlist.items)}"[:60],
                    callback_data=f"pl:{playlist.id}",
                )
            ]
        )
    app = webapp_path_button(settings, "＋ Создать плейлист в Sona", "/library")
    if app:
        rows.append([app])
    rows.append([InlineKeyboardButton(text="← В меню", callback_data="menu")])
    return InlineKeyboardMarkup(inline_keyboard=rows)


async def _send_library(
    target_message: Message,
    bot: Bot,
    user: User,
    session: AsyncSession,
    settings: Settings,
    *,
    edit: bool = False,
) -> None:
    playlists = await _user_playlists(session, user.id)
    likes = await _liked_tracks(session, user.id)
    total_tracks = sum(len(playlist.items) for playlist in playlists)
    text = (
        "🎧 <b>Твоя медиатека</b>\n\n"
        f"<b>{len(playlists)}</b> плейлистов · <b>{total_tracks}</b> треков · "
        f"<b>{len(likes)}</b> в избранном\n\n"
        + (
            "Выбирай плейлист или открой полную версию в приложении."
            if playlists
            else "Плейлистов пока нет. Создай первый в мини-приложении или через поиск."
        )
    )
    markup = _library_markup(playlists, settings, len(likes))
    if edit:
        try:
            await target_message.edit_text(
                text, reply_markup=markup, disable_web_page_preview=True
            )
            return
        except Exception:
            pass
    await bot.send_message(
        target_message.chat.id,
        text,
        reply_markup=markup,
        disable_web_page_preview=True,
    )


@router.message(Command("library", "playlists"))
async def library_command(
    message: Message, bot: Bot, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, message.from_user)
    await _send_library(message, bot, user, session, settings)


@router.callback_query(F.data == "playlists")
async def library_callback(
    callback: CallbackQuery, bot: Bot, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    await _send_library(
        callback.message, bot, user, session, settings, edit=True
    )


async def _send_likes(
    callback_or_message,
    bot: Bot,
    user: User,
    session: AsyncSession,
    settings: Settings,
    *,
    edit: bool = False,
) -> None:
    tracks = await _liked_tracks(session, user.id)
    if not tracks:
        text = (
            "💚 <b>Избранное</b>\n\n"
            "Пока пусто. Найди трек через /search или в мини-приложении и нажми ♥."
        )
        rows = [[InlineKeyboardButton(text="🔎 Найти музыку", callback_data="search")]]
        rows.append([InlineKeyboardButton(text="← Медиатека", callback_data="playlists")])
    else:
        text = (
            f"💚 <b>Избранное · {len(tracks)}</b>\n\n"
            "Твои любимые треки собраны здесь."
        )
        rows = []
        for track in tracks[:10]:
            label = f"▶ {track.title} — {track.artist}"
            rows.append(
                [
                    InlineKeyboardButton(
                        text=label[:58], callback_data=f"track:{track.id}"
                    )
                ]
            )
        if len(tracks) > 10:
            app = webapp_path_button(settings, "Показать все в Sona", "/likes")
            if app:
                rows.append([app])
        rows.append([InlineKeyboardButton(text="← Медиатека", callback_data="playlists")])
    markup = InlineKeyboardMarkup(inline_keyboard=rows)
    target = callback_or_message.message if hasattr(callback_or_message, "message") else callback_or_message
    if edit and hasattr(target, "edit_text"):
        try:
            await target.edit_text(text, reply_markup=markup)
            return
        except Exception:
            pass
    await bot.send_message(target.chat.id, text, reply_markup=markup)


@router.message(Command("likes"))
async def likes_command(
    message: Message, bot: Bot, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, message.from_user)
    await _send_likes(message, bot, user, session, settings)


@router.callback_query(F.data == "likes")
async def likes_callback(
    callback: CallbackQuery, bot: Bot, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    await _send_likes(callback, bot, user, session, settings, edit=True)


@router.callback_query(F.data.startswith("pl:"))
async def playlist_detail(
    callback: CallbackQuery, bot: Bot, session: AsyncSession, settings: Settings
) -> None:
    playlist_id = int(callback.data.split(":", 1)[1])
    user = await ensure_user(session, callback.from_user)
    playlist = await session.scalar(
        select(Playlist)
        .where(Playlist.id == playlist_id, Playlist.owner_id == user.id)
        .options(selectinload(Playlist.items).selectinload(PlaylistTrack.track))
    )
    if playlist is None:
        await callback.answer("Плейлист не найден", show_alert=True)
        return
    await callback.answer()
    items = [item for item in playlist.items if item.track]
    lines = [
        f"🎵 <b>{esc(playlist.title)}</b>",
        f"<i>{len(items)} треков</i>",
    ]
    if playlist.description:
        lines.extend(["", esc(playlist.description)])
    lines.append("")
    for index, item in enumerate(items[:20], start=1):
        track = item.track
        lines.append(
            f"{index}. <b>{esc(track.title)}</b> — {esc(track.artist)} · {fmt_duration(track.duration_ms)}"
        )
    if len(items) > 20:
        lines.append(f"…и ещё {len(items) - 20}")
    rows: list[list[InlineKeyboardButton]] = []
    for item in items[:4]:
        label = f"▶ {item.track.title} — {item.track.artist}"
        rows.append(
            [
                InlineKeyboardButton(
                    text=label[:58], callback_data=f"track:{item.track_id}"
                )
            ]
        )
    app = webapp_path_button(settings, "Открыть плейлист в Sona", f"/playlist/{playlist.id}")
    if app:
        rows.append([app])
    rows.append([InlineKeyboardButton(text="← Медиатека", callback_data="playlists")])
    await callback.message.answer(
        "\n".join(lines),
        reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
        disable_web_page_preview=True,
    )
