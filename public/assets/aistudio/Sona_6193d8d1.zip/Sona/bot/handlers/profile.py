from __future__ import annotations

from aiogram import F, Router
from aiogram.filters import Command
from aiogram.types import CallbackQuery, InlineKeyboardButton, InlineKeyboardMarkup
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.config import Settings
from backend.models import AccessRequest, Playlist, User
from bot.keyboards import settings_keyboard
from bot.utils import ensure_user, esc, privacy_label
from bot.views import send_profile

router = Router(name="profile")


@router.message(Command("profile"))
async def profile_command(
    message, bot, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, message.from_user)
    await send_profile(bot, message.chat.id, user, user, session, settings)


@router.callback_query(F.data == "profile")
async def profile_callback(
    callback: CallbackQuery, bot, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    await send_profile(bot, callback.message.chat.id, user, user, session, settings)


async def _pending_count(session: AsyncSession, user: User) -> int:
    return int(
        await session.scalar(
            select(func.count())
            .select_from(AccessRequest)
            .where(
                AccessRequest.owner_id == user.id,
                AccessRequest.status == "pending",
            )
        )
        or 0
    )


async def _send_settings_dashboard(
    callback: CallbackQuery,
    user: User,
    session: AsyncSession,
    settings: Settings,
) -> None:
    pending = await _pending_count(session, user)
    text = (
        "⚙️ <b>Доступ к профилю</b>\n\n"
        f"Сейчас: <b>{privacy_label(user.privacy)}</b>\n"
        f"Плейлисты: {'видны' if user.show_playlists else 'скрыты'} · "
        f"Избранное: {'видно' if user.show_liked else 'скрыто'}\n\n"
        "• <b>Открыт</b> — профиль доступен всем по ссылке\n"
        "• <b>По заявке</b> — только тем, кого ты одобришь\n"
        "• <b>Закрыт</b> — профиль недоступен никому\n\n"
        "Заявки приходят прямо сюда. Полные настройки — в приложении."
    )
    markup = settings_keyboard(settings, user.privacy, pending)
    try:
        await callback.message.edit_text(
            text, reply_markup=markup, disable_web_page_preview=True
        )
    except Exception:
        await callback.message.answer(
            text, reply_markup=markup, disable_web_page_preview=True
        )


@router.message(Command("settings"))
async def settings_command(
    message, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, message.from_user)
    pending = await _pending_count(session, user)
    text = (
        "⚙️ <b>Доступ к профилю</b>\n\n"
        f"Сейчас: <b>{privacy_label(user.privacy)}</b>\n"
        f"Плейлисты: {'видны' if user.show_playlists else 'скрыты'} · "
        f"Избранное: {'видно' if user.show_liked else 'скрыто'}"
    )
    await message.answer(
        text,
        reply_markup=settings_keyboard(settings, user.privacy, pending),
        disable_web_page_preview=True,
    )


@router.callback_query(F.data == "settings")
async def settings_callback(
    callback: CallbackQuery, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, callback.from_user)
    await callback.answer()
    await _send_settings_dashboard(callback, user, session, settings)


@router.callback_query(F.data.startswith("privacy:"))
async def privacy_callback(
    callback: CallbackQuery, session: AsyncSession, settings: Settings
) -> None:
    value = callback.data.split(":", 1)[1]
    if value not in {"public", "selected", "private"}:
        await callback.answer("Неизвестная настройка", show_alert=True)
        return
    user = await ensure_user(session, callback.from_user)
    user.privacy = value
    await session.commit()
    await callback.answer("Готово")
    await _send_settings_dashboard(callback, user, session, settings)


@router.callback_query(F.data == "requests")
async def requests_callback(
    callback: CallbackQuery, session: AsyncSession, settings: Settings
) -> None:
    user = await ensure_user(session, callback.from_user)
    result = await session.execute(
        select(AccessRequest)
        .where(AccessRequest.owner_id == user.id, AccessRequest.status == "pending")
        .options(selectinload(AccessRequest.requester))
        .order_by(AccessRequest.created_at.desc())
    )
    requests = list(result.scalars())
    await callback.answer()
    if not requests:
        text = "🔔 <b>Заявки</b>\n\nПока никого нового. Ссылка на профиль — в разделе «Профиль»."
        rows = [
            [InlineKeyboardButton(text="🔗 Поделиться профилем", callback_data="share_profile")],
            [InlineKeyboardButton(text="← Настройки", callback_data="settings")],
        ]
    else:
        lines = [f"🔔 <b>Заявки на доступ · {len(requests)}</b>", ""]
        rows = []
        for item in requests:
            requester = item.requester
            username = f" @{esc(requester.username)}" if requester.username else ""
            lines.append(f"• <b>{esc(requester.display_name)}</b>{username}")
            rows.append(
                [
                    InlineKeyboardButton(
                        text=f"✅ {requester.first_name[:18]}",
                        callback_data=f"access_ok:{item.id}",
                    ),
                    InlineKeyboardButton(
                        text="✖️", callback_data=f"access_no:{item.id}"
                    ),
                ]
            )
        rows.append([InlineKeyboardButton(text="← Настройки", callback_data="settings")])
        text = "\n".join(lines)
    try:
        await callback.message.edit_text(
            text,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
            disable_web_page_preview=True,
        )
    except Exception:
        await callback.message.answer(
            text,
            reply_markup=InlineKeyboardMarkup(inline_keyboard=rows),
            disable_web_page_preview=True,
        )


@router.message(Command("share"))
async def share_command(message, session: AsyncSession, settings: Settings) -> None:
    from bot.views import share_text

    user = await ensure_user(session, message.from_user)
    text, keyboard = share_text(user, settings)
    await message.answer(text, reply_markup=keyboard, disable_web_page_preview=True)
