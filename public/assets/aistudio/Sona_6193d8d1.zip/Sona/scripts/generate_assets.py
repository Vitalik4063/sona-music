"""Generate all local brand, demo cover and demo audio assets.

Run from the project root:
    .venv/Scripts/python scripts/generate_assets.py

The demo music is generated from scratch (sine waves + noise), so there are no
third-party recordings in the repository. Real search results are provided by
the public APIs of Deezer / Apple Music / Spotify / YouTube.
"""

from __future__ import annotations

import math
import random
import struct
import wave
from pathlib import Path

import lameenc
from PIL import Image, ImageDraw, ImageFilter, ImageFont

ROOT = Path(__file__).resolve().parent.parent
STATIC = ROOT / "backend" / "static"
COVERS = STATIC / "demo" / "covers"
AUDIO = STATIC / "demo" / "audio"
AVATARS = STATIC / "demo" / "avatars"
BRAND = STATIC / "brand"
FONTS = Path(__file__).resolve().parent / "fonts"
MANROPE = FONTS / "Manrope.ttf"
UNBOUNDED = FONTS / "Unbounded.ttf"

for folder in (COVERS, AUDIO, AVATARS, BRAND):
    folder.mkdir(parents=True, exist_ok=True)

TRACKS = [
    {
        "slug": "glass-rain",
        "title": "Стеклянный дождь",
        "artist": "Nula",
        "palette": ("#0b1210", "#c8ff4d", "#2bad8a"),
        "variant": "rings",
        "bpm": 78,
        "scale": [0, 3, 7, 10, 12, 15],
        "root": 55.0,
    },
    {
        "slug": "midnight-tram",
        "title": "Полночный трамвай",
        "artist": "Неон и Пыль",
        "palette": ("#0d0b18", "#9a7bff", "#ff7a59"),
        "variant": "waves",
        "bpm": 88,
        "scale": [0, 2, 3, 7, 10, 12],
        "root": 49.0,
    },
    {
        "slug": "summer-current",
        "title": "Летний ток",
        "artist": "Mara Vale",
        "palette": ("#14110a", "#ffd36e", "#ff7a59"),
        "variant": "bars",
        "bpm": 96,
        "scale": [0, 2, 4, 7, 9, 12],
        "root": 65.41,
    },
    {
        "slug": "quieter",
        "title": "Тише",
        "artist": "Kite Arcade",
        "palette": ("#0a1116", "#9ee7ff", "#c8ff4d"),
        "variant": "orbits",
        "bpm": 72,
        "scale": [0, 3, 5, 7, 10, 12],
        "root": 58.27,
    },
    {
        "slug": "northern-light",
        "title": "Северный свет",
        "artist": "Lumen Field",
        "palette": ("#0a1512", "#a8ffcc", "#d9c2ff"),
        "variant": "waves",
        "bpm": 68,
        "scale": [0, 2, 5, 7, 9, 12],
        "root": 61.74,
    },
    {
        "slug": "anyway",
        "title": "Всё равно",
        "artist": "Чувства",
        "palette": ("#170d0d", "#ff8f85", "#ffcf9c"),
        "variant": "rings",
        "bpm": 84,
        "scale": [0, 3, 5, 8, 10, 12],
        "root": 51.91,
    },
    {
        "slug": "after-rain",
        "title": "После дождя",
        "artist": "Nula",
        "palette": ("#091211", "#8de0c2", "#f2ffe8"),
        "variant": "dots",
        "bpm": 74,
        "scale": [0, 2, 3, 7, 9, 12],
        "root": 55.0,
    },
    {
        "slug": "stay-awake",
        "title": "Не спать",
        "artist": "Неон и Пыль",
        "palette": ("#100a18", "#ff7a59", "#9a7bff"),
        "variant": "bars",
        "bpm": 102,
        "scale": [0, 3, 7, 10, 12, 15],
        "root": 49.0,
    },
    {
        "slug": "gravity",
        "title": "Гравитация",
        "artist": "Mara Vale",
        "palette": ("#0e1110", "#c8ff4d", "#63c8ff"),
        "variant": "orbits",
        "bpm": 92,
        "scale": [0, 2, 5, 7, 10, 12],
        "root": 65.41,
    },
    {
        "slug": "white-noise",
        "title": "Белый шум",
        "artist": "Kite Arcade",
        "palette": ("#0c0f12", "#e8f4ff", "#8aa7ff"),
        "variant": "dots",
        "bpm": 70,
        "scale": [0, 3, 5, 10, 12, 15],
        "root": 58.27,
    },
    {
        "slug": "coffee-640",
        "title": "Кофе в 6:40",
        "artist": "Lumen Field",
        "palette": ("#14100a", "#f5c98e", "#c8ff4d"),
        "variant": "rings",
        "bpm": 80,
        "scale": [0, 2, 4, 7, 9, 12],
        "root": 61.74,
    },
    {
        "slug": "home",
        "title": "Домой",
        "artist": "Чувства",
        "palette": ("#0b1211", "#d9c2ff", "#ffcf9c"),
        "variant": "waves",
        "bpm": 76,
        "scale": [0, 2, 5, 7, 9, 12],
        "root": 51.91,
    },
]


def hex_rgb(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[i : i + 2], 16) for i in (0, 2, 4))  # type: ignore[return-value]


def blend(a: tuple[int, int, int], b: tuple[int, int, int], t: float) -> tuple[int, int, int]:
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))  # type: ignore[return-value]


def font(path: Path, size: int) -> ImageFont.FreeTypeFont:
    try:
        return ImageFont.truetype(str(path), size)
    except Exception:
        return ImageFont.load_default(size=size)


def wrap(draw: ImageDraw.ImageDraw, text: str, fnt, max_width: int) -> list[str]:
    words = text.split()
    lines: list[str] = []
    current = ""
    for word in words:
        test = f"{current} {word}".strip()
        if draw.textlength(test, font=fnt) <= max_width:
            current = test
        else:
            if current:
                lines.append(current)
            current = word
    if current:
        lines.append(current)
    return lines


def grain(image: Image.Image, opacity: int = 14) -> Image.Image:
    noise = Image.effect_noise(image.size, 42).convert("L")
    tint = Image.new("RGB", image.size, (255, 255, 255))
    mask = noise.point(lambda x: max(0, x - 118) * 2)
    image = Image.composite(tint, image, mask.point(lambda x: min(opacity, x // 9)))
    return image


def gradient_background(size: int, dark: str, accent: str) -> Image.Image:
    base = Image.new("RGB", (size, size), hex_rgb(dark))
    draw = ImageDraw.Draw(base)
    c1 = hex_rgb(accent)
    dark_rgb = hex_rgb(dark)
    for y in range(size):
        t = (y / size) ** 1.2
        row_color = blend(dark_rgb, blend(dark_rgb, c1, 0.22), t)
        draw.line([(0, y), (size, y)], fill=row_color)
    return base


def add_blobs(image: Image.Image, colors: list[tuple[int, int, int]]) -> Image.Image:
    size = image.width
    overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    random.seed(image.width + sum(colors[0]))
    for index, color in enumerate(colors):
        cx = random.randint(size // 5, size - size // 5)
        cy = random.randint(size // 5, size - size // 5)
        radius = random.randint(size // 5, size // 2)
        alpha = random.randint(75, 150)
        draw.ellipse(
            [cx - radius, cy - radius, cx + radius, cy + radius],
            fill=(*color, alpha),
        )
    overlay = overlay.filter(ImageFilter.GaussianBlur(size // 10))
    image = Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB")
    return image


def draw_rings(image: Image.Image, color: tuple[int, int, int]) -> None:
    size = image.width
    overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    cx, cy = int(size * 0.74), int(size * 0.27)
    for i in range(10):
        radius = int(size * (0.11 + i * 0.055))
        width = max(2, int(size * 0.007))
        alpha = max(20, 155 - i * 16)
        draw.ellipse(
            [cx - radius, cy - radius, cx + radius, cy + radius],
            outline=(*color, alpha),
            width=width,
        )
    draw.ellipse(
        [cx - 12, cy - 12, cx + 12, cy + 12],
        fill=(*color, 230),
    )
    image.alpha_composite(overlay.filter(ImageFilter.GaussianBlur(0.6))) if False else None
    image.paste(Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB"))


def draw_waves(image: Image.Image, color: tuple[int, int, int]) -> None:
    size = image.width
    overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    for line_index in range(18):
        points = []
        amplitude = size * (0.03 + line_index * 0.004)
        y_base = size * 0.58 + line_index * size * 0.017
        for x in range(0, size + 12, 12):
            y = y_base + math.sin(x / size * math.pi * 4 + line_index * 0.38) * amplitude
            points.append((x, y))
        draw.line(
            points,
            fill=(*color, max(18, 120 - line_index * 5)),
            width=max(2, int(size * 0.004)),
        )
    image.paste(Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB"))


def draw_bars(image: Image.Image, color: tuple[int, int, int]) -> None:
    size = image.width
    overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    random.seed(size + 7)
    count = 11
    gap = size * 0.022
    bar_width = (size * 0.6 - gap * (count - 1)) / count
    for index in range(count):
        height = random.uniform(0.08, 0.55) * size
        x = size * 0.34 + index * (bar_width + gap)
        y = size * 0.34 - height / 2
        radius = bar_width / 2
        draw.rounded_rectangle(
            [x, y, x + bar_width, y + height],
            radius=radius,
            fill=(*color, random.randint(120, 225)),
        )
    image.paste(Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB"))


def draw_orbits(image: Image.Image, color: tuple[int, int, int]) -> None:
    size = image.width
    overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    cx, cy = size * 0.52, size * 0.45
    for i in range(4):
        radius = size * (0.14 + i * 0.085)
        draw.ellipse(
            [cx - radius, cy - radius * 0.46, cx + radius, cy + radius * 0.46],
            outline=(*color, 110 - i * 16),
            width=max(3, size // 210),
        )
    for angle in range(0, 360, 45):
        rad = math.radians(angle)
        x = cx + math.cos(rad) * size * 0.3
        y = cy + math.sin(rad) * size * 0.14
        draw.ellipse([x - 4, y - 4, x + 4, y + 4], fill=(*color, 220))
    image.paste(Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB"))


def draw_dots(image: Image.Image, color: tuple[int, int, int]) -> None:
    size = image.width
    overlay = Image.new("RGBA", image.size, (0, 0, 0, 0))
    draw = ImageDraw.Draw(overlay)
    step = size // 13
    for row in range(5, 12):
        for col in range(3, 13):
            distance = abs(col - 8) + abs(row - 8)
            alpha = max(18, 160 - distance * 18)
            radius = max(2, int(size * 0.006 * (1 + (12 - row) * 0.15)))
            draw.ellipse(
                [col * step, row * step, col * step + radius * 2, row * step + radius * 2],
                fill=(*color, alpha),
            )
    image.paste(Image.alpha_composite(image.convert("RGBA"), overlay).convert("RGB"))


def make_cover(index: int, track: dict) -> None:
    size = 900
    dark, accent, second = track["palette"]
    image = gradient_background(size, dark, accent)
    image = add_blobs(image, [hex_rgb(accent), hex_rgb(second)])
    motif_color = blend(hex_rgb(accent), (255, 255, 255), 0.15)
    variant = track["variant"]
    if variant == "rings":
        draw_rings(image, motif_color)
    elif variant == "waves":
        draw_waves(image, motif_color)
    elif variant == "bars":
        draw_bars(image, motif_color)
    elif variant == "orbits":
        draw_orbits(image, motif_color)
    else:
        draw_dots(image, motif_color)

    image = image.convert("RGBA")
    # Soft vignette, so the type always sits on a calm surface.
    vignette = Image.new("L", (size, size), 0)
    vdraw = ImageDraw.Draw(vignette)
    vdraw.ellipse([-size * 0.2, size * 0.3, size * 1.2, size * 1.5], fill=110)
    black = Image.new("RGBA", image.size, (5, 8, 7, 255))
    image = Image.composite(black, image, vignette.filter(ImageFilter.GaussianBlur(100)))

    draw = ImageDraw.Draw(image)
    fnt_small = font(MANROPE, 25)
    fnt_label = font(MANROPE, 30)
    fnt_title = font(UNBOUNDED, 56)
    draw.text((56, 50), "SONA / SESSIONS", font=fnt_small, fill=(255, 255, 255, 190))
    draw.text(
        (size - 56, 46),
        f"{index + 1:02d}",
        font=font(UNBOUNDED, 38),
        fill=(255, 255, 255, 160),
        anchor="ra",
    )
    title_lines = wrap(draw, track["title"], fnt_title, int(size * 0.82))
    y = size - 140 - len(title_lines) * 66
    for line in title_lines[:3]:
        draw.text((56, y), line, font=fnt_title, fill=(255, 255, 255, 245))
        y += 66
    draw.text((56, size - 80), track["artist"], font=fnt_label, fill=(*hex_rgb(accent), 255))
    draw.line(
        [(56, size - 108), (size - 56, size - 108)],
        fill=(255, 255, 255, 55),
        width=2,
    )
    image = grain(image)
    image.convert("RGB").save(COVERS / f"{index + 1:02d}-{track['slug']}.jpg", quality=90)


def make_welcome() -> None:
    width, height = 1600, 1000
    image = Image.new("RGB", (width, height), (8, 12, 10))
    draw = ImageDraw.Draw(image)
    for y in range(height):
        t = y / height
        draw.line([(0, y), (width, y)], fill=blend((8, 12, 10), (19, 32, 25), t))
    # Airy lime glow.
    glow = Image.new("RGBA", (width, height), (0, 0, 0, 0))
    gdraw = ImageDraw.Draw(glow)
    for radius, alpha in ((720, 25), (560, 30), (400, 40), (240, 55)):
        gdraw.ellipse(
            [width * 0.62 - radius, height * 0.48 - radius, width * 0.62 + radius, height * 0.48 + radius],
            fill=(200, 255, 77, alpha),
        )
    glow = glow.filter(ImageFilter.GaussianBlur(90))
    image = Image.alpha_composite(image.convert("RGBA"), glow).convert("RGB")
    draw = ImageDraw.Draw(image)

    # Signature rings, based on the logo mark.
    cx, cy = int(width * 0.76), int(height * 0.48)
    for i in range(7):
        radius = 130 + i * 62
        draw.arc(
            [cx - radius, cy - radius, cx + radius, cy + radius],
            start=-55,
            end=235,
            fill=(200, 255, 77, max(20, 120 - i * 14)),
            width=max(2, 8 - i),
        )
    draw.ellipse(
        [cx - 126, cy - 126, cx + 126, cy + 126],
        outline=(200, 255, 77, 220),
        width=9,
    )
    draw.ellipse([cx - 18, cy - 18, cx + 18, cy + 18], fill=(200, 255, 77, 255))

    draw.text((94, 88), "sona", font=font(UNBOUNDED, 76), fill=(238, 247, 240))
    draw.text(
        (100, 328),
        "МУЗЫКА,\nКОТОРАЯ\nЗВУЧИТ КАК ТЫ.",
        font=font(UNBOUNDED, 82),
        fill=(238, 247, 240),
        spacing=18,
    )
    draw.text(
        (104, 760),
        "Плейлисты · Поиск по всем сервисам · Профиль, которым хочется делиться",
        font=font(MANROPE, 30),
        fill=(184, 201, 190),
    )
    draw.line([(104, 848), (620, 848)], fill=(200, 255, 77, 220), width=3)
    draw.text(
        (104, 878),
        "telegram mini app",
        font=font(MANROPE, 26),
        fill=(200, 255, 77),
    )
    image = grain(image, 10)
    image.save(BRAND / "welcome.jpg", quality=91)
    image.resize((1200, 750), Image.Resampling.LANCZOS).save(BRAND / "welcome-1200.jpg", quality=90)
    image.resize((1200, 630), Image.Resampling.LANCZOS).save(BRAND / "og.jpg", quality=90)


def make_logo() -> None:
    size = 1024
    image = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image)
    lime = (200, 255, 77, 255)
    for i, radius in enumerate((360, 270, 180, 90)):
        draw.arc(
            [size / 2 - radius, size / 2 - radius, size / 2 + radius, size / 2 + radius],
            start=-60,
            end=240,
            fill=(200, 255, 77, 255 - i * 35),
            width=36 - i * 6,
        )
    draw.ellipse(
        [size / 2 - 36, size / 2 - 36, size / 2 + 36, size / 2 + 36], fill=lime
    )
    image.save(BRAND / "logo-mark.png")

    icon = Image.new("RGB", (size, size), (10, 15, 12))
    idraw = ImageDraw.Draw(icon)
    for y in range(size):
        idraw.line([(0, y), (size, y)], fill=blend((10, 15, 12), (20, 34, 26), y / size))
    mark = image.resize((680, 680), Image.Resampling.LANCZOS)
    icon.paste(mark, (172, 172), mark)
    icon = grain(icon, 8)
    icon.save(BRAND / "app-icon.png")
    icon.save(BRAND / "app-icon.jpg", quality=92)


def make_avatar() -> None:
    size = 600
    image = Image.new("RGB", (size, size), (10, 15, 12))
    draw = ImageDraw.Draw(image)
    for y in range(size):
        draw.line(
            [(0, y), (size, y)],
            fill=blend((10, 15, 12), (74, 112, 86), (y / size) * 0.55),
        )
    glow = Image.new("RGBA", (size, size), (0, 0, 0, 0))
    gd = ImageDraw.Draw(glow)
    gd.ellipse([120, 70, 520, 470], fill=(200, 255, 77, 120))
    gd.ellipse([250, 220, 700, 700], fill=(255, 122, 89, 110))
    glow = glow.filter(ImageFilter.GaussianBlur(80))
    image = Image.alpha_composite(image.convert("RGBA"), glow).convert("RGB")
    draw = ImageDraw.Draw(image)
    draw.text(
        (size / 2, size / 2 - 20),
        "А",
        font=font(UNBOUNDED, 240),
        fill=(10, 15, 12),
        anchor="mm",
    )
    draw.ellipse([0, 0, size - 1, size - 1], outline=(200, 255, 77, 90), width=8)
    image = grain(image, 9)
    image.save(AVATARS / "alisa.jpg", quality=92)


def note_frequency(root: float, semitones: int) -> float:
    return root * (2 ** (semitones / 12))


def generate_audio(track: dict, index: int) -> int:
    sr = 44100
    bpm = track["bpm"]
    beat = 60.0 / bpm
    bars = 8
    seconds = beat * 4 * bars
    total = int(seconds * sr)
    samples = [0.0] * total
    random.seed(1000 + index)
    scale = track["scale"]
    root = track["root"]

    # Slow evolving chords (two bars each).
    chord_degrees = [0, 5, 3, 4]
    for bar_index in range(bars // 2):
        start = int(bar_index * beat * 8 * sr)
        end = min(total, int((bar_index + 1) * beat * 8 * sr))
        degree = chord_degrees[bar_index % len(chord_degrees)]
        chord = [
            note_frequency(root, scale[(degree + offset) % len(scale)] + 12 * ((degree + offset) // len(scale)))
            for offset in (0, 2, 4)
        ]
        for i in range(start, end):
            t = i / sr
            local = (i - start) / sr
            envelope = min(1.0, local / 1.6) * min(1.0, (end - i) / (sr * 1.6))
            value = 0.0
            for chord_index, frequency in enumerate(chord):
                detune = 1 + (chord_index - 1) * 0.0025
                value += math.sin(2 * math.pi * frequency * detune * t) * 0.5
                value += math.sin(2 * math.pi * frequency * 2 * t) * 0.12
            samples[i] += value * envelope * 0.10

    # Arpeggio / lead.
    step = beat / 2
    for step_index in range(int(seconds / step)):
        if random.random() < 0.25:
            continue
        start = int(step_index * step * sr)
        length = int(step * sr * 0.9)
        semitone = random.choice(scale) + 12
        frequency = note_frequency(root, semitone)
        amplitude = random.uniform(0.08, 0.18)
        for offset in range(min(length, total - start)):
            t = offset / sr
            env = math.exp(-t * 5.5) * min(1.0, offset / 220)
            value = math.sin(2 * math.pi * frequency * t)
            value += 0.35 * math.sin(4 * math.pi * frequency * t)
            samples[start + offset] += value * env * amplitude

    # Soft kick and brushed noise on every beat.
    for beat_index in range(int(seconds / beat)):
        if beat_index % 4 == 3:
            continue
        start = int(beat_index * beat * sr)
        length = int(beat * 0.55 * sr)
        for offset in range(min(length, total - start)):
            t = offset / sr
            env = math.exp(-t * 18)
            frequency = 54 - 22 * min(1, t * 6)
            samples[start + offset] += math.sin(2 * math.pi * frequency * t) * env * 0.22

    for beat_index in range(int(seconds / beat * 2)):
        start = int(beat_index * beat * 0.5 * sr)
        length = min(int(0.045 * sr), total - start)
        amp = 0.018 if beat_index % 2 else 0.028
        for offset in range(length):
            env = math.exp(-offset / (sr * 0.012))
            samples[start + offset] += random.uniform(-1, 1) * amp * env

    # Gentle CRT-style noise bed.
    for i in range(total):
        samples[i] += random.uniform(-1, 1) * 0.0018

    fade_in = int(sr * 1.6)
    fade_out = int(sr * 2.4)
    for i in range(fade_in):
        samples[i] *= i / fade_in
    for i in range(fade_out):
        samples[total - 1 - i] *= i / fade_out

    peak = max(1.0, max(abs(value) for value in samples))
    gain = min(1.0, 0.72 / peak)
    pcm = b"".join(
        struct.pack("<h", int(max(-1, min(1, value * gain)) * 32767)) for value in samples
    )

    encoder = lameenc.Encoder()
    encoder.set_bit_rate(96)
    encoder.set_in_sample_rate(sr)
    encoder.set_channels(1)
    encoder.set_quality(5)
    mp3 = encoder.encode(pcm)
    mp3 += encoder.flush()
    (AUDIO / f"{index + 1:02d}-{track['slug']}.mp3").write_bytes(mp3)
    return round(seconds * 1000)


def main() -> None:
    durations = {}
    for index, track in enumerate(TRACKS):
        make_cover(index, track)
        durations[track["slug"]] = generate_audio(track, index)
        print(f"cover + audio: {track['artist']} — {track['title']}")
    make_welcome()
    make_logo()
    make_avatar()
    print("durations:", durations)
    print(f"assets ready: {STATIC}")


if __name__ == "__main__":
    main()
