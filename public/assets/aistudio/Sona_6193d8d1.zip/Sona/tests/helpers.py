from __future__ import annotations

import hashlib
import hmac
import json
import time
from urllib.parse import urlencode


def sign_init_data(
    user: dict,
    bot_token: str,
    *,
    auth_date: int | None = None,
    query_id: str = "AAH-test-query",
) -> str:
    """Build a Telegram WebApp initData string with a valid HMAC signature."""

    values = {
        "auth_date": str(auth_date if auth_date is not None else int(time.time())),
        "query_id": query_id,
        "user": json.dumps(user, ensure_ascii=False, separators=(",", ":")),
    }
    check_string = "\n".join(f"{key}={values[key]}" for key in sorted(values))
    secret_key = hmac.new(
        b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256
    ).digest()
    values["hash"] = hmac.new(
        secret_key, check_string.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    return urlencode(values)
