from __future__ import annotations


async def test_playlist_lifecycle(
    client,
    make_user,
    make_track,
    auth_headers,
):
    user = await make_user()
    first = await make_track(title="Первый")
    second = await make_track(title="Второй")
    third = await make_track(title="Третий")
    headers = auth_headers(user)

    created = await client.post(
        "/api/playlists",
        json={"title": "  Дорога  ", "description": "  Для вечера  "},
        headers=headers,
    )
    assert created.status_code == 201
    playlist = created.json()
    assert playlist["title"] == "Дорога"
    assert playlist["description"] == "Для вечера"
    assert playlist["is_public"] is True
    assert playlist["tracks"] == []
    playlist_id = playlist["id"]

    for track in (first, second, first):
        response = await client.post(
            f"/api/playlists/{playlist_id}/tracks",
            json={"track_id": track.id},
            headers=headers,
        )
        assert response.status_code == 200

    detail = await client.get(f"/api/playlists/{playlist_id}", headers=headers)
    assert [track["id"] for track in detail.json()["tracks"]] == [
        first.id,
        second.id,
    ]
    assert detail.json()["track_count"] == 2

    added = await client.post(
        f"/api/playlists/{playlist_id}/tracks",
        json={"track_id": third.id},
        headers=headers,
    )
    assert [track["id"] for track in added.json()["tracks"]] == [
        first.id,
        second.id,
        third.id,
    ]

    reordered = await client.patch(
        f"/api/playlists/{playlist_id}/reorder",
        json={"track_ids": [third.id, first.id, second.id]},
        headers=headers,
    )
    assert reordered.status_code == 200
    assert [track["id"] for track in reordered.json()["tracks"]] == [
        third.id,
        first.id,
        second.id,
    ]

    bad_reorder = await client.patch(
        f"/api/playlists/{playlist_id}/reorder",
        json={"track_ids": [third.id, first.id]},
        headers=headers,
    )
    assert bad_reorder.status_code == 400

    removed = await client.delete(
        f"/api/playlists/{playlist_id}/tracks/{first.id}", headers=headers
    )
    assert removed.status_code == 200
    assert [track["id"] for track in removed.json()["tracks"]] == [
        third.id,
        second.id,
    ]

    updated = await client.patch(
        f"/api/playlists/{playlist_id}",
        json={"title": "Новое имя", "is_public": False},
        headers=headers,
    )
    assert updated.status_code == 200
    assert updated.json()["title"] == "Новое имя"
    assert updated.json()["is_public"] is False

    listed = await client.get("/api/playlists", headers=headers)
    assert [item["id"] for item in listed.json()] == [playlist_id]

    deleted = await client.delete(f"/api/playlists/{playlist_id}", headers=headers)
    assert deleted.status_code == 200
    assert (await client.get(f"/api/playlists/{playlist_id}", headers=headers)).status_code == 404


async def test_playlists_are_private_to_their_owner(
    client,
    make_user,
    make_playlist,
    auth_headers,
):
    owner = await make_user()
    stranger = await make_user()
    playlist = await make_playlist(owner, title="Личный")

    response = await client.get(
        f"/api/playlists/{playlist.id}", headers=auth_headers(stranger)
    )
    assert response.status_code == 403

    anonymous = await client.get(f"/api/playlists/{playlist.id}")
    assert anonymous.status_code == 401

    add = await client.post(
        f"/api/playlists/{playlist.id}/tracks",
        json={"track_id": 1},
        headers=auth_headers(stranger),
    )
    assert add.status_code == 403


async def test_playlist_validation(client, make_user, auth_headers):
    user = await make_user()
    headers = auth_headers(user)

    empty = await client.post(
        "/api/playlists", json={"title": "   "}, headers=headers
    )
    assert empty.status_code == 422

    missing_track = await client.post(
        "/api/playlists", json={"title": "Тест"}, headers=headers
    )
    playlist_id = missing_track.json()["id"]
    response = await client.post(
        f"/api/playlists/{playlist_id}/tracks",
        json={"track_id": 999_999},
        headers=headers,
    )
    assert response.status_code == 404
