from __future__ import annotations

from backend.config import Settings


async def _profile(client, token: str, headers: dict | None = None):
    return await client.get(f"/api/share/{token}", headers=headers or {})


async def test_selected_profile_requires_approval_then_grants_access(
    client,
    settings: Settings,
    make_user,
    make_track,
    make_playlist,
    make_like,
    auth_headers,
):
    owner = await make_user(
        first_name="Алиса",
        username="alisa",
        privacy="selected",
        share_token="alisa-selected",
    )
    viewer = await make_user(first_name="Борис", username="boris")
    first = await make_track(title="Первый", artist="Nula")
    second = await make_track(title="Второй", artist="Nula")
    hidden = await make_track(title="Скрытый", artist="Nula")
    public_playlist = await make_playlist(
        owner, [first, second], title="Открытый", is_public=True
    )
    private_playlist = await make_playlist(
        owner, [hidden], title="Скрытый", is_public=False
    )
    await make_like(owner, first)

    anonymous = await _profile(client, owner.share_token)
    assert anonymous.status_code == 200
    anonymous_body = anonymous.json()
    assert anonymous_body["can_view"] is False
    assert anonymous_body["access"] == "locked"
    assert anonymous_body["can_request"] is False
    assert anonymous_body["is_authenticated"] is False
    assert anonymous_body["stats"] == {}
    assert anonymous_body["playlists"] == []
    assert anonymous_body["liked_tracks"] == []

    viewer_headers = auth_headers(viewer)
    locked = await _profile(client, owner.share_token, viewer_headers)
    locked_body = locked.json()
    assert locked_body["can_view"] is False
    assert locked_body["can_request"] is True
    assert locked_body["request_status"] is None

    request = await client.post(
        f"/api/share/{owner.share_token}/request", headers=viewer_headers
    )
    assert request.status_code == 200
    assert request.json()["status"] == "pending"

    duplicate = await client.post(
        f"/api/share/{owner.share_token}/request", headers=viewer_headers
    )
    assert duplicate.json()["status"] == "pending"

    pending = (
        await _profile(client, owner.share_token, viewer_headers)
    ).json()
    assert pending["request_status"] == "pending"
    assert pending["can_request"] is False
    assert pending["can_view"] is False

    settings_response = await client.get(
        "/api/settings", headers=auth_headers(owner)
    )
    assert settings_response.status_code == 200
    owner_settings = settings_response.json()
    assert owner_settings["privacy"] == "selected"
    assert owner_settings["share_url"] == (
        f"https://t.me/sona_test_bot?startapp=u_{owner.share_token}"
    )
    assert owner_settings["webapp_share_url"] == (
        f"https://sona.test/u/{owner.share_token}"
    )
    assert len(owner_settings["incoming_requests"]) == 1
    request_entry = owner_settings["incoming_requests"][0]
    assert request_entry["status"] == "pending"
    assert request_entry["requester"]["id"] == viewer.id

    approved = await client.post(
        f"/api/settings/requests/{request_entry['id']}/approve",
        headers=auth_headers(owner),
    )
    assert approved.status_code == 200
    approved_body = approved.json()
    assert approved_body["incoming_requests"] == []
    assert len(approved_body["allowed_viewers"]) == 1
    assert (
        approved_body["allowed_viewers"][0]["identifier_value"]
        == str(viewer.telegram_id)
    )

    opened = (await _profile(client, owner.share_token, viewer_headers)).json()
    assert opened["can_view"] is True
    assert opened["access"] == "granted"
    assert opened["is_authenticated"] is True
    assert opened["stats"] == {"playlists": 1, "tracks": 2, "liked": 1}
    assert [item["id"] for item in opened["playlists"]] == [public_playlist.id]
    assert [track["id"] for track in opened["liked_tracks"]] == [first.id]

    shared = await client.get(
        f"/api/share/{owner.share_token}/playlists/{public_playlist.id}",
        headers=viewer_headers,
    )
    assert shared.status_code == 200
    assert shared.json()["can_copy"] is True
    assert [track["id"] for track in shared.json()["playlist"]["tracks"]] == [
        first.id,
        second.id,
    ]

    hidden_response = await client.get(
        f"/api/share/{owner.share_token}/playlists/{private_playlist.id}",
        headers=viewer_headers,
    )
    assert hidden_response.status_code == 403

    copy_response = await client.post(
        f"/api/share/{owner.share_token}/playlists/{public_playlist.id}/copy",
        headers=viewer_headers,
    )
    assert copy_response.status_code == 200
    copied = copy_response.json()["playlist"]
    assert copied["title"] == "Открытый · копия"
    assert copied["track_count"] == 2
    assert copied["owner"] is None

    viewer_playlists = await client.get(
        "/api/playlists", headers=viewer_headers
    )
    assert viewer_playlists.status_code == 200
    assert [item["id"] for item in viewer_playlists.json()] == [copied["id"]]

    copied_detail = await client.get(
        f"/api/playlists/{copied['id']}", headers=viewer_headers
    )
    assert [track["id"] for track in copied_detail.json()["tracks"]] == [
        first.id,
        second.id,
    ]

    owner_playlists = await client.get(
        "/api/playlists", headers=auth_headers(owner)
    )
    assert sorted(item["id"] for item in owner_playlists.json()) == sorted(
        [public_playlist.id, private_playlist.id]
    )


async def test_declined_request_can_be_sent_again(
    client,
    make_user,
    make_track,
    make_playlist,
    auth_headers,
):
    owner = await make_user(privacy="selected", share_token="decline-owner")
    viewer = await make_user()
    track = await make_track()
    await make_playlist(owner, [track])

    viewer_headers = auth_headers(viewer)
    await client.post(
        f"/api/share/{owner.share_token}/request", headers=viewer_headers
    )
    owner_settings = (
        await client.get("/api/settings", headers=auth_headers(owner))
    ).json()
    request_id = owner_settings["incoming_requests"][0]["id"]

    declined = await client.post(
        f"/api/settings/requests/{request_id}/decline",
        headers=auth_headers(owner),
    )
    assert declined.status_code == 200
    assert declined.json()["incoming_requests"] == []

    locked = (
        await _profile(client, owner.share_token, viewer_headers)
    ).json()
    assert locked["can_view"] is False
    assert locked["request_status"] == "declined"
    assert locked["can_request"] is True

    retry = await client.post(
        f"/api/share/{owner.share_token}/request", headers=viewer_headers
    )
    assert retry.json()["status"] == "pending"

    after_retry = (
        await client.get("/api/settings", headers=auth_headers(owner))
    ).json()
    assert len(after_retry["incoming_requests"]) == 1
    assert after_retry["incoming_requests"][0]["id"] != request_id


async def test_private_profile_is_invisible_and_cannot_be_requested(
    client,
    make_user,
    make_track,
    make_playlist,
    make_like,
    auth_headers,
):
    owner = await make_user(privacy="private", share_token="private-owner")
    viewer = await make_user()
    track = await make_track()
    private_playlist = await make_playlist(owner, [track], is_public=False)
    await make_like(owner, track)

    anonymous = (await _profile(client, owner.share_token)).json()
    assert anonymous["can_view"] is False
    assert anonymous["access"] == "private"
    assert anonymous["can_request"] is False

    viewer_headers = auth_headers(viewer)
    locked = (
        await _profile(client, owner.share_token, viewer_headers)
    ).json()
    assert locked["can_view"] is False
    assert locked["access"] == "private"
    assert locked["can_request"] is False

    request = await client.post(
        f"/api/share/{owner.share_token}/request", headers=viewer_headers
    )
    assert request.status_code == 403

    own_profile = (
        await _profile(client, owner.share_token, auth_headers(owner))
    ).json()
    assert own_profile["can_view"] is True
    assert own_profile["access"] == "owner"
    assert [item["id"] for item in own_profile["playlists"]] == [
        private_playlist.id
    ]
    assert [item["id"] for item in own_profile["liked_tracks"]] == [track.id]
    assert own_profile["stats"]["liked"] == 1

    own_playlist = await client.get(
        f"/api/share/{owner.share_token}/playlists/{private_playlist.id}",
        headers=auth_headers(owner),
    )
    assert own_playlist.status_code == 200
    assert own_playlist.json()["can_copy"] is False

    viewer_playlist = await client.get(
        f"/api/share/{owner.share_token}/playlists/{private_playlist.id}",
        headers=viewer_headers,
    )
    assert viewer_playlist.status_code == 403


async def test_hidden_sections_are_not_leaked(
    client,
    make_user,
    make_track,
    make_playlist,
    make_like,
    auth_headers,
):
    owner = await make_user(
        show_liked=False,
        show_playlists=False,
        share_token="hidden-owner",
    )
    viewer = await make_user()
    track = await make_track(title="Секретный трек")
    playlist = await make_playlist(owner, [track])
    await make_like(owner, track)

    for headers in ({}, auth_headers(viewer)):
        body = (await _profile(client, owner.share_token, headers)).json()
        assert body["can_view"] is True
        assert body["show_liked"] is False
        assert body["playlists"] == []
        assert body["liked_tracks"] == []
        assert body["stats"] == {"playlists": 0, "tracks": 0}
        assert "liked" not in body["stats"]

    hidden_playlist = await client.get(
        f"/api/share/{owner.share_token}/playlists/{playlist.id}",
        headers=auth_headers(viewer),
    )
    assert hidden_playlist.status_code == 403
    assert "скрыты" in hidden_playlist.json()["detail"]

    own_profile = (
        await _profile(client, owner.share_token, auth_headers(owner))
    ).json()
    assert [item["id"] for item in own_profile["playlists"]] == [playlist.id]
    assert [item["id"] for item in own_profile["liked_tracks"]] == [track.id]
    assert own_profile["stats"]["liked"] == 1


async def test_allowlist_by_username_grants_and_revokes_access(
    client,
    make_user,
    auth_headers,
):
    owner = await make_user(privacy="selected", share_token="allowlist-owner")
    viewer = await make_user(username="boris_viewer")
    owner_headers = auth_headers(owner)
    viewer_headers = auth_headers(viewer)

    added = await client.post(
        "/api/settings/viewers",
        json={"identifier": "@Boris_Viewer"},
        headers=owner_headers,
    )
    assert added.status_code == 200
    viewers = added.json()["allowed_viewers"]
    assert len(viewers) == 1

    granted = (
        await _profile(client, owner.share_token, viewer_headers)
    ).json()
    assert granted["can_view"] is True
    assert granted["access"] == "granted"

    duplicate = await client.post(
        "/api/settings/viewers",
        json={"identifier": "boris_viewer"},
        headers=owner_headers,
    )
    assert duplicate.status_code == 409

    removed = await client.delete(
        f"/api/settings/viewers/{viewers[0]['id']}", headers=owner_headers
    )
    assert removed.status_code == 200
    assert removed.json()["allowed_viewers"] == []

    revoked = (
        await _profile(client, owner.share_token, viewer_headers)
    ).json()
    assert revoked["can_view"] is False
    assert revoked["can_request"] is True


async def test_allowlist_validation(
    client,
    make_user,
    auth_headers,
):
    owner = await make_user()
    headers = auth_headers(owner)

    own_id = await client.post(
        "/api/settings/viewers",
        json={"identifier": str(owner.telegram_id)},
        headers=headers,
    )
    assert own_id.status_code == 400

    invalid = await client.post(
        "/api/settings/viewers",
        json={"identifier": "маша"},
        headers=headers,
    )
    assert invalid.status_code == 422


async def test_share_token_rotation_invalidates_old_link(
    client,
    make_user,
    auth_headers,
):
    owner = await make_user(share_token="old-share-token")
    headers = auth_headers(owner)
    assert (await _profile(client, "old-share-token")).status_code == 200

    rotated = await client.post("/api/settings/rotate-share", headers=headers)
    assert rotated.status_code == 200
    new_token = rotated.json()["share_token"]
    assert new_token != "old-share-token"
    assert rotated.json()["share_url"].endswith(f"u_{new_token}")

    assert (await _profile(client, "old-share-token")).status_code == 404
    assert (await _profile(client, new_token)).status_code == 200
