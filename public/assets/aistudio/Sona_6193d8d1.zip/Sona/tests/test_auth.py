from __future__ import annotations

import hashlib
import hmac
import time
from urllib.parse import parse_qsl, urlencode

import pytest

from backend.auth import validate_init_data
from backend.config import Settings
from tests.helpers import sign_init_data

TELEGRAM_USER = {
    "id": 700_000_001,
    "first_name": "Аня",
    "last_name": "Волкова",
    "username": "anya_wave",
    "language_code": "ru",
}


def test_validate_init_data_accepts_valid_signature(settings: Settings):
    raw = sign_init_data(TELEGRAM_USER, settings.bot_token)

    data = validate_init_data(raw, settings.bot_token)

    assert data["user"]["id"] == TELEGRAM_USER["id"]
    assert data["user"]["username"] == "anya_wave"
    assert data["auth_date"] > 0


def test_validate_init_data_rejects_tampered_payload(settings: Settings):
    raw = sign_init_data(TELEGRAM_USER, settings.bot_token)
    values = dict(parse_qsl(raw, keep_blank_values=True))
    values["user"] = values["user"].replace("Аня", "Вера")
    tampered = urlencode(values)

    with pytest.raises(ValueError, match="Подпись"):
        validate_init_data(tampered, settings.bot_token)


def test_validate_init_data_rejects_wrong_bot_token(settings: Settings):
    raw = sign_init_data(TELEGRAM_USER, "111111:OTHER_TOKEN")

    with pytest.raises(ValueError, match="Подпись"):
        validate_init_data(raw, settings.bot_token)


def test_validate_init_data_rejects_stale_session(settings: Settings):
    raw = sign_init_data(
        TELEGRAM_USER,
        settings.bot_token,
        auth_date=int(time.time()) - 2 * 86_400,
    )

    with pytest.raises(ValueError, match="устарела"):
        validate_init_data(raw, settings.bot_token)


def test_validate_init_data_rejects_future_timestamp(settings: Settings):
    raw = sign_init_data(
        TELEGRAM_USER,
        settings.bot_token,
        auth_date=int(time.time()) + 10_000,
    )

    with pytest.raises(ValueError, match="будущего"):
        validate_init_data(raw, settings.bot_token)


def test_validate_init_data_requires_user(settings: Settings):
    raw = sign_init_data({"username": "no_id"}, settings.bot_token)

    with pytest.raises(ValueError, match="пользователя"):
        validate_init_data(raw, settings.bot_token)


def test_validate_init_data_rejects_empty_query(settings: Settings):
    with pytest.raises(ValueError, match="Пустые"):
        validate_init_data("", settings.bot_token)


def test_validate_init_data_legacy_signature_without_signature_field(
    settings: Settings,
):
    """Telegram adds `signature` in newer clients; the legacy check must still work."""

    user_json = '{"id":42,"first_name":"Test"}'
    values = {"auth_date": str(int(time.time())), "user": user_json}
    check_string = "\n".join(f"{key}={values[key]}" for key in sorted(values))
    secret_key = hmac.new(
        b"WebAppData", settings.bot_token.encode("utf-8"), hashlib.sha256
    ).digest()
    values["hash"] = hmac.new(
        secret_key, check_string.encode("utf-8"), hashlib.sha256
    ).hexdigest()
    values["signature"] = "ed25519-placeholder"

    data = validate_init_data(urlencode(values), settings.bot_token)

    assert data["user"]["id"] == 42


async def test_session_route_creates_and_reuses_user(client, settings: Settings):
    raw = sign_init_data(TELEGRAM_USER, settings.bot_token)

    first = await client.post("/api/auth/session", json={"initData": raw})
    assert first.status_code == 200
    payload = first.json()
    assert payload["is_dev"] is False
    assert payload["token"]
    assert payload["user"]["first_name"] == "Аня"
    assert payload["user"]["telegram_id"] == TELEGRAM_USER["id"]

    me = await client.get(
        "/api/me", headers={"Authorization": f"Bearer {payload['token']}"}
    )
    assert me.status_code == 200
    assert me.json()["username"] == "anya_wave"

    second = await client.post("/api/auth/session", json={"initData": raw})
    assert second.status_code == 200
    assert second.json()["user"]["id"] == payload["user"]["id"]


async def test_session_route_rejects_invalid_signature(client):
    response = await client.post(
        "/api/auth/session",
        json={"initData": "auth_date=1&user=%7B%22id%22%3A1%7D&hash=deadbeef"},
    )

    assert response.status_code == 401
    assert "Telegram" in response.json()["detail"]


async def test_dev_session_returns_working_token(client):
    response = await client.post("/api/auth/dev")

    assert response.status_code == 200
    payload = response.json()
    assert payload["is_dev"] is True
    assert payload["user"]["telegram_id"] == 999_000_001

    home = await client.get(
        "/api/home", headers={"Authorization": f"Bearer {payload['token']}"}
    )
    assert home.status_code == 200
    assert home.json()["user"]["id"] == payload["user"]["id"]


async def test_protected_routes_require_token(client):
    response = await client.get("/api/home")

    assert response.status_code == 401
    assert response.headers["www-authenticate"] == "Bearer"
