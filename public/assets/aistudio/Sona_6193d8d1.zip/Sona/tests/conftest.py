from __future__ import annotations

import itertools
from collections.abc import AsyncIterator, Awaitable, Callable
from pathlib import Path

import httpx
import pytest
import pytest_asyncio

from backend.auth import create_access_token
from backend.config import Settings
from backend.main import create_app
from backend.models import Like, Playlist, PlaylistTrack, Track, User
from backend.services.music.base import track_fingerprint


@pytest.fixture
def settings(tmp_path: Path) -> Settings:
    database = (tmp_path / "sona-test.db").as_posix()
    return Settings(
        _env_file=None,
        database_url=f"sqlite+aiosqlite:///{database}",
        bot_token="000000:DEV_TOKEN",
        bot_username="sona_test_bot",
        jwt_secret="test-secret-" + "x" * 32,
        environment="test",
        allow_dev_auth=True,
        seed_demo=False,
        public_webapp_url="https://sona.test",
        cors_origins="https://sona.test,http://localhost:5173",
        search_cache_seconds=0,
    )


@pytest_asyncio.fixture
async def app(settings: Settings):
    application = create_app(settings)
    async with application.router.lifespan_context(application):
        yield application


@pytest_asyncio.fixture
async def client(app) -> AsyncIterator[httpx.AsyncClient]:
    transport = httpx.ASGITransport(app=app)
    async with httpx.AsyncClient(
        transport=transport, base_url="http://testserver"
    ) as http_client:
        yield http_client


@pytest_asyncio.fixture
async def make_user(app) -> Callable[..., Awaitable[User]]:
    counter = itertools.count(1)

    async def _make_user(**overrides) -> User:
        number = next(counter)
        values = {
            "telegram_id": 500_000_000 + number,
            "username": f"user_{number}",
            "first_name": f"Слушатель {number}",
            "bio": "",
            "privacy": "public",
            "share_token": f"test-token-{number:04d}",
            "is_demo": True,
        }
        values.update(overrides)
        async with app.state.session_factory() as session:
            user = User(**values)
            session.add(user)
            await session.commit()
            await session.refresh(user)
            return user

    return _make_user


@pytest_asyncio.fixture
async def make_track(app) -> Callable[..., Awaitable[Track]]:
    counter = itertools.count(1)

    async def _make_track(**overrides) -> Track:
        number = next(counter)
        title = overrides.pop("title", f"Тестовый трек {number}")
        artist = overrides.pop("artist", "Sona Test")
        values = {
            "fingerprint": track_fingerprint(title, artist),
            "provider": "sona",
            "provider_id": f"test-{number:03d}",
            "title": title,
            "artist": artist,
            "album": "Sona Test Album",
            "duration_ms": 180_000,
            "artwork_url": "/static/demo/covers/01-glass-rain.jpg",
            "preview_url": None,
            "external_url": None,
            "links": {},
            "sources": ["Sona"],
            "tags": [],
            "is_demo": True,
        }
        values.update(overrides)
        async with app.state.session_factory() as session:
            track = Track(**values)
            session.add(track)
            await session.commit()
            await session.refresh(track)
            return track

    return _make_track


@pytest_asyncio.fixture
async def make_playlist(app) -> Callable[..., Awaitable[Playlist]]:
    counter = itertools.count(1)

    async def _make_playlist(owner: User, tracks=(), **overrides) -> Playlist:
        number = next(counter)
        values = {
            "owner_id": owner.id,
            "title": f"Плейлист {number}",
            "description": "",
            "is_public": True,
        }
        values.update(overrides)
        async with app.state.session_factory() as session:
            playlist = Playlist(**values)
            session.add(playlist)
            await session.flush()
            for position, track in enumerate(tracks):
                session.add(
                    PlaylistTrack(
                        playlist_id=playlist.id,
                        track_id=track.id,
                        position=position,
                    )
                )
            await session.commit()
            await session.refresh(playlist)
            return playlist

    return _make_playlist


@pytest_asyncio.fixture
async def make_like(app) -> Callable[[User, Track], Awaitable[None]]:
    async def _make_like(user: User, track: Track) -> None:
        async with app.state.session_factory() as session:
            session.add(Like(user_id=user.id, track_id=track.id))
            await session.commit()

    return _make_like


@pytest.fixture
def auth_headers(settings: Settings):
    def _auth_headers(user: User) -> dict[str, str]:
        token = create_access_token(user, settings)
        return {"Authorization": f"Bearer {token}"}

    return _auth_headers
