from __future__ import annotations

from collections.abc import AsyncIterator

from fastapi import Depends, Request
from sqlalchemy.ext.asyncio import AsyncSession

from backend.auth import auth_error, decode_access_token
from backend.config import Settings
from backend.db import create_session_factory, create_engine
from backend.models import User


async def get_session(request: Request) -> AsyncIterator[AsyncSession]:
    factory = request.app.state.session_factory
    async with factory() as session:
        yield session


def get_app_settings(request: Request) -> Settings:
    return request.app.state.settings


def _bearer_token(request: Request) -> str | None:
    header = request.headers.get("Authorization", "")
    if header.lower().startswith("bearer "):
        return header[7:].strip()
    return request.headers.get("X-Sona-Token") or None


async def get_optional_user(
    request: Request,
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> User | None:
    token = _bearer_token(request)
    if not token:
        return None
    try:
        payload = decode_access_token(token, settings)
        user_id = int(payload["sub"])
    except (ValueError, KeyError, TypeError):
        return None
    return await session.get(User, user_id)


async def get_current_user(
    request: Request,
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> User:
    token = _bearer_token(request)
    if not token:
        raise auth_error()
    try:
        payload = decode_access_token(token, settings)
        user_id = int(payload["sub"])
    except (ValueError, KeyError, TypeError) as exc:
        raise auth_error(str(exc)) from exc
    user = await session.get(User, user_id)
    if user is None:
        raise auth_error("Пользователь не найден")
    return user


def build_state_for_app(db_url: str, settings: Settings):
    engine = create_engine(db_url)
    return {
        "engine": engine,
        "session_factory": create_session_factory(engine),
        "settings": settings,
    }
