from __future__ import annotations

import logging
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles

from backend.config import BASE_DIR, Settings, get_settings
from backend.db import create_engine, create_schema, create_session_factory
from backend.routers import auth, likes, playlists, search, settings as settings_router
from backend.routers import share, tracks, users
from backend.seed import seed_demo_data
from backend.services.music.aggregator import SearchAggregator

logger = logging.getLogger("sona")
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(name)s: %(message)s",
)

STATIC_DIR = BASE_DIR / "backend" / "static"
WEBAPP_DIST = BASE_DIR / "webapp" / "dist"


def create_app(settings: Settings | None = None) -> FastAPI:
    app_settings = settings or get_settings()

    @asynccontextmanager
    async def lifespan(app: FastAPI):
        await create_schema(app.state.engine)
        factory = app.state.session_factory
        async with factory() as session:
            await seed_demo_data(session, app.state.settings)
        logger.info("Sona API ready · %s", app.state.settings.environment)
        yield
        await app.state.engine.dispose()

    app = FastAPI(
        title="Sona Music API",
        version="1.0.0",
        docs_url="/api/docs",
        redoc_url="/api/redoc",
        openapi_url="/api/openapi.json",
        lifespan=lifespan,
    )

    app.state.settings = app_settings
    app.state.engine = create_engine(app_settings.database_url)
    app.state.session_factory = create_session_factory(app.state.engine)
    app.state.aggregator = SearchAggregator(app_settings)
    app.state.webapp_dist = WEBAPP_DIST

    app.add_middleware(
        CORSMiddleware,
        allow_origins=app_settings.cors_list,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    app.add_middleware(GZipMiddleware, minimum_size=800)

    @app.middleware("http")
    async def security_headers(request: Request, call_next):
        response = await call_next(request)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        response.headers.setdefault(
            "Content-Security-Policy",
            "frame-ancestors 'self' https://telegram.org https://*.telegram.org",
        )
        response.headers.setdefault("X-Permitted-Cross-Domain-Policies", "none")
        response.headers.setdefault(
            "Permissions-Policy", "camera=(), microphone=(), geolocation=()"
        )
        return response

    @app.get("/api/health")
    async def health() -> dict:
        configured = [
            "deezer",
            "itunes",
        ]
        if app_settings.spotify_client_id and app_settings.spotify_client_secret:
            configured.append("spotify")
        if app_settings.youtube_api_key:
            configured.append("youtube")
        return {
            "ok": True,
            "service": "sona",
            "environment": app_settings.environment,
            "providers": configured,
            "bot_configured": app_settings.bot_is_configured,
        }

    api_prefix = "/api"
    app.include_router(auth.router, prefix=api_prefix)
    app.include_router(users.router, prefix=api_prefix)
    app.include_router(search.router, prefix=api_prefix)
    app.include_router(tracks.router, prefix=api_prefix)
    app.include_router(likes.router, prefix=api_prefix)
    app.include_router(playlists.router, prefix=api_prefix)
    app.include_router(settings_router.router, prefix=api_prefix)
    app.include_router(share.router, prefix=api_prefix)

    if STATIC_DIR.exists():
        app.mount("/static", StaticFiles(directory=str(STATIC_DIR)), name="static")

    @app.get("/{full_path:path}", include_in_schema=False)
    async def serve_webapp(full_path: str):
        first_segment = full_path.split("/", 1)[0]
        if first_segment in {"api", "static"}:
            raise HTTPException(status_code=404, detail="Not found")

        dist = Path(app.state.webapp_dist)
        if not dist.exists():
            return JSONResponse(
                {
                    "service": "sona",
                    "message": "Mini App ещё не собрана. Выполните: cd webapp && npm run build",
                    "api_docs": "/api/docs",
                }
            )

        candidate = (dist / full_path).resolve()
        dist_resolved = dist.resolve()
        if (
            full_path
            and candidate.is_file()
            and candidate.is_relative_to(dist_resolved)
        ):
            return FileResponse(candidate)

        index = dist / "index.html"
        if index.exists():
            return FileResponse(index)
        raise HTTPException(status_code=404, detail="Not found")

    return app


app = create_app()
