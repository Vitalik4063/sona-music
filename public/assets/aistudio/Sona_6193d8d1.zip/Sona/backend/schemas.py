from __future__ import annotations

from datetime import datetime
from typing import Any, Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

Privacy = Literal["public", "selected", "private"]


class TrackOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    title: str
    artist: str
    album: str | None = None
    duration_ms: int = 0
    artwork_url: str | None = None
    preview_url: str | None = None
    external_url: str | None = None
    provider: str = "sona"
    links: dict[str, Any] = Field(default_factory=dict)
    sources: list[str] = Field(default_factory=list)
    is_demo: bool = False
    liked: bool = False


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    telegram_id: int | None = None
    username: str | None = None
    first_name: str
    last_name: str | None = None
    display_name: str = ""
    photo_url: str | None = None
    bio: str = ""
    accent: str = "lime"
    privacy: Privacy = "public"

    @field_validator("display_name", mode="before")
    @classmethod
    def _empty(cls, value: Any) -> str:
        return value or ""


class PublicUser(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    username: str | None = None
    first_name: str
    last_name: str | None = None
    display_name: str = ""
    photo_url: str | None = None
    bio: str = ""
    accent: str = "lime"
    is_demo: bool = False


class SessionOut(BaseModel):
    token: str
    user: UserOut
    is_dev: bool = False


class SearchOut(BaseModel):
    query: str
    top: TrackOut | None = None
    tracks: list[TrackOut] = Field(default_factory=list)
    providers_used: list[str] = Field(default_factory=list)
    elapsed_ms: int = 0


class PlaylistSummary(BaseModel):
    id: int
    title: str
    description: str = ""
    cover_url: str | None = None
    is_public: bool = True
    track_count: int = 0
    total_duration_ms: int = 0
    collage: list[str] = Field(default_factory=list)
    owner: PublicUser | None = None
    created_at: datetime | None = None
    updated_at: datetime | None = None


class PlaylistOut(PlaylistSummary):
    tracks: list[TrackOut] = Field(default_factory=list)


class CreatePlaylistIn(BaseModel):
    title: str = Field(min_length=1, max_length=120)
    description: str = Field(default="", max_length=500)
    is_public: bool = True


class UpdatePlaylistIn(BaseModel):
    title: str | None = Field(default=None, min_length=1, max_length=120)
    description: str | None = Field(default=None, max_length=500)
    is_public: bool | None = None


class AddTrackIn(BaseModel):
    track_id: int


class ReorderIn(BaseModel):
    track_ids: list[int] = Field(default_factory=list, max_length=500)


class MixOut(BaseModel):
    id: str
    title: str
    subtitle: str
    accent: str
    artwork_url: str | None = None
    tracks: list[TrackOut] = Field(default_factory=list)


class HomeOut(BaseModel):
    user: UserOut
    liked_count: int
    playlists: list[PlaylistSummary]
    recent: list[TrackOut]
    mixes: list[MixOut]
    new_releases: list[TrackOut]
    stats: dict[str, int] = Field(default_factory=dict)


class AllowedViewerOut(BaseModel):
    id: int
    identifier_type: str
    identifier_value: str
    display_name: str | None = None
    created_at: datetime


class AccessRequestOut(BaseModel):
    id: int
    status: str
    created_at: datetime
    requester: PublicUser | None = None
    owner: PublicUser | None = None


class SettingsOut(BaseModel):
    user: UserOut
    show_liked: bool
    show_playlists: bool
    privacy: Privacy
    accent: str
    share_token: str
    share_url: str
    webapp_share_url: str
    bot_username: str
    allowed_viewers: list[AllowedViewerOut] = Field(default_factory=list)
    incoming_requests: list[AccessRequestOut] = Field(default_factory=list)
    outgoing_requests: list[AccessRequestOut] = Field(default_factory=list)


class UpdateSettingsIn(BaseModel):
    privacy: Privacy | None = None
    show_liked: bool | None = None
    show_playlists: bool | None = None
    accent: Literal["lime", "coral", "sky", "lilac", "sun"] | None = None
    bio: str | None = Field(default=None, max_length=160)
    first_name: str | None = Field(default=None, min_length=1, max_length=64)


class AddViewerIn(BaseModel):
    identifier: str = Field(min_length=1, max_length=128)


class PublicProfileOut(BaseModel):
    user: PublicUser
    access: Literal["owner", "public", "selected", "granted", "locked", "private"]
    can_view: bool
    can_request: bool = False
    request_status: str | None = None
    stats: dict[str, int] = Field(default_factory=dict)
    playlists: list[PlaylistSummary] = Field(default_factory=list)
    liked_tracks: list[TrackOut] = Field(default_factory=list)
    show_liked: bool = True
    share_token: str
    is_authenticated: bool = False


class PublicPlaylistOut(BaseModel):
    playlist: PlaylistOut
    access: str
    can_copy: bool = False


class CopyResult(BaseModel):
    playlist: PlaylistSummary


class InlineSearchIn(BaseModel):
    query: str


class MessageOut(BaseModel):
    ok: bool = True
    message: str = ""
