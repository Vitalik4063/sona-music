from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.dependencies import get_current_user, get_session
from backend.models import Playlist, PlaylistTrack, Track, User
from backend.schemas import (
    AddTrackIn,
    CreatePlaylistIn,
    PlaylistOut,
    PlaylistSummary,
    ReorderIn,
    UpdatePlaylistIn,
)
from backend.services.serializers import playlist_out, playlist_summary
from backend.services.tracks import liked_track_ids

router = APIRouter(prefix="/playlists", tags=["playlists"])


def _query(playlist_id: int):
    return (
        select(Playlist)
        .where(Playlist.id == playlist_id)
        .options(
            selectinload(Playlist.items).selectinload(PlaylistTrack.track),
            selectinload(Playlist.owner),
        )
    )


async def _owned_playlist(
    session: AsyncSession, playlist_id: int, user: User
) -> Playlist:
    playlist = (await session.execute(_query(playlist_id))).scalar_one_or_none()
    if playlist is None:
        raise HTTPException(status_code=404, detail="Плейлист не найден")
    if playlist.owner_id != user.id:
        raise HTTPException(status_code=403, detail="Это чужой плейлист")
    return playlist


@router.get("", response_model=list[PlaylistSummary])
async def list_playlists(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> list[PlaylistSummary]:
    result = await session.execute(
        select(Playlist)
        .where(Playlist.owner_id == user.id)
        .options(selectinload(Playlist.items).selectinload(PlaylistTrack.track))
        .order_by(Playlist.updated_at.desc())
    )
    return [playlist_summary(playlist) for playlist in result.scalars()]


@router.post("", response_model=PlaylistOut, status_code=201)
async def create_playlist(
    payload: CreatePlaylistIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> PlaylistOut:
    playlist = Playlist(
        owner_id=user.id,
        title=payload.title.strip(),
        description=payload.description.strip(),
        is_public=payload.is_public,
    )
    session.add(playlist)
    await session.commit()
    playlist = (await session.execute(_query(playlist.id))).scalar_one()
    return playlist_out(playlist)


@router.get("/{playlist_id}", response_model=PlaylistOut)
async def get_playlist(
    playlist_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> PlaylistOut:
    playlist = await _owned_playlist(session, playlist_id, user)
    liked = await liked_track_ids(session, user.id)
    return playlist_out(playlist, liked_ids=liked)


@router.patch("/{playlist_id}", response_model=PlaylistOut)
async def update_playlist(
    playlist_id: int,
    payload: UpdatePlaylistIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> PlaylistOut:
    playlist = await _owned_playlist(session, playlist_id, user)
    if payload.title is not None:
        playlist.title = payload.title.strip()
    if payload.description is not None:
        playlist.description = payload.description.strip()
    if payload.is_public is not None:
        playlist.is_public = payload.is_public
    await session.commit()
    playlist = (await session.execute(_query(playlist_id))).scalar_one()
    liked = await liked_track_ids(session, user.id)
    return playlist_out(playlist, liked_ids=liked)


@router.delete("/{playlist_id}")
async def delete_playlist(
    playlist_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> dict:
    playlist = await _owned_playlist(session, playlist_id, user)
    await session.delete(playlist)
    await session.commit()
    return {"ok": True}


@router.post("/{playlist_id}/tracks", response_model=PlaylistOut)
async def add_track(
    playlist_id: int,
    payload: AddTrackIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> PlaylistOut:
    playlist = await _owned_playlist(session, playlist_id, user)
    track = await session.get(Track, payload.track_id)
    if track is None:
        raise HTTPException(status_code=404, detail="Трек не найден")
    existing = await session.get(PlaylistTrack, (playlist_id, track.id))
    if existing is None:
        next_position = max((item.position for item in playlist.items), default=-1) + 1
        session.add(
            PlaylistTrack(
                playlist_id=playlist_id,
                track_id=track.id,
                position=next_position,
            )
        )
        await session.commit()
    playlist = (await session.execute(_query(playlist_id))).scalar_one()
    liked = await liked_track_ids(session, user.id)
    return playlist_out(playlist, liked_ids=liked)


@router.delete("/{playlist_id}/tracks/{track_id}", response_model=PlaylistOut)
async def remove_track(
    playlist_id: int,
    track_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> PlaylistOut:
    await _owned_playlist(session, playlist_id, user)
    item = await session.get(PlaylistTrack, (playlist_id, track_id))
    if item is not None:
        await session.delete(item)
        await session.commit()
    playlist = (await session.execute(_query(playlist_id))).scalar_one()
    liked = await liked_track_ids(session, user.id)
    return playlist_out(playlist, liked_ids=liked)


@router.patch("/{playlist_id}/reorder", response_model=PlaylistOut)
async def reorder(
    playlist_id: int,
    payload: ReorderIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> PlaylistOut:
    playlist = await _owned_playlist(session, playlist_id, user)
    current = {item.track_id: item for item in playlist.items}
    if set(payload.track_ids) != set(current.keys()):
        raise HTTPException(
            status_code=400, detail="Список треков не совпадает с плейлистом"
        )
    for position, track_id in enumerate(payload.track_ids):
        current[track_id].position = position
    await session.commit()
    playlist = (await session.execute(_query(playlist_id))).scalar_one()
    liked = await liked_track_ids(session, user.id)
    return playlist_out(playlist, liked_ids=liked)
