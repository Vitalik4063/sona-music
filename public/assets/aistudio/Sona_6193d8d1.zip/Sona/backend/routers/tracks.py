from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from backend.dependencies import get_current_user, get_session
from backend.models import Track, User
from backend.schemas import TrackOut
from backend.services.serializers import track_out
from backend.services.tracks import liked_track_ids

router = APIRouter(prefix="/tracks", tags=["tracks"])


@router.get("/{track_id}", response_model=TrackOut)
async def get_track(
    track_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> TrackOut:
    track = await session.get(Track, track_id)
    if track is None:
        raise HTTPException(status_code=404, detail="Трек не найден")
    liked = await liked_track_ids(session, user.id)
    return track_out(track, track.id in liked)
