from __future__ import annotations

from fastapi import APIRouter, Depends, Query, Request
from sqlalchemy import or_, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.dependencies import get_current_user, get_session
from backend.models import Track, User
from backend.schemas import SearchOut
from backend.services.music.aggregator import SearchAggregator
from backend.services.serializers import tracks_out
from backend.services.tracks import liked_track_ids, upsert_candidates

router = APIRouter(tags=["search"])


@router.get("/search", response_model=SearchOut)
async def search(
    request: Request,
    q: str = Query(min_length=2, max_length=120),
    limit: int = Query(default=30, ge=5, le=50),
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> SearchOut:
    aggregator: SearchAggregator = request.app.state.aggregator
    result = await aggregator.search(q, limit)
    tracks = []
    if result.tracks:
        tracks = await upsert_candidates(session, result.tracks)
    providers = list(result.providers_used)

    if not tracks:
        demo_result = await session.execute(
            select(Track)
            .where(
                Track.is_demo.is_(True),
                or_(
                    Track.title.ilike(f"%{q.strip()}%"),
                    Track.artist.ilike(f"%{q.strip()}%"),
                ),
            )
            .limit(limit)
        )
        tracks = list(demo_result.scalars())
        providers = ["Sona"]

    await session.commit()
    liked = await liked_track_ids(session, user.id)
    serialized = tracks_out(tracks, liked)
    return SearchOut(
        query=q,
        top=serialized[0] if serialized else None,
        tracks=serialized,
        providers_used=providers,
        elapsed_ms=result.elapsed_ms,
    )
