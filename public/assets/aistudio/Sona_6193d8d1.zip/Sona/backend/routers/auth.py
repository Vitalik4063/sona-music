from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, ConfigDict, Field
from sqlalchemy.ext.asyncio import AsyncSession

from backend.auth import (
    create_access_token,
    get_or_create_dev_user,
    upsert_telegram_user,
    validate_init_data,
)
from backend.config import Settings
from backend.dependencies import get_app_settings, get_session
from backend.schemas import SessionOut
from backend.services.serializers import user_out

router = APIRouter(prefix="/auth", tags=["auth"])


class SessionIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    init_data: str = Field(alias="initData", min_length=1, max_length=16_384)


@router.post("/session", response_model=SessionOut)
async def create_session(
    payload: SessionIn,
    request: Request,
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SessionOut:
    try:
        data = validate_init_data(payload.init_data, settings.bot_token)
    except ValueError as exc:
        raise HTTPException(status_code=401, detail=str(exc)) from exc

    user = await upsert_telegram_user(session, data["user"])
    await session.commit()
    await session.refresh(user)
    token = create_access_token(user, settings)
    return SessionOut(token=token, user=user_out(user), is_dev=False)


@router.post("/dev", response_model=SessionOut)
async def create_dev_session(
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SessionOut:
    if settings.is_production or not settings.allow_dev_auth:
        raise HTTPException(status_code=403, detail="Демо-вход отключён")
    user = await get_or_create_dev_user(session)
    await session.commit()
    await session.refresh(user)
    token = create_access_token(user, settings)
    return SessionOut(token=token, user=user_out(user), is_dev=True)


@router.get("/check", response_model=dict)
async def auth_check(request: Request) -> dict:
    return {"ok": True}
