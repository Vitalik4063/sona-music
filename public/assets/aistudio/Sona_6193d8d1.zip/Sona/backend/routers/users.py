from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field
from sqlalchemy import func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.dependencies import get_current_user, get_session
from backend.models import Like, Playlist, PlaylistTrack, RecentPlay, Track, User
from backend.schemas import HomeOut, MixOut, TrackOut, UserOut
from backend.services.editorial import build_mixes, mix_by_id, new_releases
from backend.services.serializers import (
    playlist_summary,
    track_out,
    tracks_out,
    user_out,
)
from backend.services.tracks import liked_track_ids, register_play

router = APIRouter(tags=["me"])


class ProfileUpdateIn(BaseModel):
    first_name: str | None = Field(default=None, min_length=1, max_length=64)
    bio: str | None = Field(default=None, max_length=160)


class HistoryIn(BaseModel):
    track_id: int


def _playlist_query(owner_id: int):
    return (
        select(Playlist)
        .where(Playlist.owner_id == owner_id)
        .options(selectinload(Playlist.items).selectinload(PlaylistTrack.track))
        .order_by(Playlist.updated_at.desc())
    )


@router.get("/me", response_model=UserOut)
async def me(user: User = Depends(get_current_user)) -> UserOut:
    return user_out(user)


@router.patch("/me", response_model=UserOut)
async def update_me(
    payload: ProfileUpdateIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> UserOut:
    if payload.first_name is not None:
        user.first_name = payload.first_name.strip()[:64] or user.first_name
    if payload.bio is not None:
        user.bio = payload.bio.strip()
    await session.commit()
    await session.refresh(user)
    return user_out(user)


@router.get("/home", response_model=HomeOut)
async def home(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> HomeOut:
    likes = await liked_track_ids(session, user.id)
    playlists = list((await session.execute(_playlist_query(user.id))).scalars())
    recent_result = await session.execute(
        select(RecentPlay)
        .where(RecentPlay.user_id == user.id)
        .options(selectinload(RecentPlay.track))
        .order_by(RecentPlay.played_at.desc())
        .limit(10)
    )
    recent_tracks = [item.track for item in recent_result.scalars() if item.track]
    mixes = await build_mixes(session, user, likes)
    releases = await new_releases(session, likes, limit=8)
    total_tracks = await session.scalar(
        select(func.count()).select_from(PlaylistTrack).join(
            Playlist, Playlist.id == PlaylistTrack.playlist_id
        ).where(Playlist.owner_id == user.id)
    )
    return HomeOut(
        user=user_out(user),
        liked_count=len(likes),
        playlists=[playlist_summary(playlist) for playlist in playlists],
        recent=tracks_out(recent_tracks, likes),
        mixes=mixes,
        new_releases=releases,
        stats={
            "liked": len(likes),
            "playlists": len(playlists),
            "tracks": int(total_tracks or 0),
        },
    )


@router.get("/mixes/{mix_id}", response_model=MixOut)
async def get_mix(
    mix_id: str,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> MixOut:
    likes = await liked_track_ids(session, user.id)
    mix = await mix_by_id(session, user, mix_id, likes)
    if mix is None:
        raise HTTPException(status_code=404, detail="Подборка не найдена")
    return mix


@router.get("/me/likes", response_model=list[TrackOut])
async def my_likes(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> list[TrackOut]:
    result = await session.execute(
        select(Like)
        .where(Like.user_id == user.id)
        .options(selectinload(Like.track))
        .order_by(Like.created_at.desc())
    )
    tracks = [like.track for like in result.scalars() if like.track]
    return tracks_out(tracks, {track.id for track in tracks})


@router.get("/me/recent", response_model=list[TrackOut])
async def my_recent(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> list[TrackOut]:
    likes = await liked_track_ids(session, user.id)
    result = await session.execute(
        select(RecentPlay)
        .where(RecentPlay.user_id == user.id)
        .options(selectinload(RecentPlay.track))
        .order_by(RecentPlay.played_at.desc())
        .limit(30)
    )
    tracks = [item.track for item in result.scalars() if item.track]
    return tracks_out(tracks, likes)


@router.post("/me/history")
async def add_history(
    payload: HistoryIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> dict:
    track = await session.get(Track, payload.track_id)
    if track is None:
        raise HTTPException(status_code=404, detail="Трек не найден")
    await register_play(session, user.id, track.id)
    await session.commit()
    return {"ok": True}


@router.delete("/me/history")
async def delete_history(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> dict:
    from sqlalchemy import delete as sql_delete

    await session.execute(sql_delete(RecentPlay).where(RecentPlay.user_id == user.id))
    await session.commit()
    return {"ok": True}
