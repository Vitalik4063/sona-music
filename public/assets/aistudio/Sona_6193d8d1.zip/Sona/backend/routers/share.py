from __future__ import annotations

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.config import Settings
from backend.dependencies import (
    get_app_settings,
    get_current_user,
    get_optional_user,
    get_session,
)
from backend.models import (
    AccessRequest,
    Like,
    Playlist,
    PlaylistTrack,
    User,
)
from backend.models import utcnow
from backend.schemas import (
    CopyResult,
    PlaylistOut,
    PlaylistSummary,
    PublicPlaylistOut,
    PublicProfileOut,
    PublicUser,
)
from backend.services.access import resolve_access, visible_playlists
from backend.services.notify import notify_access_request
from backend.services.serializers import (
    playlist_out,
    playlist_summary,
    public_user,
    tracks_out,
)
from backend.services.tracks import liked_track_ids

router = APIRouter(prefix="/share", tags=["share"])


async def _owner_by_token(session: AsyncSession, token: str) -> User:
    owner = await session.scalar(select(User).where(User.share_token == token))
    if owner is None:
        raise HTTPException(status_code=404, detail="Профиль не найден")
    return owner


async def _playlist_for_owner(
    session: AsyncSession, owner_id: int, playlist_id: int
) -> Playlist:
    playlist = (
        await session.execute(
            select(Playlist)
            .where(Playlist.id == playlist_id, Playlist.owner_id == owner_id)
            .options(
                selectinload(Playlist.items).selectinload(PlaylistTrack.track),
                selectinload(Playlist.owner),
            )
        )
    ).scalar_one_or_none()
    if playlist is None:
        raise HTTPException(status_code=404, detail="Плейлист не найден")
    return playlist


async def _load_liked(
    session: AsyncSession, owner_id: int, viewer_id: int | None, limit: int = 200
):
    result = await session.execute(
        select(Like)
        .where(Like.user_id == owner_id)
        .options(selectinload(Like.track))
        .order_by(Like.created_at.desc())
        .limit(limit)
    )
    return [like.track for like in result.scalars() if like.track]


@router.get("/{token}", response_model=PublicProfileOut)
async def public_profile(
    token: str,
    viewer: User | None = Depends(get_optional_user),
    session: AsyncSession = Depends(get_session),
) -> PublicProfileOut:
    owner = await _owner_by_token(session, token)
    access = await resolve_access(session, owner, viewer)
    is_owner = bool(viewer and viewer.id == owner.id)

    if not access.can_view:
        return PublicProfileOut(
            user=public_user(owner),
            access=access.access,  # type: ignore[arg-type]
            can_view=False,
            can_request=access.can_request,
            request_status=access.request_status,
            stats={},
            playlists=[],
            liked_tracks=[],
            show_liked=owner.show_liked,
            share_token=owner.share_token,
            is_authenticated=viewer is not None,
        )

    playlists: list[Playlist] = []
    if is_owner or owner.show_playlists:
        playlists = await visible_playlists(session, owner, viewer)

    liked_tracks = []
    if is_owner or owner.show_liked:
        liked = await _load_liked(session, owner.id, viewer.id if viewer else None)
        liked_ids = {track.id for track in liked}
        liked_tracks = tracks_out(liked, liked_ids)

    viewer_likes: set[int] = set()
    if viewer:
        viewer_likes = await liked_track_ids(session, viewer.id)

    serialized_playlists: list[PlaylistSummary] = []
    total_tracks = 0
    for playlist in playlists:
        summary = playlist_summary(playlist, include_owner=False)
        serialized_playlists.append(summary)
        total_tracks += summary.track_count

    liked_for_viewer = [
        track.model_copy(update={"liked": track.id in viewer_likes})
        for track in liked_tracks
    ]

    stats = {
        "playlists": len(playlists),
        "tracks": total_tracks,
    }
    if is_owner or owner.show_liked:
        stats["liked"] = len(liked_tracks)

    return PublicProfileOut(
        user=public_user(owner),
        access=access.access,  # type: ignore[arg-type]
        can_view=True,
        can_request=False,
        request_status=access.request_status,
        stats=stats,
        playlists=serialized_playlists,
        liked_tracks=liked_for_viewer,
        show_liked=owner.show_liked,
        share_token=owner.share_token,
        is_authenticated=viewer is not None,
    )


@router.post("/{token}/request")
async def request_access(
    token: str,
    background: BackgroundTasks,
    viewer: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> dict:
    owner = await _owner_by_token(session, token)
    if owner.id == viewer.id:
        return {"status": "owner", "message": "Это ваш профиль"}
    if owner.privacy == "public":
        return {"status": "public", "message": "Профиль уже открыт"}
    if owner.privacy == "private":
        raise HTTPException(status_code=403, detail="Владелец закрыл профиль для всех")

    access = await resolve_access(session, owner, viewer)
    if access.can_view:
        return {"status": "approved", "message": "Доступ уже открыт"}

    existing = await session.scalar(
        select(AccessRequest)
        .where(
            AccessRequest.owner_id == owner.id,
            AccessRequest.requester_id == viewer.id,
            AccessRequest.status == "pending",
        )
        .limit(1)
    )
    if existing is None:
        session.add(
            AccessRequest(
                owner_id=owner.id,
                requester_id=viewer.id,
                status="pending",
            )
        )
        await session.commit()
        if not owner.is_demo:
            background.add_task(
                notify_access_request,
                settings,
                owner.telegram_id,
                viewer.display_name,
            )
        return {"status": "pending", "message": "Заявка отправлена"}
    return {"status": "pending", "message": "Заявка уже отправлена"}


@router.get("/{token}/playlists/{playlist_id}", response_model=PublicPlaylistOut)
async def shared_playlist(
    token: str,
    playlist_id: int,
    viewer: User | None = Depends(get_optional_user),
    session: AsyncSession = Depends(get_session),
) -> PublicPlaylistOut:
    owner = await _owner_by_token(session, token)
    access = await resolve_access(session, owner, viewer)
    if not access.can_view:
        raise HTTPException(status_code=403, detail="Нет доступа к профилю")
    playlist = await _playlist_for_owner(session, owner.id, playlist_id)
    is_owner = bool(viewer and viewer.id == owner.id)
    if not playlist.is_public and not is_owner:
        raise HTTPException(status_code=403, detail="Плейлист скрыт владельцем")
    if not owner.show_playlists and not is_owner:
        raise HTTPException(status_code=403, detail="Плейлисты скрыты владельцем")
    liked = await liked_track_ids(session, viewer.id) if viewer else set()
    return PublicPlaylistOut(
        playlist=playlist_out(playlist, include_owner=True, liked_ids=liked),
        access=access.access,
        can_copy=bool(viewer and viewer.id != owner.id),
    )


@router.post("/{token}/playlists/{playlist_id}/copy", response_model=CopyResult)
async def copy_shared_playlist(
    token: str,
    playlist_id: int,
    viewer: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> CopyResult:
    owner = await _owner_by_token(session, token)
    access = await resolve_access(session, owner, viewer)
    if not access.can_view:
        raise HTTPException(status_code=403, detail="Нет доступа к профилю")
    source = await _playlist_for_owner(session, owner.id, playlist_id)
    is_owner = viewer.id == owner.id
    if not source.is_public and not is_owner:
        raise HTTPException(status_code=403, detail="Плейлист скрыт владельцем")
    if not owner.show_playlists and not is_owner:
        raise HTTPException(status_code=403, detail="Плейлисты скрыты владельцем")

    title = source.title if len(source.title) <= 112 else source.title[:112]
    title = f"{title} · копия"
    copy = Playlist(
        owner_id=viewer.id,
        title=title,
        description=source.description,
        cover_url=source.cover_url,
        is_public=True,
    )
    session.add(copy)
    await session.flush()
    for position, item in enumerate(source.items):
        session.add(
            PlaylistTrack(
                playlist_id=copy.id,
                track_id=item.track_id,
                position=position,
            )
        )
    await session.commit()
    copy = (
        await session.execute(
            select(Playlist)
            .where(Playlist.id == copy.id)
            .options(selectinload(Playlist.items).selectinload(PlaylistTrack.track))
        )
    ).scalar_one()
    return CopyResult(playlist=playlist_summary(copy))
