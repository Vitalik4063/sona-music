from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field, field_validator

from backend.config import Settings
from backend.schemas import SessionOut, UserOut


class SessionIn(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    init_data: str = Field(alias="initData", min_length=1, max_length=16_384)


def _session_out(token: str, user, is_dev: bool) -> SessionOut:
    return SessionOut(
        token=token,
        user=UserOut(
            id=user.id,
            telegram_id=user.telegram_id,
            username=user.username,
            first_name=user.first_name,
            last_name=user.last_name,
            display_name=user.display_name,
            photo_url=user.photo_url,
            bio=user.bio,
            accent=user.accent,
            privacy=user.privacy,
        ),
        is_dev=is_dev,
    )
