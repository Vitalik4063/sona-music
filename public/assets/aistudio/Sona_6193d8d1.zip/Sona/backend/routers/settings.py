from __future__ import annotations

import re

from fastapi import APIRouter, BackgroundTasks, Depends, HTTPException
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.config import Settings
from backend.dependencies import get_app_settings, get_current_user, get_session
from backend.models import AccessRequest, AllowedViewer, User
from backend.models import utcnow
from backend.schemas import (
    AccessRequestOut,
    AddViewerIn,
    AllowedViewerOut,
    SettingsOut,
    UpdateSettingsIn,
)
from backend.services.access import get_allowed_viewers
from backend.services.notify import notify_access_approved
from backend.services.serializers import public_user, user_out

router = APIRouter(prefix="/settings", tags=["settings"])

USERNAME_RE = re.compile(r"^[A-Za-z0-9_]{3,32}$")


def share_links(settings: Settings, token: str) -> tuple[str, str]:
    deep_link = f"https://t.me/{settings.bot_username}?startapp=u_{token}"
    webapp_link = f"{settings.webapp_base}/u/{token}"
    return deep_link, webapp_link


async def _settings_out(
    session: AsyncSession, user: User, settings: Settings
) -> SettingsOut:
    viewers = await get_allowed_viewers(session, user.id)
    incoming_result = await session.execute(
        select(AccessRequest)
        .where(AccessRequest.owner_id == user.id, AccessRequest.status == "pending")
        .options(selectinload(AccessRequest.requester))
        .order_by(AccessRequest.created_at.desc())
    )
    outgoing_result = await session.execute(
        select(AccessRequest)
        .where(AccessRequest.requester_id == user.id)
        .options(selectinload(AccessRequest.owner))
        .order_by(AccessRequest.created_at.desc())
        .limit(10)
    )
    deep_link, webapp_link = share_links(settings, user.share_token)
    return SettingsOut(
        user=user_out(user),
        show_liked=user.show_liked,
        show_playlists=user.show_playlists,
        privacy=user.privacy,  # type: ignore[arg-type]
        accent=user.accent,
        share_token=user.share_token,
        share_url=deep_link,
        webapp_share_url=webapp_link,
        bot_username=settings.bot_username,
        allowed_viewers=[
            AllowedViewerOut(
                id=viewer.id,
                identifier_type=viewer.identifier_type,
                identifier_value=viewer.identifier_value,
                display_name=viewer.display_name,
                created_at=viewer.created_at,
            )
            for viewer in viewers
        ],
        incoming_requests=[
            AccessRequestOut(
                id=request.id,
                status=request.status,
                created_at=request.created_at,
                requester=public_user(request.requester) if request.requester else None,
            )
            for request in incoming_result.scalars()
        ],
        outgoing_requests=[
            AccessRequestOut(
                id=request.id,
                status=request.status,
                created_at=request.created_at,
                owner=public_user(request.owner) if request.owner else None,
            )
            for request in outgoing_result.scalars()
        ],
    )


@router.get("", response_model=SettingsOut)
async def get_settings_page(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SettingsOut:
    return await _settings_out(session, user, settings)


@router.patch("", response_model=SettingsOut)
async def update_settings(
    payload: UpdateSettingsIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SettingsOut:
    if payload.privacy is not None:
        user.privacy = payload.privacy
    if payload.show_liked is not None:
        user.show_liked = payload.show_liked
    if payload.show_playlists is not None:
        user.show_playlists = payload.show_playlists
    if payload.accent is not None:
        user.accent = payload.accent
    if payload.bio is not None:
        user.bio = payload.bio.strip()
    if payload.first_name is not None:
        user.first_name = payload.first_name.strip() or user.first_name
    await session.commit()
    await session.refresh(user)
    return await _settings_out(session, user, settings)


@router.post("/viewers", response_model=SettingsOut)
async def add_viewer(
    payload: AddViewerIn,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SettingsOut:
    value = payload.identifier.strip()
    if value.startswith("@"):
        value = value[1:]
    if not value:
        raise HTTPException(status_code=422, detail="Укажите @username или Telegram ID")

    if value.isdigit():
        if int(value) == user.telegram_id:
            raise HTTPException(status_code=400, detail="Это ваш собственный профиль")
        identifier_type = "telegram_id"
        identifier_value = value
        target = await session.scalar(select(User).where(User.telegram_id == int(value)))
        display_name = target.display_name if target else f"ID {value}"
    else:
        if not USERNAME_RE.match(value):
            raise HTTPException(
                status_code=422,
                detail="Username может содержать только латиницу, цифры и _",
            )
        identifier_type = "username"
        identifier_value = value.lower()
        target = await session.scalar(select(User).where(User.username == value))
        display_name = target.display_name if target else f"@{value}"

    duplicate = await session.scalar(
        select(AllowedViewer.id).where(
            AllowedViewer.owner_id == user.id,
            AllowedViewer.identifier_type == identifier_type,
            AllowedViewer.identifier_value == identifier_value,
        )
    )
    if duplicate:
        raise HTTPException(status_code=409, detail="Этот человек уже в списке доступа")

    session.add(
        AllowedViewer(
            owner_id=user.id,
            identifier_type=identifier_type,
            identifier_value=identifier_value,
            display_name=display_name,
        )
    )
    await session.commit()
    return await _settings_out(session, user, settings)


@router.delete("/viewers/{viewer_id}", response_model=SettingsOut)
async def remove_viewer(
    viewer_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SettingsOut:
    await session.execute(
        delete(AllowedViewer).where(
            AllowedViewer.id == viewer_id, AllowedViewer.owner_id == user.id
        )
    )
    await session.commit()
    return await _settings_out(session, user, settings)


@router.post("/requests/{request_id}/approve", response_model=SettingsOut)
async def approve_request(
    request_id: int,
    background: BackgroundTasks,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SettingsOut:
    access_request = await session.scalar(
        select(AccessRequest)
        .where(AccessRequest.id == request_id, AccessRequest.owner_id == user.id)
        .options(selectinload(AccessRequest.requester))
    )
    if access_request is None:
        raise HTTPException(status_code=404, detail="Заявка не найдена")
    if access_request.status != "pending":
        raise HTTPException(status_code=409, detail="Заявка уже обработана")

    requester = access_request.requester
    access_request.status = "approved"
    access_request.decided_at = utcnow()
    if user.privacy == "private":
        user.privacy = "selected"
    identifier_type = "telegram_id"
    identifier_value = str(requester.telegram_id)
    existing = await session.scalar(
        select(AllowedViewer.id).where(
            AllowedViewer.owner_id == user.id,
            AllowedViewer.identifier_type == identifier_type,
            AllowedViewer.identifier_value == identifier_value,
        )
    )
    if not existing:
        session.add(
            AllowedViewer(
                owner_id=user.id,
                identifier_type=identifier_type,
                identifier_value=identifier_value,
                display_name=requester.display_name,
            )
        )
    await session.commit()
    background.add_task(
        notify_access_approved,
        settings,
        requester.telegram_id,
        user.display_name,
        user.share_token,
    )
    return await _settings_out(session, user, settings)


@router.post("/requests/{request_id}/decline", response_model=SettingsOut)
async def decline_request(
    request_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SettingsOut:
    access_request = await session.scalar(
        select(AccessRequest).where(
            AccessRequest.id == request_id, AccessRequest.owner_id == user.id
        )
    )
    if access_request is None:
        raise HTTPException(status_code=404, detail="Заявка не найдена")
    if access_request.status != "pending":
        raise HTTPException(status_code=409, detail="Заявка уже обработана")
    access_request.status = "declined"
    access_request.decided_at = utcnow()
    await session.commit()
    return await _settings_out(session, user, settings)


@router.post("/rotate-share", response_model=SettingsOut)
async def rotate_share_link(
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
    settings: Settings = Depends(get_app_settings),
) -> SettingsOut:
    from backend.auth import ensure_unique_share_token

    user.share_token = await ensure_unique_share_token(session)
    await session.commit()
    await session.refresh(user)
    return await _settings_out(session, user, settings)
