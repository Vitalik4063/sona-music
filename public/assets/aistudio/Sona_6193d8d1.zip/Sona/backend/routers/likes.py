from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.dependencies import get_current_user, get_session
from backend.models import Like, Track, User
from backend.schemas import TrackOut
from backend.services.serializers import track_out
from backend.services.tracks import liked_track_ids

router = APIRouter(prefix="/likes", tags=["likes"])


@router.post("/{track_id}", response_model=TrackOut)
async def like_track(
    track_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> TrackOut:
    track = await session.get(Track, track_id)
    if track is None:
        raise HTTPException(status_code=404, detail="Трек не найден")
    existing = await session.get(Like, (user.id, track_id))
    if existing is None:
        session.add(Like(user_id=user.id, track_id=track_id))
        await session.commit()
    return track_out(track, True)


@router.delete("/{track_id}", response_model=TrackOut)
async def unlike_track(
    track_id: int,
    user: User = Depends(get_current_user),
    session: AsyncSession = Depends(get_session),
) -> TrackOut:
    track = await session.get(Track, track_id)
    if track is None:
        raise HTTPException(status_code=404, detail="Трек не найден")
    await session.execute(
        delete(Like).where(Like.user_id == user.id, Like.track_id == track_id)
    )
    await session.commit()
    return track_out(track, False)
