from __future__ import annotations

from datetime import datetime, timedelta, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.config import Settings
from backend.models import Like, Playlist, PlaylistTrack, Track, User
from backend.services.music.base import track_fingerprint

DEMO_TRACKS = [
    {
        "provider_id": "demo-01",
        "title": "Стеклянный дождь",
        "artist": "Nula",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 24615,
        "artwork": "01-glass-rain.jpg",
        "audio": "01-glass-rain.mp3",
        "tags": ["night", "focus"],
    },
    {
        "provider_id": "demo-02",
        "title": "Полночный трамвай",
        "artist": "Неон и Пыль",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 21818,
        "artwork": "02-midnight-tram.jpg",
        "audio": "02-midnight-tram.mp3",
        "tags": ["night", "drive"],
    },
    {
        "provider_id": "demo-03",
        "title": "Летний ток",
        "artist": "Mara Vale",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 20000,
        "artwork": "03-summer-current.jpg",
        "audio": "03-summer-current.mp3",
        "tags": ["warm", "drive"],
    },
    {
        "provider_id": "demo-04",
        "title": "Тише",
        "artist": "Kite Arcade",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 26667,
        "artwork": "04-quieter.jpg",
        "audio": "04-quieter.mp3",
        "tags": ["focus", "warm"],
    },
    {
        "provider_id": "demo-05",
        "title": "Северный свет",
        "artist": "Lumen Field",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 28235,
        "artwork": "05-northern-light.jpg",
        "audio": "05-northern-light.mp3",
        "tags": ["warm", "focus"],
    },
    {
        "provider_id": "demo-06",
        "title": "Всё равно",
        "artist": "Чувства",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 22857,
        "artwork": "06-anyway.jpg",
        "audio": "06-anyway.mp3",
        "tags": ["warm", "drive"],
    },
    {
        "provider_id": "demo-07",
        "title": "После дождя",
        "artist": "Nula",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 25946,
        "artwork": "07-after-rain.jpg",
        "audio": "07-after-rain.mp3",
        "tags": ["focus", "warm"],
    },
    {
        "provider_id": "demo-08",
        "title": "Не спать",
        "artist": "Неон и Пыль",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 18824,
        "artwork": "08-stay-awake.jpg",
        "audio": "08-stay-awake.mp3",
        "tags": ["night", "drive"],
    },
    {
        "provider_id": "demo-09",
        "title": "Гравитация",
        "artist": "Mara Vale",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 20870,
        "artwork": "09-gravity.jpg",
        "audio": "09-gravity.mp3",
        "tags": ["drive", "night"],
    },
    {
        "provider_id": "demo-10",
        "title": "Белый шум",
        "artist": "Kite Arcade",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 27429,
        "artwork": "10-white-noise.jpg",
        "audio": "10-white-noise.mp3",
        "tags": ["focus"],
    },
    {
        "provider_id": "demo-11",
        "title": "Кофе в 6:40",
        "artist": "Lumen Field",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 24000,
        "artwork": "11-coffee-640.jpg",
        "audio": "11-coffee-640.mp3",
        "tags": ["warm", "focus"],
    },
    {
        "provider_id": "demo-12",
        "title": "Домой",
        "artist": "Чувства",
        "album": "Sona Sessions, Vol. 1",
        "duration_ms": 25263,
        "artwork": "12-home.jpg",
        "audio": "12-home.mp3",
        "tags": ["drive", "warm", "night"],
    },
]


async def _ensure_demo_tracks(session: AsyncSession) -> list[Track]:
    result = await session.execute(
        select(Track).where(Track.provider == "sona").order_by(Track.id)
    )
    existing = {track.provider_id: track for track in result.scalars()}
    tracks: list[Track] = []
    for item in DEMO_TRACKS:
        track = existing.get(item["provider_id"])
        artwork_url = f"/static/demo/covers/{item['artwork']}"
        preview_url = f"/static/demo/audio/{item['audio']}"
        if track is None:
            track = Track(
                fingerprint=track_fingerprint(item["title"], item["artist"]),
                provider="sona",
                provider_id=item["provider_id"],
                title=item["title"],
                artist=item["artist"],
                album=item["album"],
                duration_ms=item["duration_ms"],
                artwork_url=artwork_url,
                preview_url=preview_url,
                external_url=None,
                links={},
                sources=["Sona"],
                tags=item["tags"],
                is_demo=True,
            )
            session.add(track)
        else:
            track.artwork_url = artwork_url
            track.preview_url = preview_url
            track.tags = item["tags"]
            track.duration_ms = item["duration_ms"]
        tracks.append(track)
    await session.flush()
    return tracks


async def _ensure_user(
    session: AsyncSession,
    *,
    telegram_id: int,
    username: str,
    first_name: str,
    bio: str,
    photo_url: str | None,
    share_token: str,
    accent: str = "lime",
) -> User:
    user = await session.scalar(select(User).where(User.telegram_id == telegram_id))
    if user is None:
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            bio=bio,
            photo_url=photo_url,
            share_token=share_token,
            privacy="public",
            show_liked=True,
            show_playlists=True,
            accent=accent,
            is_demo=True,
        )
        session.add(user)
        await session.flush()
    return user


async def _ensure_playlist(
    session: AsyncSession,
    owner: User,
    title: str,
    description: str,
    tracks: list[Track],
) -> Playlist:
    playlist = await session.scalar(
        select(Playlist)
        .where(Playlist.owner_id == owner.id, Playlist.title == title)
        .options(selectinload(Playlist.items))
    )
    created = playlist is None
    if playlist is None:
        playlist = Playlist(
            owner_id=owner.id,
            title=title,
            description=description,
            is_public=True,
        )
        session.add(playlist)
        await session.flush()
    existing = set() if created else {item.track_id for item in (playlist.items or [])}
    for position, track in enumerate(tracks):
        if track.id not in existing:
            session.add(
                PlaylistTrack(
                    playlist_id=playlist.id,
                    track_id=track.id,
                    position=position,
                )
            )
    return playlist


async def _ensure_likes(
    session: AsyncSession, user: User, tracks: list[Track], created_days: int = 0
) -> None:
    existing = set(
        (
            await session.execute(select(Like.track_id).where(Like.user_id == user.id))
        ).scalars()
    )
    base = datetime.now(timezone.utc) - timedelta(days=created_days)
    for index, track in enumerate(tracks):
        if track.id not in existing:
            session.add(
                Like(
                    user_id=user.id,
                    track_id=track.id,
                    created_at=base - timedelta(minutes=index * 17),
                )
            )


async def seed_demo_data(session: AsyncSession, settings: Settings) -> None:
    if not settings.seed_demo:
        return
    tracks = await _ensure_demo_tracks(session)
    by_number = {track.provider_id: track for track in tracks}
    t = lambda number: by_number[f"demo-{number:02d}"]  # noqa: E731

    alisa = await _ensure_user(
        session,
        telegram_id=100_000_001,
        username="alisa_wave",
        first_name="Алиса",
        bio="Ночные поездки, тёплый звук и кофе до рассвета.",
        photo_url="/static/demo/avatars/alisa.jpg",
        share_token="demo-alisa",
    )
    dev = await _ensure_user(
        session,
        telegram_id=999_000_001,
        username="sona_you",
        first_name="Ты",
        bio="Тестовый профиль для локальной разработки",
        photo_url=None,
        share_token="demo-you",
    )

    await _ensure_playlist(
        session,
        alisa,
        "Ночная смена",
        "Когда город уже спит, а музыка только начинается.",
        [t(1), t(2), t(8), t(9)],
    )
    await _ensure_playlist(
        session,
        alisa,
        "Тихое утро",
        "Медленный свет, кофе и немного пространства для себя.",
        [t(11), t(7), t(4), t(5)],
    )
    await _ensure_playlist(
        session,
        alisa,
        "Дорога домой",
        "Любимые треки для долгой дороги и пустых улиц.",
        [t(6), t(12), t(3), t(10)],
    )
    await _ensure_playlist(
        session,
        dev,
        "Мой вайб",
        "Всё, что хочется слушать снова и снова.",
        [t(1), t(4), t(9), t(11)],
    )
    await _ensure_playlist(
        session,
        dev,
        "Глубокий фокус",
        "Без слов, без уведомлений. Только ты и задача.",
        [t(10), t(4), t(7)],
    )
    await _ensure_playlist(
        session,
        dev,
        "Вечерний свет",
        "Мягкий саундтрек для конца дня.",
        [t(2), t(5), t(12), t(6)],
    )

    await _ensure_likes(session, alisa, [t(2), t(3), t(5), t(7), t(12)])
    await _ensure_likes(session, dev, [t(1), t(3), t(7), t(9)])
    await session.commit()
