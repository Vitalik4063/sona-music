from __future__ import annotations

import hashlib
import hmac
import json
import secrets
import time
from datetime import datetime, timedelta, timezone
from typing import Any
from urllib.parse import parse_qsl

import jwt
from fastapi import HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.config import Settings
from backend.models import User

JWT_ALGORITHM = "HS256"


def _data_check_string(values: dict[str, str], exclude_signature: bool) -> str:
    pairs = []
    for key in sorted(values):
        if key == "hash":
            continue
        if exclude_signature and key == "signature":
            continue
        pairs.append(f"{key}={values[key]}")
    return "\n".join(pairs)


def validate_init_data(
    init_data: str,
    bot_token: str,
    max_age_seconds: int = 86_400,
    now: int | None = None,
) -> dict[str, Any]:
    if not init_data or len(init_data) > 16_384:
        raise ValueError("Пустые данные Telegram")

    pairs = parse_qsl(init_data, keep_blank_values=True, strict_parsing=False)
    values = dict(pairs)
    received_hash = values.get("hash", "")
    if not received_hash:
        raise ValueError("В данных нет подписи Telegram")

    secret_key = hmac.new(
        b"WebAppData", bot_token.encode("utf-8"), hashlib.sha256
    ).digest()

    valid = False
    for exclude_signature in (False, True):
        check_string = _data_check_string(values, exclude_signature)
        calculated = hmac.new(
            secret_key, check_string.encode("utf-8"), hashlib.sha256
        ).hexdigest()
        if hmac.compare_digest(calculated, received_hash):
            valid = True
            break
    if not valid:
        raise ValueError("Подпись Telegram не совпадает")

    try:
        auth_date = int(values.get("auth_date", "0"))
    except ValueError as exc:
        raise ValueError("Некорректная дата авторизации") from exc

    current = now if now is not None else int(time.time())
    if auth_date <= 0:
        raise ValueError("В данных нет даты авторизации")
    if auth_date > current + 120:
        raise ValueError("Дата авторизации из будущего")
    if current - auth_date > max_age_seconds:
        raise ValueError("Сессия Telegram устарела, откройте приложение заново")

    try:
        user = json.loads(values.get("user", "{}"))
    except json.JSONDecodeError as exc:
        raise ValueError("Некорректный профиль Telegram") from exc
    if not user.get("id"):
        raise ValueError("В данных нет пользователя Telegram")

    return {"user": user, "auth_date": auth_date, "raw": values}


def create_access_token(user: User, settings: Settings) -> str:
    now = datetime.now(timezone.utc)
    payload = {
        "sub": str(user.id),
        "tid": user.telegram_id,
        "iat": int(now.timestamp()),
        "exp": int((now + timedelta(days=settings.jwt_expire_days)).timestamp()),
        "iss": "sona",
    }
    return jwt.encode(payload, settings.jwt_secret, algorithm=JWT_ALGORITHM)


def decode_access_token(token: str, settings: Settings) -> dict[str, Any]:
    try:
        return jwt.decode(
            token,
            settings.jwt_secret,
            algorithms=[JWT_ALGORITHM],
            issuer="sona",
        )
    except jwt.ExpiredSignatureError as exc:
        raise ValueError("Сессия истекла") from exc
    except jwt.PyJWTError as exc:
        raise ValueError("Некорректная сессия") from exc


def generate_share_token() -> str:
    return secrets.token_urlsafe(9).replace("-", "").replace("_", "")[:12]


async def ensure_unique_share_token(session: AsyncSession) -> str:
    for _ in range(8):
        token = generate_share_token()
        exists = await session.scalar(select(User.id).where(User.share_token == token))
        if not exists:
            return token
    return secrets.token_urlsafe(16)


async def upsert_telegram_user(
    session: AsyncSession,
    telegram_user: dict[str, Any],
    *,
    is_demo: bool = False,
) -> User:
    telegram_id = int(telegram_user["id"])
    user = await session.scalar(select(User).where(User.telegram_id == telegram_id))
    username = (telegram_user.get("username") or "").strip().lstrip("@") or None
    first_name = (telegram_user.get("first_name") or "Слушатель").strip()[:128]
    last_name = (telegram_user.get("last_name") or "").strip()[:128] or None
    photo_url = telegram_user.get("photo_url")

    if user is None:
        user = User(
            telegram_id=telegram_id,
            username=username,
            first_name=first_name,
            last_name=last_name,
            photo_url=photo_url,
            share_token=await ensure_unique_share_token(session),
            is_demo=is_demo,
        )
        session.add(user)
    else:
        user.username = username or user.username
        user.first_name = first_name or user.first_name
        user.last_name = last_name
        if photo_url:
            user.photo_url = photo_url
    await session.flush()
    return user


async def get_or_create_dev_user(session: AsyncSession) -> User:
    telegram_id = 999_000_001
    user = await session.scalar(select(User).where(User.telegram_id == telegram_id))
    if user is None:
        user = User(
            telegram_id=telegram_id,
            username="sona_you",
            first_name="Ты",
            last_name=None,
            bio="Тестовый профиль для локальной разработки",
            privacy="public",
            share_token=await ensure_unique_share_token(session),
            is_demo=True,
        )
        session.add(user)
        await session.flush()
    return user


def auth_error(detail: str = "Нужна авторизация") -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=detail,
        headers={"WWW-Authenticate": "Bearer"},
    )
