from __future__ import annotations

from dataclasses import dataclass

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.models import AccessRequest, AllowedViewer, PlaylistTrack, User
from backend.models import Playlist as PlaylistModel


@dataclass
class AccessInfo:
    access: str
    can_view: bool
    can_request: bool = False
    request_status: str | None = None


async def get_allowed_viewers(session: AsyncSession, owner_id: int) -> list[AllowedViewer]:
    result = await session.execute(
        select(AllowedViewer)
        .where(AllowedViewer.owner_id == owner_id)
        .order_by(AllowedViewer.created_at.desc())
    )
    return list(result.scalars())


def viewer_matches(viewer: User, allowed: list[AllowedViewer]) -> bool:
    username = viewer.username_normalized
    telegram_id = str(viewer.telegram_id)
    for item in allowed:
        if item.identifier_type == "telegram_id" and item.identifier_value == telegram_id:
            return True
        if (
            item.identifier_type == "username"
            and username
            and item.identifier_value.lower() == username
        ):
            return True
    return False


async def latest_request(
    session: AsyncSession, owner_id: int, requester_id: int
) -> AccessRequest | None:
    result = await session.execute(
        select(AccessRequest)
        .where(
            AccessRequest.owner_id == owner_id,
            AccessRequest.requester_id == requester_id,
        )
        .order_by(AccessRequest.created_at.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def resolve_access(
    session: AsyncSession,
    owner: User,
    viewer: User | None,
    *,
    check_request: bool = True,
) -> AccessInfo:
    if viewer and viewer.id == owner.id:
        return AccessInfo(access="owner", can_view=True)

    if owner.privacy == "public":
        return AccessInfo(access="public", can_view=True)

    if owner.privacy == "private":
        return AccessInfo(access="private", can_view=False)

    allowed = await get_allowed_viewers(session, owner.id)
    if viewer and viewer_matches(viewer, allowed):
        return AccessInfo(access="granted", can_view=True)

    request_status = None
    if viewer and check_request:
        request = await latest_request(session, owner.id, viewer.id)
        request_status = request.status if request else None

    can_request = bool(
        viewer
        and owner.privacy == "selected"
        and request_status not in {"pending", "approved"}
    )
    if viewer and request_status == "approved":
        can_request = True

    return AccessInfo(
        access="locked",
        can_view=False,
        can_request=can_request,
        request_status=request_status,
    )


async def visible_playlists(
    session: AsyncSession, owner: User, viewer: User | None, *, include_private: bool = False
):
    query = (
        select(PlaylistModel)
        .where(PlaylistModel.owner_id == owner.id)
        .options(
            selectinload(PlaylistModel.items).selectinload(PlaylistTrack.track),
            selectinload(PlaylistModel.owner),
        )
        .order_by(PlaylistModel.updated_at.desc())
    )
    is_owner = bool(viewer and viewer.id == owner.id)
    if not (is_owner or include_private):
        query = query.where(PlaylistModel.is_public.is_(True))
    result = await session.execute(query)
    return list(result.scalars())
