from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from backend.models import Like, Playlist, PlaylistTrack, RecentPlay, Track, User
from backend.schemas import MixOut, TrackOut
from backend.services.serializers import track_out

MIX_DEFINITIONS = [
    {
        "id": "night-shift",
        "title": "Ночная смена",
        "subtitle": "Электроника для города после полуночи",
        "accent": "violet",
        "tag": "night",
    },
    {
        "id": "warm-light",
        "title": "Тёплый свет",
        "subtitle": "Негромко, по-домашнему, без спешки",
        "accent": "sun",
        "tag": "warm",
    },
    {
        "id": "deep-focus",
        "title": "Глубокий фокус",
        "subtitle": "Ровный ритм, чтобы остаться в потоке",
        "accent": "mint",
        "tag": "focus",
    },
    {
        "id": "open-road",
        "title": "Открытая дорога",
        "subtitle": "Для окон, опущенных вниз",
        "accent": "coral",
        "tag": "drive",
    },
]


async def demo_tracks(session: AsyncSession) -> list[Track]:
    result = await session.execute(
        select(Track).where(Track.is_demo.is_(True)).order_by(Track.id.asc())
    )
    return list(result.scalars())


async def build_mixes(
    session: AsyncSession, user: User, liked_ids: set[int]
) -> list[MixOut]:
    demos = await demo_tracks(session)
    mixes: list[MixOut] = []
    for definition in MIX_DEFINITIONS:
        tag = definition["tag"]
        tracks = [track for track in demos if tag in (track.tags or [])]
        if not tracks:
            tracks = demos[:5]
        mixes.append(
            MixOut(
                id=definition["id"],
                title=definition["title"],
                subtitle=definition["subtitle"],
                accent=definition["accent"],
                artwork_url=tracks[0].artwork_url if tracks else None,
                tracks=[track_out(track, track.id in liked_ids) for track in tracks],
            )
        )

    recent_result = await session.execute(
        select(RecentPlay)
        .where(RecentPlay.user_id == user.id)
        .options(selectinload(RecentPlay.track))
        .order_by(RecentPlay.played_at.desc())
        .limit(8)
    )
    personal: list[Track] = [item.track for item in recent_result.scalars() if item.track]

    if len(personal) < 4:
        likes_result = await session.execute(
            select(Like)
            .where(Like.user_id == user.id)
            .options(selectinload(Like.track))
            .order_by(Like.created_at.desc())
            .limit(8)
        )
        for like in likes_result.scalars():
            if like.track and like.track not in personal:
                personal.append(like.track)
    if not personal:
        personal = demos[4:9]

    mixes.insert(
        0,
        MixOut(
            id="for-you",
            title="Только для тебя",
            subtitle="Собрано из твоих лайков и недавних прослушиваний",
            accent="lime",
            artwork_url=personal[0].artwork_url if personal else None,
            tracks=[track_out(track, track.id in liked_ids) for track in personal[:10]],
        ),
    )
    return mixes


async def mix_by_id(
    session: AsyncSession, user: User, mix_id: str, liked_ids: set[int]
) -> MixOut | None:
    mixes = await build_mixes(session, user, liked_ids)
    return next((mix for mix in mixes if mix.id == mix_id), None)


async def new_releases(session: AsyncSession, liked_ids: set[int], limit: int = 10) -> list[TrackOut]:
    autoload_items = (
        select(Track)
        .where(Track.is_demo.is_(False))
        .order_by(Track.created_at.desc())
        .limit(limit)
    )
    result = await session.execute(autoload_items)
    tracks = list(result.scalars())
    if len(tracks) < limit:
        demos = await demo_tracks(session)
        seen = {track.id for track in tracks}
        for track in demos:
            if track.id not in seen:
                tracks.append(track)
            if len(tracks) >= limit:
                break
    return [track_out(track, track.id in liked_ids) for track in tracks]
