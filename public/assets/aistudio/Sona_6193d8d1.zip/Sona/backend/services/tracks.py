from __future__ import annotations

from collections.abc import Iterable

from sqlalchemy import delete, select
from sqlalchemy.ext.asyncio import AsyncSession

from backend.models import Like, RecentPlay, Track
from backend.services.music.base import SERVICE_LABELS, TrackCandidate


def _merge_links(
    existing: dict[str, str] | None, incoming: dict[str, str] | None
) -> dict[str, str]:
    result = dict(existing or {})
    for key, value in (incoming or {}).items():
        if value:
            result[key] = value
    return result


async def upsert_candidates(
    session: AsyncSession, candidates: Iterable[TrackCandidate]
) -> list[Track]:
    candidates = list(candidates)
    if not candidates:
        return []
    fingerprints = {candidate.fingerprint for candidate in candidates}
    result = await session.execute(select(Track).where(Track.fingerprint.in_(fingerprints)))
    existing = {track.fingerprint: track for track in result.scalars()}

    tracks: list[Track] = []
    for candidate in candidates:
        track = existing.get(candidate.fingerprint)
        if track is None:
            track = Track(
                fingerprint=candidate.fingerprint,
                provider=candidate.service,
                provider_id=candidate.service_id,
                title=candidate.title,
                artist=candidate.artist,
                album=candidate.album,
                duration_ms=candidate.duration_ms,
                artwork_url=candidate.artwork_url,
                preview_url=candidate.preview_url,
                external_url=candidate.external_url,
                links=_merge_links({}, candidate.links),
                sources=[
                    SERVICE_LABELS.get(service, service)
                    for service in candidate.links
                    if service in SERVICE_LABELS
                ],
                isrc=candidate.isrc,
            )
            session.add(track)
            existing[candidate.fingerprint] = track
        else:
            track.links = _merge_links(track.links, candidate.links)
            track.sources = sorted(
                {
                    SERVICE_LABELS.get(service, service)
                    for service in track.links
                    if service in SERVICE_LABELS
                }
            )
            if not track.artwork_url and candidate.artwork_url:
                track.artwork_url = candidate.artwork_url
            if not track.preview_url and candidate.preview_url:
                track.preview_url = candidate.preview_url
            if not track.external_url and candidate.external_url:
                track.external_url = candidate.external_url
            if not track.duration_ms and candidate.duration_ms:
                track.duration_ms = candidate.duration_ms
            if not track.album and candidate.album:
                track.album = candidate.album
            if candidate.preview_url and candidate.service == "deezer":
                # Deezer previews are stable and directly playable as mp3.
                track.preview_url = candidate.preview_url
        tracks.append(track)

    await session.flush()
    return tracks


async def liked_track_ids(session: AsyncSession, user_id: int) -> set[int]:
    result = await session.execute(select(Like.track_id).where(Like.user_id == user_id))
    return set(result.scalars())


async def register_play(session: AsyncSession, user_id: int, track_id: int) -> None:
    existing = await session.get(RecentPlay, (user_id, track_id))
    if existing:
        existing.play_count += 1
        from backend.models import utcnow

        existing.played_at = utcnow()
    else:
        session.add(RecentPlay(user_id=user_id, track_id=track_id))


async def clear_history(session: AsyncSession, user_id: int) -> None:
    await session.execute(delete(RecentPlay).where(RecentPlay.user_id == user_id))
