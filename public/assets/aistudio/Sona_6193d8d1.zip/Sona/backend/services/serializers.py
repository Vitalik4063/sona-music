from __future__ import annotations

from collections.abc import Iterable

from backend.models import Playlist, PlaylistTrack, Track, User
from backend.schemas import PlaylistOut, PlaylistSummary, PublicUser, TrackOut, UserOut


def user_out(user: User) -> UserOut:
    return UserOut(
        id=user.id,
        telegram_id=user.telegram_id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name,
        display_name=user.display_name,
        photo_url=user.photo_url,
        bio=user.bio,
        accent=user.accent,
        privacy=user.privacy,  # type: ignore[arg-type]
    )


def public_user(user: User) -> PublicUser:
    return PublicUser(
        id=user.id,
        username=user.username,
        first_name=user.first_name,
        last_name=user.last_name,
        display_name=user.display_name,
        photo_url=user.photo_url,
        bio=user.bio,
        accent=user.accent,
        is_demo=user.is_demo,
    )


def track_out(track: Track, liked: bool = False) -> TrackOut:
    return TrackOut(
        id=track.id,
        title=track.title,
        artist=track.artist,
        album=track.album,
        duration_ms=track.duration_ms,
        artwork_url=track.artwork_url,
        preview_url=track.preview_url,
        external_url=track.external_url,
        provider=track.provider,
        links=track.links or {},
        sources=track.sources or [],
        is_demo=track.is_demo,
        liked=liked,
    )


def tracks_out(tracks: Iterable[Track], liked_ids: set[int] | None = None) -> list[TrackOut]:
    liked_ids = liked_ids or set()
    return [track_out(track, track.id in liked_ids) for track in tracks]


def _playlist_items(playlist: Playlist) -> list[PlaylistTrack]:
    return list(playlist.items or [])


def playlist_summary(
    playlist: Playlist, *, include_owner: bool = False
) -> PlaylistSummary:
    items = _playlist_items(playlist)
    collage = []
    for item in items:
        artwork = item.track.artwork_url if item.track else None
        if artwork and artwork not in collage:
            collage.append(artwork)
        if len(collage) == 4:
            break
    return PlaylistSummary(
        id=playlist.id,
        title=playlist.title,
        description=playlist.description or "",
        cover_url=playlist.cover_url,
        is_public=playlist.is_public,
        track_count=len(items),
        total_duration_ms=sum((item.track.duration_ms or 0) for item in items if item.track),
        collage=collage,
        owner=public_user(playlist.owner) if include_owner and playlist.owner else None,
        created_at=playlist.created_at,
        updated_at=playlist.updated_at,
    )


def playlist_out(
    playlist: Playlist,
    *,
    include_owner: bool = False,
    liked_ids: set[int] | None = None,
) -> PlaylistOut:
    summary = playlist_summary(playlist, include_owner=include_owner)
    tracks = [item.track for item in _playlist_items(playlist) if item.track]
    return PlaylistOut(
        **summary.model_dump(),
        tracks=tracks_out(tracks, liked_ids),
    )
