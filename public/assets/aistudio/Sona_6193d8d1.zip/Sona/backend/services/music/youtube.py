from __future__ import annotations

import httpx

from backend.services.music.base import TrackCandidate
from backend.services.music.provider import MusicProvider


class YouTubeProvider(MusicProvider):
    name = "youtube"
    label = "YouTube Music"

    def __init__(self, api_key: str) -> None:
        self.api_key = api_key

    @property
    def enabled(self) -> bool:
        return bool(self.api_key)

    async def search(
        self, client: httpx.AsyncClient, query: str, limit: int
    ) -> list[TrackCandidate]:
        if not self.enabled:
            return []
        response = await client.get(
            "https://www.googleapis.com/youtube/v3/search",
            params={
                "part": "snippet",
                "type": "video",
                "videoCategoryId": "10",
                "maxResults": min(max(limit, 10), 25),
                "q": query,
                "key": self.api_key,
            },
        )
        if response.status_code >= 400:
            return []
        tracks: list[TrackCandidate] = []
        for item in response.json().get("items", []):
            video_id = (item.get("id") or {}).get("videoId")
            snippet = item.get("snippet") or {}
            if not video_id or not snippet.get("title"):
                continue
            thumbnails = snippet.get("thumbnails") or {}
            thumb = (
                thumbnails.get("high")
                or thumbnails.get("medium")
                or thumbnails.get("default")
                or {}
            )
            title = snippet["title"]
            # YouTube titles are usually "Artist - Track". Split when we can.
            artist = snippet.get("channelTitle") or "YouTube"
            if " - " in title:
                possible_artist, possible_title = title.split(" - ", 1)
                if possible_artist and possible_title:
                    artist, title = possible_artist, possible_title
            tracks.append(
                TrackCandidate(
                    service=self.name,
                    service_id=video_id,
                    title=title,
                    artist=artist,
                    artwork_url=thumb.get("url"),
                    external_url=f"https://music.youtube.com/watch?v={video_id}",
                )
            )
        return tracks
