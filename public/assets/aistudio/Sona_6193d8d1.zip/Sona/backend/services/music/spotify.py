from __future__ import annotations

import base64
import time

import httpx

from backend.services.music.base import TrackCandidate
from backend.services.music.provider import MusicProvider


class SpotifyProvider(MusicProvider):
    name = "spotify"
    label = "Spotify"

    def __init__(self, client_id: str, client_secret: str) -> None:
        self.client_id = client_id
        self.client_secret = client_secret
        self._token: str | None = None
        self._expires_at = 0.0

    @property
    def enabled(self) -> bool:
        return bool(self.client_id and self.client_secret)

    async def _access_token(self, client: httpx.AsyncClient) -> str | None:
        if not self.enabled:
            return None
        if self._token and time.time() < self._expires_at - 30:
            return self._token
        credentials = base64.b64encode(
            f"{self.client_id}:{self.client_secret}".encode()
        ).decode()
        response = await client.post(
            "https://accounts.spotify.com/api/token",
            data={"grant_type": "client_credentials"},
            headers={"Authorization": f"Basic {credentials}"},
        )
        if response.status_code >= 400:
            return None
        payload = response.json()
        self._token = payload.get("access_token")
        self._expires_at = time.time() + int(payload.get("expires_in", 3600))
        return self._token

    async def search(
        self, client: httpx.AsyncClient, query: str, limit: int
    ) -> list[TrackCandidate]:
        token = await self._access_token(client)
        if not token:
            return []
        response = await client.get(
            "https://api.spotify.com/v1/search",
            params={"q": query, "type": "track", "limit": min(max(limit, 10), 25)},
            headers={"Authorization": f"Bearer {token}"},
        )
        if response.status_code == 401:
            self._token = None
            return []
        response.raise_for_status()
        items = (response.json().get("tracks") or {}).get("items") or []
        tracks: list[TrackCandidate] = []
        for item in items:
            if not item:
                continue
            images = sorted(
                (item.get("album") or {}).get("images") or [],
                key=lambda image: image.get("width") or 0,
                reverse=True,
            )
            artists = ", ".join(
                artist.get("name", "") for artist in item.get("artists") or []
            )
            tracks.append(
                TrackCandidate(
                    service=self.name,
                    service_id=str(item.get("id", "")),
                    title=item.get("name", ""),
                    artist=artists,
                    album=(item.get("album") or {}).get("name"),
                    duration_ms=int(item.get("duration_ms") or 0),
                    artwork_url=images[0].get("url") if images else None,
                    preview_url=item.get("preview_url"),
                    external_url=(item.get("external_urls") or {}).get("spotify"),
                    popularity=int(item.get("popularity") or 0),
                )
            )
        return tracks
