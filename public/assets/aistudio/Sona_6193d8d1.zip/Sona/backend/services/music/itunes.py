from __future__ import annotations

import httpx

from backend.services.music.base import TrackCandidate
from backend.services.music.provider import MusicProvider


class ITunesProvider(MusicProvider):
    name = "itunes"
    label = "Apple Music"
    endpoint = "https://itunes.apple.com/search"

    async def search(
        self, client: httpx.AsyncClient, query: str, limit: int
    ) -> list[TrackCandidate]:
        response = await client.get(
            self.endpoint,
            params={
                "term": query,
                "media": "music",
                "entity": "song",
                "limit": min(max(limit, 10), 35),
                "country": "US",
            },
        )
        response.raise_for_status()
        payload = response.json()
        tracks: list[TrackCandidate] = []
        for item in payload.get("results", []):
            if item.get("kind") != "song" or not item.get("trackId"):
                continue
            artwork = item.get("artworkUrl100") or item.get("artworkUrl60")
            if artwork:
                artwork = (
                    artwork.replace("100x100bb", "600x600bb")
                    .replace("60x60bb", "600x600bb")
                    .replace("100x100", "600x600")
                )
            tracks.append(
                TrackCandidate(
                    service=self.name,
                    service_id=str(item["trackId"]),
                    title=item.get("trackName", ""),
                    artist=item.get("artistName", ""),
                    album=item.get("collectionName"),
                    duration_ms=int(item.get("trackTimeMillis") or 0),
                    artwork_url=artwork,
                    preview_url=item.get("previewUrl"),
                    external_url=item.get("trackViewUrl"),
                    isrc=item.get("isrc"),
                )
            )
        return tracks
