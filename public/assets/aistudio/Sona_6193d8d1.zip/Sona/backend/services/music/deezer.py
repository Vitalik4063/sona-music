from __future__ import annotations

import httpx

from backend.services.music.base import TrackCandidate
from backend.services.music.provider import MusicProvider


class DeezerProvider(MusicProvider):
    name = "deezer"
    label = "Deezer"
    endpoint = "https://api.deezer.com/search"

    async def search(
        self, client: httpx.AsyncClient, query: str, limit: int
    ) -> list[TrackCandidate]:
        response = await client.get(
            self.endpoint,
            params={"q": query, "limit": min(max(limit, 10), 35)},
        )
        response.raise_for_status()
        payload = response.json()
        tracks: list[TrackCandidate] = []
        for item in payload.get("data", []):
            album = item.get("album") or {}
            artist = item.get("artist") or {}
            tracks.append(
                TrackCandidate(
                    service=self.name,
                    service_id=str(item.get("id", "")),
                    title=item.get("title", ""),
                    artist=artist.get("name", ""),
                    album=album.get("title"),
                    duration_ms=int(item.get("duration") or 0) * 1000,
                    artwork_url=(
                        album.get("cover_xl")
                        or album.get("cover_big")
                        or album.get("cover_medium")
                        or album.get("cover")
                    ),
                    preview_url=item.get("preview") or None,
                    external_url=item.get("link"),
                    popularity=int(item.get("rank") or 0),
                )
            )
        return tracks
