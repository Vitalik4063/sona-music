from __future__ import annotations

import hashlib
import html
import re
import unicodedata
from dataclasses import dataclass, field


def _strip_accents(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value)
    return "".join(ch for ch in normalized if not unicodedata.combining(ch))


def clean_text(value: str | None) -> str:
    if not value:
        return ""
    value = html.unescape(value)
    value = re.sub(r"\s+", " ", value)
    return value.strip()


def normalize_title(value: str) -> str:
    value = _strip_accents(clean_text(value)).lower()
    value = re.sub(r"\([^)]*\)|\[[^\]]*\]", " ", value)
    value = re.sub(r"\s*-\s*(remaster(ed)?|live|radio edit|version).*$", " ", value)
    value = re.sub(r"[^\w\s]", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def normalize_artist(value: str) -> str:
    value = _strip_accents(clean_text(value)).lower()
    value = re.split(r"\s*(?:,|&| feat\.?| ft\.?| x |/)\s*", value, maxsplit=1)[0]
    value = re.sub(r"[^\w\s]", " ", value, flags=re.UNICODE)
    return re.sub(r"\s+", " ", value).strip()


def track_fingerprint(title: str, artist: str) -> str:
    raw = f"{normalize_title(title)}|{normalize_artist(artist)}"
    return hashlib.sha1(raw.encode("utf-8")).hexdigest()[:32]


SERVICE_LABELS = {
    "itunes": "Apple Music",
    "deezer": "Deezer",
    "spotify": "Spotify",
    "youtube": "YouTube Music",
    "soundcloud": "SoundCloud",
    "sona": "Sona",
}


@dataclass
class TrackCandidate:
    service: str
    service_id: str
    title: str
    artist: str
    album: str | None = None
    duration_ms: int = 0
    artwork_url: str | None = None
    preview_url: str | None = None
    external_url: str | None = None
    isrc: str | None = None
    popularity: int = 0
    links: dict[str, str] = field(default_factory=dict)

    def __post_init__(self) -> None:
        self.title = clean_text(self.title) or "Без названия"
        self.artist = clean_text(self.artist) or "Неизвестный исполнитель"
        if self.external_url and self.service not in self.links:
            self.links[self.service] = self.external_url

    @property
    def fingerprint(self) -> str:
        return track_fingerprint(self.title, self.artist)

    @property
    def service_label(self) -> str:
        return SERVICE_LABELS.get(self.service, self.service.title())

    @property
    def quality_score(self) -> int:
        return (
            (12 if self.preview_url else 0)
            + (4 if self.artwork_url else 0)
            + (2 if self.duration_ms else 0)
            + (2 if self.external_url else 0)
        )

    def merge(self, other: "TrackCandidate") -> "TrackCandidate":
        """Merge duplicate from another provider into the best available card."""
        primary, secondary = (self, other)
        if other.quality_score > self.quality_score:
            primary, secondary = other, self

        primary.links = {**secondary.links, **primary.links}
        if not primary.preview_url and secondary.preview_url:
            primary.preview_url = secondary.preview_url
        if not primary.artwork_url and secondary.artwork_url:
            primary.artwork_url = secondary.artwork_url
        if not primary.duration_ms and secondary.duration_ms:
            primary.duration_ms = secondary.duration_ms
        if not primary.album and secondary.album:
            primary.album = secondary.album
        if not primary.external_url and secondary.external_url:
            primary.external_url = secondary.external_url
        if not primary.isrc and secondary.isrc:
            primary.isrc = secondary.isrc
        primary.popularity = max(primary.popularity, secondary.popularity)
        return primary


def query_relevance(candidate: TrackCandidate, query: str) -> float:
    q = _strip_accents(query).lower().strip()
    title = candidate.title.lower()
    artist = candidate.artist.lower()
    haystack = f"{title} {artist}"
    tokens = [token for token in re.split(r"\W+", q, flags=re.UNICODE) if token]

    score = 0.0
    if q and (title.startswith(q) or f"{artist} {title}".startswith(q)):
        score += 40
    if q and q in title:
        score += 28
    if q and q in artist:
        score += 18
    if tokens:
        matched = sum(1 for token in tokens if token in haystack)
        score += 24 * (matched / len(tokens))
    if candidate.popularity:
        import math

        score += min(8.0, math.log10(max(candidate.popularity, 1)) * 1.5)
    if candidate.preview_url:
        score += 5
    return score
