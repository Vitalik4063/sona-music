from __future__ import annotations

import asyncio
import copy
import time
from dataclasses import dataclass
from urllib.parse import quote_plus

import httpx

from backend.config import Settings
from backend.services.music.base import TrackCandidate, query_relevance
from backend.services.music.deezer import DeezerProvider
from backend.services.music.itunes import ITunesProvider
from backend.services.music.provider import MusicProvider, new_http_client
from backend.services.music.spotify import SpotifyProvider
from backend.services.music.youtube import YouTubeProvider

EXTERNAL_SEARCH_SERVICES = {
    "yandex": "Яндекс Музыка",
    "vk": "VK Музыка",
    "youtube_music": "YouTube Music",
}


@dataclass
class SearchResult:
    query: str
    tracks: list[TrackCandidate]
    providers_used: list[str]
    elapsed_ms: int


CacheValue = tuple[list[TrackCandidate], list[str]]


class _TTLCache:
    def __init__(self, ttl: int) -> None:
        self.ttl = ttl
        self._data: dict[str, tuple[float, CacheValue]] = {}

    def get(self, key: str) -> CacheValue | None:
        if self.ttl <= 0:
            return None
        item = self._data.get(key)
        if not item:
            return None
        created_at, value = item
        if time.time() - created_at > self.ttl:
            self._data.pop(key, None)
            return None
        return copy.deepcopy(value)

    def set(self, key: str, tracks: list[TrackCandidate], providers: list[str]) -> None:
        if self.ttl <= 0:
            return
        if len(self._data) > 250:
            self._data.clear()
        self._data[key] = (
            time.time(),
            copy.deepcopy((tracks, providers)),
        )


class SearchAggregator:
    def __init__(self, settings: Settings) -> None:
        self.settings = settings
        self.providers: list[MusicProvider] = [
            DeezerProvider(),
            ITunesProvider(),
            SpotifyProvider(
                settings.spotify_client_id, settings.spotify_client_secret
            ),
            YouTubeProvider(settings.youtube_api_key),
        ]
        self.cache = _TTLCache(settings.search_cache_seconds)
        self._locks: dict[str, asyncio.Lock] = {}

    async def search(self, query: str, limit: int = 30) -> SearchResult:
        query = query.strip()
        if not query:
            return SearchResult(query=query, tracks=[], providers_used=[], elapsed_ms=0)

        cache_key = f"{query.lower()}::{limit}"
        cached = self.cache.get(cache_key)
        if cached is not None:
            cached_tracks, cached_providers = cached
            return SearchResult(
                query=query,
                tracks=cached_tracks,
                providers_used=cached_providers,
                elapsed_ms=0,
            )

        lock = self._locks.setdefault(cache_key, asyncio.Lock())
        async with lock:
            cached = self.cache.get(cache_key)
            if cached is not None:
                cached_tracks, cached_providers = cached
                return SearchResult(
                    query=query,
                    tracks=cached_tracks,
                    providers_used=cached_providers,
                    elapsed_ms=0,
                )

            started = time.perf_counter()
            async with new_http_client(self.settings.search_timeout_seconds) as client:
                groups = await asyncio.gather(
                    *[
                        provider.safe_search(client, query, limit)
                        for provider in self.providers
                    ],
                    return_exceptions=True,
                )

            providers_used: list[str] = []
            merged: dict[str, TrackCandidate] = {}
            for provider, group in zip(self.providers, groups):
                if isinstance(group, Exception) or not group:
                    continue
                providers_used.append(provider.label)
                for candidate in group:
                    if not candidate.service_id:
                        continue
                    key = candidate.fingerprint
                    if key in merged:
                        merged[key] = merged[key].merge(candidate)
                    else:
                        merged[key] = candidate

            for track in merged.values():
                search_term = quote_plus(f"{track.artist} {track.title}")
                track.links.setdefault(
                    "yandex", f"https://music.yandex.ru/search?text={search_term}"
                )
                track.links.setdefault(
                    "vk", f"https://vk.com/audio?q={search_term}"
                )
                track.links.setdefault(
                    "youtube_music",
                    f"https://music.youtube.com/search?q={search_term}",
                )

            ranked = sorted(
                merged.values(),
                key=lambda track: (
                    query_relevance(track, query),
                    track.quality_score,
                    track.popularity,
                ),
                reverse=True,
            )[:limit]
            self.cache.set(cache_key, ranked, providers_used)
            return SearchResult(
                query=query,
                tracks=ranked,
                providers_used=providers_used,
                elapsed_ms=int((time.perf_counter() - started) * 1000),
            )
