from __future__ import annotations

import asyncio
from abc import ABC, abstractmethod

import httpx

from backend.services.music.base import TrackCandidate

USER_AGENT = "SonaMusicBot/1.0 (+https://t.me/sona_music_bot)"


class MusicProvider(ABC):
    name: str
    label: str

    @abstractmethod
    async def search(
        self, client: httpx.AsyncClient, query: str, limit: int
    ) -> list[TrackCandidate]:
        raise NotImplementedError

    async def safe_search(
        self, client: httpx.AsyncClient, query: str, limit: int
    ) -> list[TrackCandidate]:
        try:
            return await asyncio.wait_for(self.search(client, query, limit), timeout=8)
        except Exception:
            return []


def new_http_client(timeout: float) -> httpx.AsyncClient:
    return httpx.AsyncClient(
        timeout=httpx.Timeout(timeout, connect=4.0),
        headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
        follow_redirects=True,
    )
