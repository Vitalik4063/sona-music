from __future__ import annotations

import logging

import httpx

from backend.config import Settings

logger = logging.getLogger(__name__)


async def send_telegram_message(
    settings: Settings,
    chat_id: int,
    text: str,
    *,
    button_text: str | None = None,
    button_url: str | None = None,
) -> bool:
    if not settings.bot_is_configured:
        return False
    payload: dict = {
        "chat_id": chat_id,
        "text": text,
        "parse_mode": "HTML",
        "disable_web_page_preview": True,
    }
    if button_text and button_url and button_url.startswith("https://"):
        payload["reply_markup"] = {
            "inline_keyboard": [[{"text": button_text, "web_app": {"url": button_url}}]]
        }
    try:
        async with httpx.AsyncClient(timeout=6) as client:
            response = await client.post(
                f"https://api.telegram.org/bot{settings.bot_token}/sendMessage",
                json=payload,
            )
        if response.status_code >= 400:
            logger.warning("Telegram notification failed: %s", response.text[:300])
            return False
        return True
    except Exception as exc:
        logger.warning("Telegram notification failed: %s", exc)
        return False


async def notify_access_request(
    settings: Settings,
    owner_telegram_id: int,
    requester_name: str,
) -> None:
    text = (
        "🔔 <b>Новая заявка в Sona</b>\n\n"
        f"<b>{requester_name}</b> просит доступ к твоему музыкальному профилю.\n\n"
        "Открой настройки → «Доступ к профилю», чтобы одобрить или отклонить заявку."
    )
    await send_telegram_message(
        settings,
        owner_telegram_id,
        text,
        button_text="Открыть заявки",
        button_url=f"{settings.webapp_base}/settings?tab=access",
    )


async def notify_access_approved(
    settings: Settings,
    requester_telegram_id: int,
    owner_name: str,
    share_token: str,
) -> None:
    profile_url = f"{settings.webapp_base}/u/{share_token}"
    text = (
        "✅ <b>Доступ открыт</b>\n\n"
        f"<b>{owner_name}</b> открыл(а) тебе свой музыкальный профиль в Sona.\n\n"
        "Загляни, чтобы послушать плейлисты и сохранить понравившееся."
    )
    await send_telegram_message(
        settings,
        requester_telegram_id,
        text,
        button_text="Открыть профиль",
        button_url=profile_url,
    )
