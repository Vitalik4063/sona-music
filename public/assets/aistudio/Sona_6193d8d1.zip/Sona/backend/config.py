from __future__ import annotations

from functools import lru_cache
from pathlib import Path

from pydantic import Field, model_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

BASE_DIR = Path(__file__).resolve().parent.parent

WEAK_JWT_SECRETS = {
    "change-me",
    "change-me-to-a-long-random-string",
    "secret",
    "sona-dev-secret-change-me",
}


class Settings(BaseSettings):
    """Runtime configuration. Everything can be overridden from .env."""

    model_config = SettingsConfigDict(
        env_file=str(BASE_DIR / ".env"),
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=False,
    )

    # Telegram
    bot_token: str = Field(default="000000:DEV_TOKEN")
    bot_username: str = Field(default="sona_music_bot")

    # Storage & auth
    database_url: str = Field(default="sqlite+aiosqlite:///./data/sona.db")
    jwt_secret: str = Field(default="sona-dev-secret-change-me")
    jwt_expire_days: int = Field(default=30, ge=1, le=365)

    # Web app
    public_webapp_url: str = Field(default="http://localhost:5173")
    environment: str = Field(default="development")
    allow_dev_auth: bool = Field(default=True)
    seed_demo: bool = Field(default=True)
    cors_origins: str = Field(
        default="http://localhost:5173,http://127.0.0.1:5173,http://localhost:8000"
    )

    # Music providers (all optional except Deezer + iTunes, which need no key)
    spotify_client_id: str = Field(default="")
    spotify_client_secret: str = Field(default="")
    youtube_api_key: str = Field(default="")
    search_timeout_seconds: float = Field(default=7.0, ge=2, le=20)
    search_cache_seconds: int = Field(default=180, ge=0, le=3600)

    @model_validator(mode="after")
    def _guard_production(self) -> "Settings":
        if not self.is_production:
            return self

        problems: list[str] = []
        if self.allow_dev_auth:
            problems.append("ALLOW_DEV_AUTH=true (set it to false)")
        if self.seed_demo:
            problems.append("SEED_DEMO=true (demo accounts must stay local)")
        if (
            len(self.jwt_secret) < 32
            or self.jwt_secret.strip().lower() in WEAK_JWT_SECRETS
        ):
            problems.append("JWT_SECRET is weak (use 32+ random characters)")
        if not self.public_webapp_url.startswith("https://"):
            problems.append("PUBLIC_WEBAPP_URL must use HTTPS")
        if "*" in self.cors_list:
            problems.append("CORS_ORIGINS cannot contain * with credentials")
        if problems:
            raise ValueError(
                "Unsafe production configuration: " + "; ".join(problems)
            )
        return self

    @property
    def is_production(self) -> bool:
        return self.environment.lower() in {"prod", "production"}

    @property
    def bot_is_configured(self) -> bool:
        return bool(self.bot_token) and ":" in self.bot_token and not self.bot_token.startswith("000000")

    @property
    def cors_list(self) -> list[str]:
        return [origin.strip() for origin in self.cors_origins.split(",") if origin.strip()]

    @property
    def webapp_base(self) -> str:
        return self.public_webapp_url.rstrip("/")

    @property
    def telegram_bot_link(self) -> str:
        return f"https://t.me/{self.bot_username}"

    def absolute_url(self, value: str | None) -> str | None:
        if not value:
            return None
        if value.startswith(("http://", "https://", "data:")):
            return value
        return f"{self.webapp_base}/{value.lstrip('/')}"


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    return Settings()
